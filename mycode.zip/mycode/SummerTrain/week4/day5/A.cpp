#include <stdio.h>
#include <cstring>
#include <string>
#include <algorithm>
using namespace std;
char str[1000010];
int f[1000010];
void kmp_pre(char *x,int m,int *nex)
{
  int i,j;
  j=nex[0]=-1;
  i=0;
  while(i<m)
  {
    while(-1!=j && x[i]!=x[j])  j=nex[j];
    nex[++i]=++j;
  }
}
void PrintF(int m)
{
  for(int i = 0; i <= m; i++)
    printf("%d ", f[i]);
  printf("\n");
}
int main()
{
  while(~scanf("%s", str))
  {
    if(!strcmp(str, "."))  break;
    int len = strlen(str);
    kmp_pre(str, len, f);
    //PrintF(len);
    int ans = 1;

    if(len % (len - f[len]) == 0)
      ans = len / (len - f[len]);
    printf("%d\n", ans);
  }
}
