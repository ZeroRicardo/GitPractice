#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
using namespace std;
const int N = 1000010;
int n, k;
int ran[N + 1];
int tmp[N + 1];
int sa[N + 1];
int lcp[N + 1];
bool compare_ca(int i, int j){
  if(ran[i] != ran[j])  return ran[i] < ran[j];
  else{
    int ri = i + k <= n ? ran[i + k] : -1;
    int rj = j + k <= n ? ran[j + k] : -1;
    return ri < rj;
  }
}
void construct_sa(string S, int *sa)
{
  n = S.length();
  for(int i = 0; i <= n; i++){
    sa[i] = i;
    ran[i] = i < n ? S[i] : -1;
  }
  for(k = 1; k <= n; k *= 2){
    sort(sa, sa + n + 1, compare_ca);
    tmp[sa[0]] = 0;
    for(int i = 1; i <= n; i++){
      tmp[sa[i]] = tmp[sa[i - 1]] + compare_ca(sa[i - 1], sa[i]);
    }
    for(int i = 0; i <= n; i++)
      ran[i] = tmp[i];
  }
}
void construct_lcp(string S, int *sa, int *lcp){
  int n =S.length();
  for(int i = 0; i <= n; i++) ran[sa[i]] = i;
  int h = 0;
  lcp[0] = 0;
  for(int i = 0; i <= n; i++)
  {
    int j = sa[ran[i] - 1];
    if(h > 0) h--;
    for(; j + h < n && i + h < n; h++){
      if(S[j + h] != S[i + h])  break;
    }
    lcp[ran[i] - 1] = h;
  }
}
char str[1000010];
string ssr;
int main()
{
  while(~scanf("%s", str))
  {
    if(!strcmp(str, ".")) break;
    int len = strlen(str);
    ssr.assign(str);
    construct_sa(ssr, sa);
  //  construct_lcp(ssr, sa, lcp);
    int l = sa[1] - sa[2];
  //  printf("%d %d\n", sa[1], sa[2]);
    int ans = str[sa[1]] == str[sa[2]] ? len / l : 1;
    //printf("%s %s\n%d %d\n", str + sa[i - 1], str + sa[i], lcp[i], ans);
    printf("%d\n", ans);
  }
  return 0;
}
