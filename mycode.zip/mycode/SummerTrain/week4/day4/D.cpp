#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <string.h>
#include <set>
#include <queue>
#include <vector>
using namespace std;
struct Trie
{
  int next[500010][130], fail[500010],end[500010];
  int root, L;
  int newnode()
  {
    for(int i = 0; i < 130; i++)
      next[L][i] = -1;
    end[L++] = 0;
    return L - 1;
  }
  void init()
  {
    L = 0;
    root = newnode();
  }
  void insert(char *buf, int num)
  {
    int len = strlen(buf);
    int now = root;
    for(int i = 0; i < len; i++)
    {
      if(next[now][buf[i]] == -1)
        next[now][buf[i]] = newnode();
      now = next[now][buf[i]];
    }
    end[now] = num;
  }
  void build()
  {
    queue<int> Q;
    fail[root] = root;
    for(int i = 0; i < 130; i++)
      if(next[root][i] == -1)
        next[root][i] = root;
      else
      {
        fail[next[root][i]] = root;
        Q.push(next[root][i]);
      }
    while(!Q.empty())
    {
      int now = Q.front();
      Q.pop();
      for(int i = 0;i < 130; i++)
        if(next[now][i] == -1)
          next[now][i] = next[fail[now]][i];
        else
        {
          fail[next[now][i]] = next[fail[now]][i];
          Q.push(next[now][i]);
        }
    }
  }
  int query(char *buf, int num)
  {
    int len = strlen(buf);
    int now = root;
    int res = 0;
    set<pair<int, int> > s;
    set<pair<int, int> >::iterator ite;
    s.clear();
    for(int i = 0; i < len; i++)
    {
      now = next[now][buf[i]];
      int temp = now;
      while(temp != root)
      {
        res += end[temp];
        if(end[temp])
        {
          s.insert(make_pair(end[temp], temp));
          if(s.size() >= 3)
            goto hell;
        }
        end[temp] = 0;
        temp = fail[temp];
      }
    }
hell: if(!s.empty())
    {
      printf("web %d:", num);
      for(ite = s.begin(); ite != s.end(); ite++)
      {
        printf(" %d", ite->first);
        end[ite->second] = ite->first;
      }
      printf("\n");
      s.clear();
      return 1;
    }
    return 0;
  }
  void debug()
  {
    for(int i = 0; i < L; i++)
    {
      printf("id = %3d, fail = %3d, end = %3d, chi = [", i, fail[i], end[i]);
      for(int j = 0; j < 130; j++)
        printf("%2d", next[i][j]);
      printf("]\n");
    }
  }
};
char buf[1000010];
Trie ac;
int main()
{
  int T;
  int n;
  //scanf("%d", &T);
  while(~scanf("%d", &n))
  {

    ac.init();
    for(int i = 0; i < n; i++)
    {
      scanf("%s", buf);
      ac.insert(buf, i + 1);
    }
    ac.build();
    int m;
    scanf("%d", &m);
    int ans = 0;
    for(int i = 1; i <= m; i++)
    {
      scanf("%s", buf);
      ans += ac.query(buf, i);
    }
    printf("total: %d\n", ans);
  }
  return 0;
}
