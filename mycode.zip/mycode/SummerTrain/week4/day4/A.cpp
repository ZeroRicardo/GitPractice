#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <string.h>
#include <queue>
using namespace std;
struct Trie
{
  int next[500010][10], fail[500010],end[500010];
  int root, L;
  int newnode()
  {
    for(int i = 0; i < 10; i++)
      next[L][i] = -1;
    end[L++] = 0;
    return L - 1;
  }
  void init()
  {
    L = 0;
    root = newnode();
  }
  bool insert(char *buf)
  {
    bool flag = 1;
    int len = strlen(buf);
    int now = root;
    for(int i = 0; i < len; i++)
    {
      if(end[now] == 1)
        flag = 0;
      if(next[now][buf[i] - '0'] == -1)
        next[now][buf[i] - '0'] = newnode();
      now = next[now][buf[i] - '0'];
    }
    end[now]++;
    return flag;
  }
  void build()
  {
    queue<int> Q;
    fail[root] = root;
    for(int i = 0; i < 10; i++)
      if(next[root][i] == -1)
        next[root][i] = root;
      else
      {
        fail[next[root][i]] = root;
        Q.push(next[root][i]);
      }
    while(!Q.empty())
    {
      int now = Q.front();
      Q.pop();
      for(int i = 0;i < 10; i++)
        if(next[now][i] == -1)
          next[now][i] = next[fail[now]][i];
        else
        {
          fail[next[now][i]] = next[fail[now]][i];
          Q.push(next[now][i]);
        }
    }
  }
  void debug()
  {
    for(int i = 0; i < L; i++)
    {
      printf("id = %3d, fail = %3d, end = %3d, chi = [", i, fail[i], end[i]);
      for(int j = 0; j < 10; j++)
        printf("%2d", next[i][j]);
      printf("]\n");
    }
  }
};
struct BUF{
  char phone[11];
  int len;
  bool operator < (const BUF &x)const{
    return len < x.len;
  }
}buf[10010];
Trie ac;
int main()
{
  int T;
  int n;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d", &n);
    ac.init();
    bool flag = 1;
    for(int i = 0; i < n; i++)
    {
      scanf("%s", buf[i].phone);
      buf[i].len = strlen(buf[i].phone);
    }
    sort(buf, buf + n);
    for(int i = 0; i < n; i++)
    {
      if(!ac.insert(buf[i].phone))
        flag = 0;
    }
    ac.build();
  //  ac.debug();
    if(!flag) printf("NO\n");
    else printf("YES\n");
  }
  return 0;
}
