#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <string.h>
#include <queue>
using namespace std;
struct Trie
{
  int next[50010][26], fail[50010],end[50010];
  int root, L;
  int newnode()
  {
    for(int i = 0; i < 26; i++)
      next[L][i] = -1;
    end[L++] = 0;
    return L - 1;
  }
  void init()
  {
    L = 0;
    root = newnode();
  }
  void insert(char *buf)
  {
    int len = strlen(buf);
    int now = root;
    for(int i = 0; i < len; i++)
    {
      if(next[now][buf[i] - 'a'] == -1)
        next[now][buf[i] - 'a'] = newnode();
      now = next[now][buf[i] - 'a'];
    }
    end[now]++;
  }
  void build()
  {
    queue<int> Q;
    fail[root] = root;
    for(int i = 0; i < 26; i++)
      if(next[root][i] == -1)
        next[root][i] = root;
      else
      {
        fail[next[root][i]] = root;
        Q.push(next[root][i]);
      }
    while(!Q.empty())
    {
      int now = Q.front();
      Q.pop();
      for(int i = 0;i < 26; i++)
        if(next[now][i] == -1)
          next[now][i] = next[fail[now]][i];
        else
        {
          fail[next[now][i]] = next[fail[now]][i];
          Q.push(next[now][i]);
        }
    }
  }
  bool query(char *buf)
  {
  //  printf("%s\n", buf);
    int len = strlen(buf);
    int now = root;
    bool res = 0;
    for(int i = 0; i < len; i++)
    {
      now = next[now][buf[i] - 'a'];
      int temp = now;
      if(now == -1) break;
      if(i == len - 1 && end[temp]) res = 1;
    }
    return res;
  }
  void debug()
  {
    printf("\t\t\t\t\t");
    for(int i = 0; i < 26; i++)
      printf(" %c", i + 'a');
    printf("\n");
    for(int i = 0; i < L; i++)
    {
      printf("id = %3d, fail = %3d, end = %3d, chi = [", i, fail[i], end[i]);
      for(int j = 0; j < 26; j++)
        printf("%2d", next[i][j]);
      printf("]\n");
    }
  }
};
char IN[50010][50];
int n = 0;
struct gun{
  char word[50];
  bool operator < (const gun &x)const{
    return strcmp(word, x.word) <= 0;
  }
}OUT[50010];
int tot = 0;
Trie ac;
int main()
{
//  freopen("1.txt", "r", stdin);
  //freopen("out.txt", "w", stdout);
  ac.init();
  while(~scanf("%s", IN[n])){
    ac.insert(IN[n]);
    n++;
  }
  for(int i = 0; i < n; i++)
  {
  //  printf("%s\n", IN[i]);
    int len = strlen(IN[i]);
    char s1[50], s2[50];
    for(int j = 1; j < len; j++)
    {
      int k;
      for(k = 0; k < j; k++)
        s1[k] = IN[i][k];
      s1[k] = 0;
      for(; k < len; k++)
        s2[k - j] = IN[i][k];
      s2[k - j] = 0;
      if(ac.query(s1) && ac.query(s2))
      {
        strcpy(OUT[tot++].word, IN[i]);
        break;
      }
    }
  }
  sort(OUT, OUT + tot);
  for(int i = 0; i < tot; i++)
    printf("%s\n", OUT[i].word);
  return 0;
}
