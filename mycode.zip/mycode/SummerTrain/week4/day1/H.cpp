#include <bits/stdc++.h>
using namespace std;
#define LL long long
LL eularPhi(LL n)
{
    LL res=n;
    for(LL i=2;i*i<=n;i++)
    {
        if(n%i==0)
        {
            res=res/i*(i-1);
            for(;n%i==0;n/=i);
        }
    }
    if(n!=1) res=res/n*(n-1);
    return res;
}
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    LL N, M;
    LL ans = 0;
    cin >> N >> M;
    for(int i = 1;i * i <= N; i++)
    {
      if(N % i == 0)
      {
        if(i >= M) ans += eularPhi(N / i);
        if(N / i >= M && i * i != N) ans += eularPhi(i);
      }
   }
    cout << ans << endl;
  }
}
