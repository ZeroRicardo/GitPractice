#include <bits/stdc++.h>
using namespace std;
bool isprime(int n)
{
  for(int i = 2; i * i <= n; i++)
    if(n % i == 0)
      return 0;
  return 1;
}
void printlist()
{
  long long tmp;
  for(int i = 1; i <= 100; i++)
  {
    tmp = 1;
    for(int j = 1; j <= i - 1; j++)
      tmp = (tmp * j) % (i);
    cout << i << " " << tmp << endl;
  }
}
int main()
{
  int T;
//  printlist();
  scanf("%d", &T);
  while(T--)
  {
    int n;
    scanf("%d", &n);
    if(n == 4)
        printf("2\n");
    else
    {
      if(isprime(n))
        printf("%d\n", n - 1);
      else
        printf("0\n");
    }
  }
  return 0;
}
