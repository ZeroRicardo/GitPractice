#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
#define mod 1000000007
int prime[maxn], a[maxn];
map<int,int> mmp;
map<int, int>::iterator ite;
void GetPrime()
{
  memset(prime, 0, sizeof prime);
  for(int i = 2; i < maxn; i++)
  {
    if(!prime[i]) prime[++prime[0]] = i;
    for(int j = 1; j <= prime[0] && prime[j] <= maxn / i; j++)
    {
      prime[prime[j] * i] = 1;
      if(i % prime[j] == 0) break;
    }
  }
}
long long quick_pow(int a, int n)
{
  long long res = 1;
  while(n)
  {
    if(n % 2) res = (res * a) % mod;
    a = (a * a) % mod;
    n >>= 1;
  }
  return res;
}
int main()
{
  GetPrime();
  int T;
  cout << quick_pow(2, 1);
  scanf("%d", &T);
  for(int cas = 1; cas <= T; cas++)
  {
    mmp.clear();
    int n;
    int mina = 0x3f3f3f3f;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
    {
      scanf("%d", &a[i]);
      mina = min(mina, a[i]);
      mmp[a[i]]++;
    }
    long long ans = 0;
    for(int i = 1; prime[i] <= mina; i++)
    {
      long long tmp = 1;
      for(ite = mmp.begin(); ite != mmp.end(); ite++)
      {
        tmp = quick_pow(ite->first / prime[i], ite->second);
      }
        ans = (ans + tmp) % mod;
    }
    printf("Case #%d: %lld\n", cas, ans % mod);
  }
  return 0;
}
