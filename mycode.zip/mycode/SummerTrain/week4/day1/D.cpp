#include <bits/stdc++.h>
using namespace std;
#define LL long long
LL eularPhi(LL n, LL m)
{
    LL res=m;
    for(LL i=2; i * i <= n;i++)
    {
        if(n%i==0)
        {
            res = res/i*(i-1);
            for(;n%i==0;n/=i);
        }
    }
    if(n != 1 && res >= n)
      res = res / n * (n - 1);
    return res;
}
void debug()
{
  while(1)
  {
    LL n, m;
    cin >> n >> m;
    cout << eularPhi(n, m) << endl;
  }
}
int main()
{
//  ios::sync_with_stdio(false);
//  debug();
  int T;
  cin >> T;
  for(int cas = 1; cas <= T; cas++)
  {
    LL A, B, N;
    cin >> A >> B >> N;
    cout << "Case #" << cas << ": ";
    cout << eularPhi(N, B) - eularPhi(N, A - 1) << endl;
  }
}
