#include <cstdio>
#include <algorithm>
using namespace std;
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int N, M;
    scanf("%d%d", &N, &M);
    /*int u1, v1, w1, p1;
    scanf("%d%d%d%d", &u1, &v1, &w1, &p1);
    int u2 = u1, v2 = v1, w2 = w1, p2 = p1;
    bool flag = 1;
    for(int i = 2; i <= M; i++)
    {
      scanf("%d%d%d%d", &u2, &v2, &w2, &p2);
      if(flag)
      {
        u1 = max(u1, u2);
        v1 = max(v1, v2);
        w1 = min(w1, w2);
        p1 = min(p1, p2);
    //    printf("%d %d %d %d\n", u1, v1, w1, p1);
        if(u1 > w1 || v1 > p1)  flag = 0;
      }
    }*/
    long long ans = 0;
    for(int i = 1; i <= M; i++)
    {
      long long u, v, w, p;
      scanf("%lld%lld%lld%lld", &u, &v, &w, &p);
      ans = ans ^ ((w - u) * (p - v));
    }
    if(ans) printf("Yong Chol\n");
    else  printf("Brother\n");
  }
  return 0;
}
