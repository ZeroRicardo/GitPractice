#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <string>
using namespace std;
int a[200010], b[200010];
int da[200010], db[200010];
int f[200010];
void preKMP(int *x,int m,int *kmpNext)
{
  kmpNext[0] = kmpNext[1] = 0;
  for(int i = 1; i < m; i++)
  {
    int j = f[i];
    while(j && x[i]!=x[j])  j=kmpNext[j];
    if(x[i]==x[j])  kmpNext[i + 1]= j + 1;
    else  kmpNext[i + 1]= 0;
  }
}
int KMP_Count(int *x,int m,int *y,int n)
{
  int i,j;
  preKMP(x,m,f);
  j = 0;
  int ans = 0;
  for(i = 0; i < n; i++)
  {
    while(j && y[i]!=x[j]) j=f[j];
    if(x[j] == y[i]) j++;
    if(j>=m)
    {
      ans++;
      j=f[j];
    }
  }
  return ans;
}
int main()
{
  ios::sync_with_stdio(false);
  int m, n;
  cin >> n >> m;
  for(int i = 0; i < n; i++)
  {
    cin >> a[i];
  }
  for(int i = 0; i <= n - 1; i++)
    da[i] = a[i + 1] - a[i];
  for(int i = 0; i < m; i++)
  {
    cin >> b[i];
  }
  for(int i = 0; i <= m - 1; i++)
    db[i] = b[i + 1] - b[i];
  if(m >= 2)
    cout << KMP_Count(db, m - 1, da, n - 1) << endl;
  else
    cout << n << endl;

}
