#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int n;
  while(cin >> n)
  {
    if(n == 0)  break;
    if(n % 2 == 1)  cout << "ailyanlu" << endl;
    else  cout << "8600" << endl;
  }
  return 0;
}
