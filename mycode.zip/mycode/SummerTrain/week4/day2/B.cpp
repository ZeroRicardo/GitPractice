#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    long long ans = 0, N, t;
    cin >> N;
    for(int i = 1; i <= N; i++)
    {
      cin >> t;
      if(t % 4 == 1 || t % 4 == 2)
        ans = ans ^ t;
      else  if(t % 4 == 3)
        ans = ans ^ (t + 1);
      else
        ans = ans ^ (t - 1);
    }
    if(ans != 0)  cout << "Alice" << endl;
    else  cout << "Bob" << endl;
  }
  return 0;
}
