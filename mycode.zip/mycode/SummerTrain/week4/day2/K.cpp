#include <bits/stdc++.h>
using namespace std;
const int maxn = 1000010;
int f[1010];
int sg[1010];
int ash[1010];
void getSG(int n){
    memset(sg,0,sizeof(sg));
    for(int i = 1; i <= n; i++)
    {
        memset(ash,0,sizeof(ash));
        for(int j = 1; j <= i; j++)
            ash[sg[i-j]] = 1;
        for(int m = 1; m <= i; m++)
          for(int j = 1; m + j <= i; j++)
          {
            int k = i - m - j;
            if(k > 0)
              ash[sg[m] ^ sg[j] ^ sg[k]] = 1;
          }
        for(int j = 0; j <= n; j++)
        {
            if(ash[j] == 0)
            {
                sg[i] = j;
                cout << i << " " << sg[i] << endl;
                break;
            }
        }
    }
}
int main()
{
  //getSG(100);
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    int n;
    cin >> n;
    long long ans = 0, s;
    for(int i = 1; i <= n; i++)
    {
      cin >> s;
      if(s % 8 == 7)  ans = ans ^ (s + 1);
      else  if(s % 8 == 0)  ans = ans ^ (s - 1);
      else  ans = ans ^ s;
    }
    if(ans == 0)  cout << "Second player wins." << endl;
    else  cout << "First player wins." << endl;
  }
  return 0;
}
