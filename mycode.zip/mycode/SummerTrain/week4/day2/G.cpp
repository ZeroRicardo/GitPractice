#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
int f[20] = {0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024};
int sg[1010];
int ash[1010];
void getSG(int n)
{
  memset(sg, 0, sizeof sg);
  for(int i = 1; i <= n; i++)
  {
    memset(ash, 0, sizeof ash);
    for(int j = 1; f[j] <= i; j++)
      ash[sg[i - f[j]]] = 1;
    for(int j = 0; j <= n; j++)
      if(ash[j] == 0)
      {
        sg[i] = j;
        break;
      }
  }
}
void debug(int n)
{
  for(int i = 0; i <= n; i++)
    cout << i << " " << sg[i] << endl;
}
int main()
{
  ios::sync_with_stdio(false);
  int n;
  while(cin >> n)
  {
    getSG(n);
  //  debug(n);
    if(sg[n] != 0)  cout << "Kiki" << endl;
    else  cout << "Cici" << endl;
  }
  return 0;

}
