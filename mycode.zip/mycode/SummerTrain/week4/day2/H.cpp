#include <bits/stdc++.h>
using namespace std;
int main()
{
  int a, b;
  while(cin >> a >> b)
  {
    if(a == 0 && b == 0)  break;
    int win = 0;
    while(1)
    {
      if(a < b) swap(a, b);
      if(b == 0 || a % b == 0 || a > 2 * b) break;
      win = win ^ 1;
      a = a - b;
    }
    if(!win) cout << "Stan wins" << endl;
    else cout << "Ollie wins" << endl;
  }
  return 0;
}
