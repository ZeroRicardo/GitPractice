#include <iostream>
#include <cstdio>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  for(int cas = 1; cas <= T; cas++)
  {
    int n, k;
    cin >> n >> k;
    int flag = 0;
    if(k >= n)
      flag = 1;
    else  if(k != 1)
      flag = -1;
    else  if(n % 2 == 0)
      flag = -1;
    else  if(n % 2 == 1)
      flag = 1;
    cout << "Case " << cas << ": ";
    if(flag > 0)
      cout << "first" << endl;
    else  if(flag < 0)
      cout << "second" << endl;
  }
  return 0;
}
