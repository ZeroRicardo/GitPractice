#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int a, b;
  while(cin >> a >> b)
  {
    if(a == 0 && b == 0)  break;
    if(a < b) swap(a, b);
    if((a - b) % 2 == 0 && b % 2 == 1)  cout << "What a pity!" << endl;
    else  cout << "Wonderful!" << endl;
  }
  return 0;
}
