#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
unsigned long long F[100];
int main()
{
  unsigned long long n;
  F[0] = F[1] = 1;
  for(int i = 2; i <= 120; i++)
  {
    F[i] = F[i - 1] + F[i - 2];
  //  cout << i << " " << F[i] << endl;
  }
  while(cin >> n)
  {
    if(n == 0)  break;
    int flag = !(upper_bound(F, F + 91, n) - lower_bound(F, F + 91, n));
    if(!flag)  cout << "Second win" << endl;
    else  cout << "First win"  << endl;
  }
  return 0;
}
