#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int a, b, k;
  while(cin >> a >> b)
  {
    if(a < b) swap(a, b);
    k = a - b;
  //  cout << k * (1 + sqrt(5.0)) / 2;
    if(b == (int)(k * (1 + sqrt(5.0)) / 2))
      cout << "0" << endl;
    else
      cout << "1" << endl;
  }
  return 0;
}
