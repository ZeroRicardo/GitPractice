#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAXN = 200010;
int Ma[MAXN * 2];
int Mp[MAXN * 2];
int s[MAXN];
int l;
void Manacher(int *s, int len)
{
  l = 0;
  Ma[l++] = 251;
  Ma[l++] = 0;
  for(int i = 0; i < len; i++)
  {
    Ma[l++] = s[i];
    Ma[l++] = 0;
  }
  Ma[l] = 0;
  int mx = 0, id = 0;
  for(int i = 0; i < l; i++)
  {
    Mp[i] = mx > i ? min(Mp[2 * id - i], mx - i) : 1;
    while(Ma[i + Mp[i]] == Ma[i - Mp[i]] && Ma[i - Mp[i] + 2] >= Ma[i - Mp[i]]) Mp[i]++;
    if(i + Mp[i] > mx)
    {
      mx = i + Mp[i];
      id = i;
    }
  }
}

int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    int n;
    cin >> n;
    for(int i = 0; i < n; i++)
      cin >> s[i];
    memset(Mp, 0, sizeof Mp);
    Manacher(s, n);
    int ans = 0;
    for(int i = 0; i <= l; i++)
    {
  //    cout << Ma[i] << ": " << Mp[i] << " ";
      ans = max(ans, Mp[i] - 1);
    }
  //  cout << endl;
    cout << ans << endl;
  }
  return 0;
}
