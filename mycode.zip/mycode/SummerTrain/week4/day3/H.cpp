#include <iostream>
#include <cstring>
#include <cstdio>
#include <ctype.h>
#include <cmath>
#include <set>
#include <stack>
#include <queue>
#include <algorithm>
using namespace std;
#define MAX_N 1000010
#define pii pair<long long, long long>
#define mp make_pair
char s[MAX_N];
const long long B = 131;
const long long A = 223;
const long long mod = 1e9 + 7;
set<pii> hashlist;
set<pii>::iterator ite;
long long preA[MAX_N];
long long preB[MAX_N];
void init()
{
  hashlist.clear();
  preA[0] = preB[0] = 1;
  for(int i = 1; i < MAX_N; i++)
    {
      preA[i] = (preA[i - 1] * A) % mod;
      preB[i] = (preB[i - 1] * B) % mod;
    }
  //cout << pre[MAX_N - 1] << endl;
}
int main()
{
  ios::sync_with_stdio(false);
  init();
  int n, m;
  cin >> n >> m;
  for(int i = 0; i < n; i++)
  {
    cin >> s;
    int len = strlen(s);
    long long sumA = 0, sumB = 0;
    for(int i = 0; i < len; i++)
    {
      sumB = (sumB * B + s[i] - 'a' + 1) % mod;
      sumA = (sumA * A + s[i] - 'a' + 1) % mod;
    }
    hashlist.insert(mp(sumA, sumB));
  }
  for(int i = 0; i < m; i++)
  {
    cin >> s;
    int len = strlen(s);
    long long sumA = 0, sumB = 0;
    for(int j = 0; j < len; j++)
    {
      sumB = (sumB * B + s[j] - 'a' + 1) % mod;
      sumA = (sumA * A + s[j] - 'a' + 1) % mod;
    }
    bool flag = 0;
    long long ckA, ckB;
    for(int j = 0; j < len; j++)
      for(int cg = 1; cg <= 3; cg++)
      {
        if(cg == s[j] - 'a' + 1)  continue;
        ckA = ((sumA + (cg - s[j] + 'a' - 1) * preA[len - 1 - j]) % mod + mod) % mod;
        ckB = ((sumB + (cg - s[j] + 'a' - 1) * preB[len - 1 - j]) % mod + mod) % mod;
    //    cout << j << " " << len << " " << ck << endl;
        ite = hashlist.find(mp(ckA, ckB));
        if(ite != hashlist.end())
        {
          flag = 1;
          cout << "YES" << endl;
          goto gun;
        }
      }
      gun:
      if(!flag) cout << "NO" << endl;
  }
  return 0;
}
