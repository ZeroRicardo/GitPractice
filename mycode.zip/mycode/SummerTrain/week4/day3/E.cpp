#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAXN = 210010;
char Ma[MAXN * 2];
int Mp[MAXN * 2];
char s[MAXN];
int len;
void Manacher()
{
  int l = 0;
  Ma[l++] = '$';
  Ma[l++] = '#';
  for(int i = 0; i < len; i++)
  {
    Ma[l++] = s[i];
    Ma[l++] = '#';
  }
  Ma[l] = 0;
  int mx = 0, id = 0;
  for(int i = 0; i < l; i++)
  {
    Mp[i] = mx > i ? min(Mp[2 * id - i], mx - i) : 1;
    while(Ma[i + Mp[i]] == Ma[i - Mp[i]]) Mp[i]++;
    if(i + Mp[i] > mx)
    {
      mx = i + Mp[i];
      id = i;
    }
  }
}

int main()
{
  while(scanf("%s", s) == 1)
  {
    len = strlen(s);
    Manacher();
    int ans = 0;
    for(int i = 0; Ma[i]; i++)
      ans = max(ans, Mp[i] - 1);
    printf("%d\n", ans);
  }
  return 0;
}
