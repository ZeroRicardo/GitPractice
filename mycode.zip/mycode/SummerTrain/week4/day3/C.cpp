#include <bits/stdc++.h>
using namespace std;
#define maxn 200010
char str1[maxn], str2[maxn];
int f[maxn];
long long cnt[maxn];
const int mod = 10007;
void Reverse()
{
  int l = 0, r = strlen(str1) - 1;
  while(l < r)
  {
    swap(str1[l], str1[r]);
    l++, r--;
  }
  l = 0, r = strlen(str2) - 1;
  while(l < r)
  {
    swap(str2[l], str2[r]);
    l++, r--;
  }
}
void preKMP(char *x,int m,int *kmpNext)
{
  kmpNext[0] = kmpNext[1] = 0;
  for(int i = 1; i < m; i++)
  {
    int j = f[i];
    while(j && x[i]!=x[j])  j=kmpNext[j];
    if(x[i]==x[j])  kmpNext[i + 1]= j + 1;
    else  kmpNext[i + 1]= 0;
  }
}
/*
* 返回x在y中出现的次数，可以重叠
*/
void KMP_Count(char *x,int m,char *y,int n)
{//x是模式串，y是主串
  int i,j;
  preKMP(x,m,f);
  j = 0;
  for(i = 0; i < n; i++)
  {
    while(j && y[i]!=x[j]) j=f[j];
    if(x[j] == y[i]) j++;
    cnt[j]++;
    if(j>=m)
    {
      j=f[j];
    }
  }
}
void PrintF()
{

  for(int i = 1; str2[i - 1]; i++)
  {
    cout << f[i - 1] << " ";
  }
  cout << endl;
}
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    int n;
    cin >> n;
    cin >> str1;
    strcpy(str2, str1);
    int len1 = strlen(str1), len2 = strlen(str2);
    memset(cnt, 0, sizeof cnt);
    KMP_Count(str2, len2, str1, len1);
//    cout << "&&&" << endl;
    long long ans = 0;
    for(int i = len2; i >= 1; i--)
      cnt[f[i]] += cnt[i];
  //  PrintF();
    for(long long i = 1; i <= len2; i++)
      ans = ((ans % mod) +  (cnt[i]) % mod) % mod;
    cout << ans  << endl;
  }
  return 0;
}
