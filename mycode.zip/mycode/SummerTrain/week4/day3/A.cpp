#include <iostream>
#include <cstring>
#include <cstdio>
#include <ctype.h>
#include <cmath>
#include <stack>
#include <queue>
#include <algorithm>
using namespace std;
#define MAX_N 1000010
#define MAX_M 10010
char a[MAX_M], b[MAX_N];
int M, N;
const long long B = 100000007;
int ans;
int solve()
{
  M = strlen(a + 1);
  N = strlen(b + 1);
	if(M > N)
		return -1;
	long long t = 1;
	for(int i = 1;i <= M; i++) t *= B;
	long long ah = 0, bh = 0;
	for(int i = 1;i <= M; i++)
	{
		bh = bh * B + a[i];
		ah = ah * B + b[i];
	}
	for(int i = 1; i + M <= N + 1; i++)
	{
		if(ah == bh)
	  ans++;
		if(i + M < N + 1)
			ah = ah * B + b[i + M] - b[i] * t;
	}
	return ans;
}
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    cin >> a + 1;
    cin >> b + 1;
    ans = 0;
    solve();
    cout << ans << endl;
  }
}
