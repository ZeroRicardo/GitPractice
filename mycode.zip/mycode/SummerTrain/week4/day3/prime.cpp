#include <stdio.h>
#include <cmath>
#include <bits/stdc++.h>
using namespace std;
long long a[10];
bool isprime(long long x)
{
  if(x <= 1)
    return 0;
  for(long long i = 2; i * i <= x; i++)
    if(x % i == 0)
      return 0;
  return 1;
}
long long gcd(long long a, long long b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int main()
{
  for(long long i = 2e9 + 8;; i++)
    if(isprime(i))
    {
      printf("%d\n", i);
      break;
    }
}
