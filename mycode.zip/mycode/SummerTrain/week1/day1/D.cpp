#include <bits/stdc++.h>
using namespace std;
struct P{
  int x, y;
  P(int _x, int _y):x(_x), y(_y){}
  bool operator < (const P &p)const{
    return x == p.x ? y < p.y : x < p.x;
  }
};
multiset<P> s;
multiset<P>::reverse_iterator ite;
int x[1010], y[1010];
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    s.clear();
    int n;
    cin >> n;
    int ans = 0;
    for(int i = 1; i <= n; i++)
      cin >> x[i];
    for(int i = 1; i <= n; i++)
    {
      cin >> y[i];
      ans += y[i];
    }
    for(int i = 1; i <= n; i++)
      s.insert(P(x[i], y[i]));
    /*for(ite = s.begin(); ite != s.end(); ite++)
      cout << ite->first << " " << ite->second << endl;*/

  }
}
