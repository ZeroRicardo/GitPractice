#include <bits/stdc++.h>

using namespace std;
#define MAX_N 2010
multis
int main() {

  int n;
  while(~scanf("%d", &n))
  {
    char c, s[30];
    int pro, no;
    HEAP doc[3];
    struct Pai tmp;
    int tot = 0;
    for(int i = 0; i < n; i++)
    {
      scanf(" %c", &c);
      if(c == 'I')
      {
        scanf(" %s %d %d", s, no, pro);
        printf("%d %d\n", no, pro)

      }
      else if(c == 'O')
      {
        scanf(" %s %d", s, no);

        }
      }
    }
  }
  return 0;
}
