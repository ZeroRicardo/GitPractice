#include <bits/stdc++.h>

using namespace std;
char s[1010];
int main()
{
  while(~scanf(" %s", s))
  {
    int len = strlen(s);
    int ans = 0;
    for(int i = 0; i < len ; i++)
    {
      if(s[i] == '(')
        ans++;
      else if(s[i] == ')')
        ans--;
      else if(s[i] == 'B')
        break;
    }
    printf("%d\n", ans);
  }
}
