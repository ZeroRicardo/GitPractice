#include <bits/stdc++.h>

using namespace std;
char str1[20], str2[20];
int vis[40];
int main()
{
    int n;
    while(~scanf("%d", &n))
    {
      memset(vis, 0, sizeof(vis));
      scanf(" %s %s", str1, str2);
      stack<char> sta;

      int tot = 0, j = 0;
      for(int i = 0; i < n; i++)
      {
        sta.push(str1[i]);
        vis[tot++] = 1;
        while(!sta.empty() && sta.top() == str2[j])
        {
          vis[tot++] = -1;
          sta.pop();
          j++;
        }
      }
      while(!sta.empty())
      {
        vis[tot++] = -1;
        sta.pop();
      }
      if(j < n - 1)
        printf("No.\nFINISH\n");
      else
      {
        printf("Yes.\n");
        for(int i = 0; i < tot; i++)
        {
          if(vis[i] == 1) printf("in\n");
          else  printf("out\n");
        }
      }
    }
}
