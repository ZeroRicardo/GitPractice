#include <bits/stdc++.h>

using namespace std;
char str[1000];
 int main(){
   while(1)
   {
     gets(str);
     if(strlen(str) == 1 && str[0] == '0')
      break;
    double ans = 0;
    char op = '+';
    stack<char> s;
    stack<double> a;
    s.push(op);
    a.push(0);
    int len = strlen(str);
    for(int i = 0; i < len; i++)
    {
      if(isdigit(str[i]))
      {
        int num = 0;
        while(i < len && isdigit(str[i]))
        {
          num *= 10;
          num += str[i] - '0';
          i++;
        }
        a.push(num);
        if(op == '*')
        {
          double numa = a.top();
          a.pop();
          double numb = a.top();
          a.pop();
          a.push(numa * numb);
    //      printf("%.2f\n", numa * numb);
          s.pop();
      //    op = s.top();
        }

        else if(op == '/')
        {
          double numa = a.top();
          a.pop();
          double numb = a.top();
          a.pop();
          a.push(numb / numa);
  //        printf("%.2f\n", numb / numa);
          s.pop();
        //  op = s.top();
        }
        else if(op == '-')
        {
          double numa = -a.top();
          a.pop();
          a.push(numa);
          s.pop();
          s.push('+');
        }
        i--;
      }
      else if(isspace(str[i]))  continue;
      else
      {
        s.push(str[i]);
        op = str[i];
      //  printf("%c\n", op);
      }
    }
    while(a.size() > 1)
    {
  //    printf("%.2f\n", a.top());
      double numa = a.top();
      a.pop();
      double numb = a.top();
      a.pop();
      op = s.top();
      s.pop();
        a.push(numb + numa);

    }
    ans = a.top(); a.pop();
    printf("%.2f\n", ans);
   }

}
