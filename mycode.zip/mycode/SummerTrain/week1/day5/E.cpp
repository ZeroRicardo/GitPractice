#include <bits/stdc++.h>

using namespace std;

int main()
{
  int n, m, k;
  while(~scanf("%d%d%d", &n, &m, &k))
  {
    for (int i = 0; i < n; i++) {
      scanf("%d", &a[i]);
    }
    int maxp = 0, minp = 0, ans = 0;
    for(int i = 0; i < n; i++)
    {

    }
  }
}
