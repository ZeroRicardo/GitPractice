#include <bits/stdc++.h>

using namespace std;
int A[100010];
int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int n, k;
    scanf("%d%d", &n, &k);
    bool flag = 0;
    int st = 1, ansst = 1, ansend = 1, ans = 0, maxt = -2000;
    for(int i = 1; i <= n; i++)
    {
      scanf("%d", &A[i]);
      if(A[i] > 0)  flag = 1;
      if(maxt < A[i])
      {
        maxt = A[i];
        ansst = ansend = i;
      }
    }
    if(!flag)
    {
      ans = maxt;
      printf("%d %d %d\n", ans, ansst, ansend);
    }
    else{
      st = 1;
      int sum = 0, len = 0;
      while(st <= n)
      {

        if(len > k)
        {
          sum -=  A[st];
          st++;
          len--;
        }
        if(sum > ans)
        {
          ans = sum;
          ansst = st;
          printf("%d %d %d\n", ans, st, len);
          ansend = (st + len) % n - 1;

        }
        if(sum < 0)
        {
          st = st + len + 1;
          len = 0;
          sum = 0;
        }

        sum += A[(st + len - 1) % n + 1];
        len++;

      }
      printf("%d %d %d\n", ans, ansst, ansend);
    }
  }
}
