#include <bits/stdc++.h>

using namespace std;
char maze[110][110];
bool sawD[110][110];
bool sawE[110][110];
int tim[110][110];
bool finD[110][110];
bool finE[110][110];
bool vis[110][110][2][2];
int stx, sty, Dx, Dy, Ex, Ey;
int dx[4] = {0, 1, 0 , -1}, dy[4] = {1, 0, -1, 0};
bool flag1 = 0, flag2 = 0;
int n, m, t;
void pre()
{
  for(int i = 0; i < 4; i++)
  {
    int mx = Dx + dx[i], my = Dy + dy[i];
    while(0 <= mx && mx < n && 0 <= my && my < m && (maze[mx][my] == '.' || maze[mx][my] == 'S'))
    {
      sawD[mx][my] = 1;
      if(maze[mx][my] == 'S')  break;
      mx += dx[i];
      my += dy[i];

    }
    mx = Ex + dx[i], my = Ey + dy[i];
    while(0 <= mx && mx < n && 0 <= my && my < m && (maze[mx][my] == '.' || maze[mx][my] == 'S'))
    {
      sawE[mx][my] = 1;
      if(maze[mx][my] == 'S')  break;
      mx += dx[i];
      my += dy[i];


    }
  }
}
int main()
{
  int T;
  scanf("%d", &T);
  for(int cas = 1; cas <= T; cas++){
    memset(sawD, 0, sizeof(sawD));
    memset(sawE, 0, sizeof(sawE));
    memset(tim, -1, sizeof(tim));
    memset(finE, 0, sizeof(finE));
    memset(finD, 0, sizeof(finD));
    memset(vis, 0, sizeof(vis));
    scanf("%d%d%d", &n, &m, &t);
        for(int i = 0; i < n; i++)
          for(int j = 0; j < m; j++)
          {
            scanf(" %c", &maze[i][j]);
            if(maze[i][j] == 'S')
            {
              stx = i;
              sty = j;
            }
            if(maze[i][j] == 'D')
            {
              Dx = i;
              Dy = j;
            }
            if(maze[i][j] == 'E')
            {
              Ex = i;
              Ey = j;
            }
          }
          pre();
          /*for(int i = 0; i < n; i++){
            for(int j = 0; j < m; j++)
            {
              printf("%d  ", sawD[i][j]);
            }
            printf("\n");
          }*/
          queue<pair<int, int> > q;
          tim[stx][sty] = t;
          //vis[stx][sty] = 1;
          if(sawD[stx][sty])
            finD[stx][sty] = 1;
          if(sawE[stx][sty])
            finE[stx][sty] = 1;
          vis[stx][sty][finD[stx][sty]][finE[stx][sty]] = 1;
          q.push(make_pair(stx, sty));
          bool flag = 0;
          int ans;
          while(!q.empty())
          {
            pair<int, int> tmp;
            tmp = q.front();
            int x = tmp.first, y = tmp.second;
            q.pop();

            //vis[x][y][finD[x][y]][finE[x][y]] = 1;
            printf("%d %d %d %d %d\n", x, y, tim[x][y], finD[x][y], finE[x][y]);
            if(finD[x][y] && finE[x][y])
            {
              flag = 1;
              ans = tim[x][y];
              break;
            }
            if(tim[x][y] <= 0)
              continue;
            for(int i = 0; i < 4; i++)
            {
              int mx = x + dx[i], my = y + dy[i];
              if(0 <= mx && mx < n && 0 <= my && my < m && (maze[mx][my] == '.' || maze[mx][my] == 'S'))
              {

                if(sawD[mx][my])
                  finD[mx][my] = 1;
                if(sawE[mx][my])
                  finE[mx][my] = 1;

                bool tmpD = finD[mx][my], tmpE = finE[mx][my];
                if(finD[x][y])
                  finD[mx][my] = 1;
                if(finE[x][y])
                  finE[mx][my] = 1;
                if(!vis[mx][my][finD[mx][my]][finE[mx][my]])
                {
                  tim[mx][my] = tim[x][y] - 1;
                  vis[mx][my][finD[mx][my]][finE[mx][my]] = 1;
                  printf("%d %d %d %d %d\n", mx, my, tim[mx][my], finD[mx][my], finE[mx][my]);
                  q.push(make_pair(mx, my));
                }

              }
            }
      //      cout << endl;
          }
          printf("Case %d:\n", cas);
          if(flag)
            printf("%d\n", t - ans);
          else
            printf("%d\n", -1);
  }
}
/*
3
5 6 3
XXD...
....E.
....X.
....S.
......
5 6 3
XDX...
....E.
......
....S.
......
5 6 8
XXDX..
.XEX..
......
....S.
......
*/
