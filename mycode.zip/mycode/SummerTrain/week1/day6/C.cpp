#include <bits/stdc++.h>

using namespace std;
int a[10010];
int main()
{
  int n;

  while(~scanf("%d", &n)){
    if(n == 0)  break;
    bool flag = 0;
    int st, ed, ans, sum = 0, maxt = -0x3f3f3f3f;
    for (int i = 0; i < n; i++) {
      scanf("%d", &a[i]);
      if(a[i] > 0){
        flag = 1;
      }
      if(maxt < a[i])
      {
        maxt = a[i];
        st = a[i];
        ed = a[i];
      }
    }
    if(flag)
    {
      sum = 0, ans = 0;
      int tmpst = a[0], tmped;
      for(int i = 0; i < n; i++)
      {
        sum += a[i];
        tmped = a[i];
        if(sum < 0)
        {
          sum = 0;
          tmpst = a[i + 1];
        }
        if(sum > ans)
        {
          ans = sum;
          st = tmpst;
          ed = tmped;
        }
      }
      printf("%d %d %d\n", ans, st, ed);
    }
    else{
      if(maxt == 0) printf("0 0 0\n");
      else{
        st = a[0], ed = a[n - 1];
        printf("0 %d %d\n", st, ed);
      }
    }
  }
}
