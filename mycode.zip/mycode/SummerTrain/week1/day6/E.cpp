#include <bits/stdc++.h>

using namespace std;
#define MAX_N 1000000
int a[MAX_N + 10], pre[MAX_N + 10];
long long n, m, w;
bool check(int mid)
{
  long long tot = 0;
  memset(pre, 0, sizeof(pre));
  for(int i = 0; i < n; i++)
  {
    if(i >= 1)  pre[i] += pre[i - 1];
    int tmp = mid - a[i] - pre[i];
    if(tmp > 0)
    {
      tot += tmp;
      //if(tot > m)  return 0;
      pre[i] += tmp;
      pre[i + w] -= tmp;
    }
  }
//  return 1;
  return tot <= m;
}
int main()
{
  scanf("%lld%lld%lld", &n, &m, &w);
  int low = 0x3f3f3f3f, high = 0, mid;
  for(int i = 0; i < n; i++){
    scanf("%d", &a[i]);
    low = min(low, a[i]);
    high = max(high, a[i]);
  }
  high += m;
  while(low < high)
  {
    mid = (low + high + 1) / 2;
    if(check(mid))  low = mid;
    else  high = mid - 1;
  }
  printf("%d\n", low);

}
