#include <stdio.h>
#include <math.h>
#include <string.h>
using namespace std;
double mat[300][300];
double dp[150][150][150];
double dfs(int st, int ed, int winner)
{
  if(dp[st][ed][winner])  return dp[st][ed][winner];
  if(ed - st == 1){
    if(winner == st){
      dp[st][ed][winner] = mat[st][ed];
  //    printf("%d %d %d %f\n", st, ed, winner, dp[st][ed][winner]);
      return dp[st][ed][winner];
    }
    else
    {
      dp[st][ed][winner] = mat[ed][st];
  //    printf("%d %d %d %f\n", st, ed, winner, dp[st][ed][winner]);
      return dp[st][ed][winner];
    }
  }
  else
  {
  //  double ret = 0;
    int mid = (st + ed) / 2;
    if(winner <= mid){

      for(int i = mid + 1; i <= ed; i++)
        dp[st][ed][winner] += dfs(st, mid, winner) * dfs(mid + 1, ed, i) * mat[winner][i];
    }
    else
    {
      double ret = 0;
      for(int i = st; i <= mid; i++)
        dp[st][ed][winner] += dfs(st, mid, i) * dfs(mid + 1, ed, winner) * mat[winner][i];
    }
  //  printf("%d %d %d %f\n", st, ed, winner, dp[st][ed][winner]);
    return dp[st][ed][winner];
  }
}
int main()
{
  int n;
  while(~scanf("%d", &n)){
    memset(dp, 0, sizeof(dp));
    if(n == -1) break;
    int tot = pow(2, n);
    for(int i = 1; i <= tot; i++)
      for(int j = 1; j <= tot; j++)
        scanf("%lf", &mat[i][j]);
    double maxp = 0;
    int ans;
    for(int i = 1; i <= tot; i++)
    {
      double tmp = dfs(1, tot, i);
    //  printf("%f\n", tmp);
      if(maxp < tmp)
      {
        maxp = tmp;
        ans = i;
      }
    }
    printf("%d\n", ans);
  }
}
