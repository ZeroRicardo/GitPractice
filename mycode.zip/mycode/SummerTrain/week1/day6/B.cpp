#include <bits/stdc++.h>

using namespace std;
long long dfs(long long ed, int n)
{
//  printf("%lld %d\n", ed, n);
  long long mid = pow(2, n - 1);
  if(ed == 0) return 0;
  else  if(ed == 1) return 1;
  if(ed == mid * 2 - 1) return mid;
  else  if(ed < mid)  return dfs(ed, n - 1);
  else  if(ed == mid) return dfs(ed - 1, n - 1) + 1;
  else  if(ed > mid)  return mid - 2 * mid + 1 + ed + dfs(2 * mid - 1- ed, n - 1);
}

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    long long L, R;
    scanf("%lld%lld", &L, &R);
    printf("%lld\n", dfs(R, 63) - dfs(L - 1, 63));
  }
}
