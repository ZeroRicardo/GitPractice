#include <bits/stdc++.h>

using namespace std;
#define MAX_N 100000
const int NOD = 1e9;
struct node{
  int id, val;
  bool operator < (struct node &t) const{
    return val < t.val;
  }
}P[maxn + 10];
set<node> PP;
bool b[maxn + 10];
int main()
{
  int n, a, b;
  scanf("%d%d%d", &n, &a, &b);
  for(int i = 0; i < n; i++)
  {
    scanf("%d", &P[i].val);
    P[i].id = i;
    PP.insert(P[i]);
  }
//  sort(P, P + n);
  for(int i = 0; i < n; i++)
  {
    struct node *p1, *p2, *p3, *p4;

    if(lower_bound(p, )
  }
}
