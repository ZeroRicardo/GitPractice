#include <stdio.h>

using namespace std;
long long quick_pow2(long long x,long long t,long long MOD){
	long long ret=1;
		while(t){
			if(t%2)ret=ret*x%MOD;
			x=x*x%MOD;
			t>>=1;
		}
		return ret;
}

bool isprime(long long p)
{
  for(int i = 2; i * i <= p; i++)
    if(p % i == 0)
      return 0;
  return 1;
}
int main()
{
  long long a, p;
  while(1){
    scanf("%lld%lld", &p, &a);
    if(a == 0 && p == 0)  break;
    if(!isprime(p) && (quick_pow2(a, p, p) == a % p))
      printf("yes\n");
    else
      printf("no\n");
    }
}
