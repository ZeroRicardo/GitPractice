#include <stdio.h>
#include <string.h>
#include <map>
using namespace std;
map<int, int> mmp;
char s[100010];
int main()
{
  int n, num;

//  memset(cnt, 0, sizeof(cnt));
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
  {
    num = 0;
    scanf(" %s", s);
//    printf("%d\n", num);
    for(int i = 0; s[i]; i++)
    {
      if('0' <= s[i] && s[i] <= '9')
      {
  //      printf("%d\n", num);
        num *= 10;
        num += s[i] - '0';
      }
      else if(s[i] == 'A' || s[i] == 'B' || s[i] == 'C')
      {
        num *= 10;
        num += 2;
      }
      else if(s[i] == 'D' || s[i] == 'E' || s[i] == 'F')
      {
        num *= 10;
        num += 3;
      }
      else if(s[i] == 'G' || s[i] == 'H' || s[i] == 'I')
      {
        num *= 10;
        num += 4;
      }
      else if(s[i] == 'J' || s[i] == 'K' || s[i] == 'L')
      {
        num *= 10;
        num += 5;
      }
      else if(s[i] == 'M' || s[i] == 'N' || s[i] == 'O')
      {
        num *= 10;
        num += 6;
      }
      else if(s[i] == 'P' || s[i] == 'R' || s[i] == 'S')
      {
        num *= 10;
        num += 7;
      }
      else if(s[i] == 'T' || s[i] == 'U' || s[i] == 'V')
      {
        num *= 10;
        num += 8;
      }
      else if(s[i] == 'W' || s[i] == 'X' || s[i] == 'Y')
      {
        num *= 10;
        num += 9;
      }
    }
//    printf("%d\n", num);
    mmp[num]++;
  }
  map<int, int>::iterator ite;
  bool flag = 0;
  for(ite = mmp.begin(); ite != mmp.end(); ite++)
  {
      if((*ite).second > 1)
      {
        flag = 1;
        int numa  = (*ite).first / 10000, numb = (*ite).first % 10000;
        printf("%03d-%04d %d\n", numa, numb, (*ite).second);
      }
  }
  if(!flag)
    printf("No duplicates.\n");


}
