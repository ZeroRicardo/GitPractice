#include <stdio.h>
#include <algorithm>
using namespace std;
int A[500010];
int tmp[500010];

//long long b[500010];


long long ans;
void mergesort(int *a,int l,int r){
	int mid=(l+r)/2,i,j,k;
	if(l<mid)mergesort(a,l,mid);
	if(mid+1<r)mergesort(a,mid+1,r);
	i=l;j=mid+1;k=l;
	bool flag = 1;
	while(i<=mid || j<=r){
		if(j>r)tmp[k++]=a[i++];
		else if(i>mid)tmp[k++]=a[j++];
		else if(a[i]<=a[j])
		{
			tmp[k++]=a[i++];
		}
		else {
			tmp[k++]=a[j++];
			ans += mid - i + 1;
		}

	}

	for(int i=l;i<=r;i++)a[i]=tmp[i];
}

int main()
{
  int n;

    while(~scanf("%d", &n)){
    if(n == 0)  break;
    for(int i = 0; i < n; i++)
    {
      scanf("%d", &A[i]);
    }
    ans = 0;
		mergesort(A, 0, n - 1);
//    for(int i = 0; i < n; i++)
  //    printf("%d\n", A[i]);
    printf("%lld\n", ans);
  }
}
