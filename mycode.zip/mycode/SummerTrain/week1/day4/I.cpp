#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAX_N = 50010;
int Tree[MAX_N];
int lowbit(int x){
	return x & -x;
}
void add(int x, int val){
	for(int i = x; i < MAX_N; i += lowbit(i))
		Tree[i] += val;
}
int get(int x){
	int ret = 0;
	for(int i = x; i; i -= lowbit(i))
		ret += Tree[i];
	return ret;
}
int a[MAX_N], b[MAX_N], c[MAX_N];
void Print(int n)
{
	for(int i = 1; i <= n; i++)
		printf("%d ", b[i]);
	printf("\n");
	for(int i = 1; i <= n; i++)
		printf("%d ", c[i]);
	printf("\n");
}
int main()
{
	int n;
	while(~scanf("%d", &n)&&n)
	{
		for(int i = 1;i <= n; i++)
		{
			scanf("%d", &a[i]);
		}
		memset(Tree, 0, sizeof Tree);
		for(int i = 1; i <= n; i++)
		{
			b[i] = get(a[i] - 1);
		//	printf("%d ", b[i]);
			add(a[i], 1);
		}
		//printf("\n");
		for(int i = 1, j = n; i < j; i++, j--)
			swap(a[i], a[j]);
		memset(Tree, 0, sizeof Tree);
		for(int i = 1; i <= n; i++)
		{
			c[n - i + 1] = get(a[i] - 1);
			add(a[i], 1);
		}
		//Print(n);
		long long ans = 0;
		for(int i = 1; i <= n; i++)
			ans += (long long)b[i] * c[i];
		printf("%lld\n", ans);
	}
	return 0;
}
