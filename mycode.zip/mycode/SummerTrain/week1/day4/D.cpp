#include <bits/stdc++.h>

using namespace std;
int a[5010];
int mysum(int low, int high)
{
  int mid = (low + high) / 2;
  if(low == high) return a[low];
  return mysum(low, mid) + mymin(mid + 1, high);
}
int mymin(int low, int high)
{
  int mid = (low + high) / 2;
  if(low == high) return a[low];
  return min(mymin(low, mid) + mymin(mid + 1, high));
}
int solve(int low, int high)
{
  int mid = (low + high) / 2;
  int ans = 1000000000;
  ans = min(sum(mylow, high) - (high - low + 1) * mymin(low, high), high - low + 1);
}

int main()
{
  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
    scanf("%d", &a[i]);
  ans = solve(0, n - 1);
}
