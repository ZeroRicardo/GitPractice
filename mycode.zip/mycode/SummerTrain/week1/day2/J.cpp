#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;

const int mod = 500003;
bool vis[mod], Vis[mod];
int lis[mod];
int pre[mod];
int sta[mod];
char mov[5] = "lrud";
int cat[] = {1,1,2,6,24,120,720,5040,40320,362880};
//康托展开
int gethash(int x)
{
  int s[10];
  int t = x;
  for(int i = 0; i < 9; i++)
  {
    s[i] = x % 10;
    x /= 10;
  }
  int sum=0;
    for(int i=0;i<9;i++)
    {
        int num=0;
        for(int j=i+1;j<9;j++)
          if(s[j]<s[i])num++;
        sum+=(num*cat[9-i-1]);
    }
    lis[sum + 1] = t;
    return sum+1;

}
int a[10];
int getvalue(int *a)
{
  int ret = 0;
  for(int i = 0; i < 9; i++)
    ret = ret * 10 + a[i];
  return ret;
}
int divide(int val)
{
  for(int i = 8; i >= 0; i--)
  {
    a[i] = val % 10;
    val /= 10;
  }
}
int getx(int *a)
{
  for(int i = 0; i < 9; i++)
    if(a[i] == 0)
      return i;
}

char buf[20];
queue<int> q;
void Pre()
{
  memset(lis, 0, sizeof lis);
  memset(Vis, 0, sizeof Vis);
  memset(sta, 0x3f, sizeof sta);
  int st = gethash(123456780);
  Vis[st] = 1, sta[st] = 4;
  q.push(st);
  while(!q.empty())
  {
    int t = q.front(); q.pop();
    int val = lis[t];
    //printf("%d %c\n", val, mov[sta[t]]);
    int nex, hasn;
    divide(val);
    int pos = getx(a);
    if(pos % 3 >= 1)
    {
      swap(a[pos], a[pos - 1]);
      nex = getvalue(a);
      hasn = gethash(nex);
      if(!Vis[hasn])
      {
        Vis[hasn] = 1;
        q.push(hasn);
        pre[hasn] = t;
        sta[hasn] = 1;
      }
      swap(a[pos], a[pos - 1]);
    }
    if(pos % 3 <= 1)
    {
      swap(a[pos], a[pos + 1]);
      nex = getvalue(a);
      hasn = gethash(nex);
      if(!Vis[hasn])
      {
        Vis[hasn] = 1;
        q.push(hasn);
        pre[hasn] = t;
        sta[hasn] = 0;
      }
      swap(a[pos], a[pos + 1]);
    }
    if(pos / 3 >= 1)
    {
      swap(a[pos], a[pos - 3]);
      nex = getvalue(a);
      hasn = gethash(nex);
      if(!Vis[hasn])
      {
        Vis[hasn] = 1;
        q.push(hasn);
        pre[hasn] = t;
        sta[hasn] = 3;
      }
      swap(a[pos], a[pos - 3]);
    }
    if(pos / 3 <= 1)
    {
      swap(a[pos], a[pos + 3]);
      nex = getvalue(a);
      hasn = gethash(nex);
      if(!Vis[hasn])
      {
        Vis[hasn] = 1;
        q.push(hasn);
        pre[hasn] = t;
        sta[hasn] = 2;
      }
      swap(a[pos], a[pos + 3]);
    }
  }
}
int main()
{
  Pre();
  while(~scanf(" %c", &buf[0]))
  {
    for(int i = 1; i < 9; i++)
      scanf(" %c", &buf[i]);
    for(int i = 0; i < 9; i++)
    {
      if(buf[i] == 'x') a[i] = 0;
      else  a[i] = buf[i] - '0';
    }
    int cnt = 0;
    for(int i = 0; i < 9; i++)
      for(int j = i + 1; j < 9; j++)
        if(a[i] != 0 && a[j] != 0 && a[i] > a[j])
          cnt++;
    if(cnt % 2) printf("unsolvable\n");
    else
    {
      int st = gethash(getvalue(a));
      int ed = gethash(123456780);
      if(sta[st] == -1) printf("unsolvable");
      else
      {
        while(st != ed)
        {
          printf("%c", mov[sta[st]]);
          st = pre[st];
        }
        printf("\n");
      }
    }
  }
  return 0;
}
