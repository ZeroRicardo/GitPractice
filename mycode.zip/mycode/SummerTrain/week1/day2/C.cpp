//hoj - 3237
#include <bits/stdc++.h>

using namespace std;
int n, m, l;
bool vis[110][110];
char maze[110][110];
int fuel[110][110];
bool flag = 0;
int dx[4] = {0, 1, 0, -1}, dy[4] = {-1, 0, 1, 0};
void dfs(int x, int y)
{

  if(flag || x == n - 1 && y == m - 1){
    flag = 1;
    return;
  }
  if(fuel[x][y] == 0) return;
  for(int i = 0; i < 4; i++)
  {
    int mx = x + dx[i], my = y + dy[i];
    if(0 <= mx && mx < n && 0 <= my && my < m && maze[mx][my] != '#')
    {
      int nexfuel = fuel[x][y] - 1;
      if(maze[mx][my] == '+')
        nexfuel = l;
      if(fuel[mx][my] < nexfuel)      //去重条件，不优化直接搜肯定超时
      {
        fuel[mx][my] = nexfuel;
        dfs(mx, my);
      }
    }
  }
}
int main()
{
  int  T;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d%d%d", &n, &m, &l);
    for(int i = 0; i < n; i++)
      for(int j = 0; j < n; j++)
        scanf(" %c", &maze[i][j]);
    flag = 0;
    memset(vis, 0, sizeof(vis));
    vis[0][0] = 1;
    memset(fuel, -1, sizeof(fuel));
    fuel[0][0] = l;
    dfs(0, 0);
    if(flag)  printf("Yes\n");
    else  printf("No\n");
  }
}
