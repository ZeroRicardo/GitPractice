#include <bits/stdc++.h>
using namespace std;
bool vis[510];
int a[510];
int n;
int ans;
bool cmp(int a, int b){
  return a > b;
}
bool dfs(int ned, int step)
{
  if(step == n) return true;
  if(ned == 0)  ned = ans;
  for(int i = 0; i < n; i++)
  {
    if(!vis[i] && a[i] <= ned)
    {
      vis[i] = 1;
      if(dfs(ned - a[i], step + 1))  return true;
      vis[i] = 0;
      if(ned == a[i] || ned == ans) break; // important
    }
  }
  return false;
}
int main()
{
  while(~scanf("%d", &n))
  {
    if(n == 0)  break;
    int sum = 0;
    for(int i = 0; i < n; i++)
    {
      scanf("%d", &a[i]);
      sum += a[i];
    }
    sort(a, a + n, cmp);
    for(ans = a[0]; ans <= sum; ans++)
    {
      if(sum % ans == 0)
      {
        memset(vis, false, sizeof vis);
        if(dfs(ans, 0)) break;
      }
    }
    printf("%d\n", ans);
  }
}
