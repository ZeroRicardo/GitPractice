#include <bits/stdc++.h>
using namespace std;
int main()
{
  int x;
  cin >> x;A
  if(x == 3)  cout << 5 << endl;
  else{
  for(int i = 1; i <= 1000; i += 2)
    if((i * i + 1) / 2 >= x){
      cout << i << endl;
      break;
    }
  }
}
