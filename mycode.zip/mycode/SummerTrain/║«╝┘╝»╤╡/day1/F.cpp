#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
char zod[12][22] = {"rat", "ox", "tiger", "rabbit", "dragon", "snake", "horse", "sheep", "monkey", "rooster", "dog", "pig" };
int main()
{
  int T;
  cin >> T;
  while(T--)
  {
    char buf[22];
    int A, B;
    cin >> buf;
    for(A = 0; A < 12; A++)
      if(!strcmp(buf, zod[A]))  break;
    cin >> buf;
    for(B = 0; B < 12; B++)
      if(!strcmp(buf, zod[B]))  break;
    int ans = B - A;
    if(ans <= 0)  ans += 12;
    cout << ans << endl;
  }
}
