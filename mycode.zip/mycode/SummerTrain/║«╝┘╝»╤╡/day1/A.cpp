#include <iostream>
#include <cstring>
using namespace std;
char buf[10096];
int main()
{
  int T, cas = 1;
  cin >> T;
  while(T--){
    cin >> buf;
    cout << "Case " << cas++ << ": ";
    if(strlen(buf) % 2 == 0) cout << "Even" << endl;
    else  cout << "Odd" << endl;
  }
}
