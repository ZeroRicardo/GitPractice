#include <iostream>
using namespace std;
#define ll long long
const int maxn = 580010;
ll pr[maxn];
int main()
{
  for(ll i = 2; i <= 577351; i++)
    pr[i - 1] = i * i * i - (i - 1) * (i - 1) * (i - 1);
  int T;
  cin >> T;
  while(T--){
    ll x;
    cin >> x;
    if(x == *lower_bound(pr + 1, pr + 577350, x)) cout << "YES" << endl;
    else  cout << "NO" << endl;
  }
}
