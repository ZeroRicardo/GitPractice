#include <iostream>
#include <cstring>
using namespace std;
const int maxn = 100010;
bool mark[maxn];
int a[maxn];
int pos[maxn];
int main()
{
  int n;
  cin >> n;
  memset(mark, 0, sizeof mark);
  memset(pos, 0, sizeof pos);
  for(int i = 1; i <= n; i++){
    cin >> a[i];
    if(1 <= a[i] && a[i] <= n && pos[a[i]] == 0){
      pos[a[i]] = i;
      mark[i] = 1;
    }
  }
  int i = 1, j = 1;
  while(i <= n && j <= n)
  {
    while(i <= n && pos[i]) i++;
    while(j <= n && mark[j]) j++;
    if(i > n || j > n)  break;
    a[j] = i;
    i++;
    j++;
  }
  for(int i = 1; i <= n; i++)
    cout << a[i] << " ";
  cout << endl;
}
