#include <iostream>
#include <cstring>
using namespace std;
int cnt[1510];
int main()
{
  int n;
  cin >> n;
  int ans = 0;
  for(int i = 1; i <= n; i++){
    int h, m;
    cin >> h >> m;
    cnt[h * 60 + m]++;
    ans = max(ans, cnt[h * 60 + m]);
  }
  cout << ans << endl;
}
