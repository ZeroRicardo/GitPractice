#include <iostream>
using namespace std;
int main()
{
  int T;
  cin >> T;
  while(T--)
  {
    int n, l, r;
    cin >> n >> l >> r;
    int ans = 0;
    for(int i = l; i <= r; i++)
      ans += n / i;
    cout << ans << endl;
  }
}
