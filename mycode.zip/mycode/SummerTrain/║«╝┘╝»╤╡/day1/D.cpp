#include <iostream>
using namespace std;
char s1[110], s2[110];
int A, B, C, k, d;
int main(){
  int T;
  cin >> T;
  while(T--){
    cin >> s1 >> s2 >> C;
    A = B = 0;
    for(int i = 0; s1[i]; i++){
      if(isdigit(s1[i]))  A = A * C + s1[i] - '0';
      else A = A * C + s1[i] - 'a' + 10;
    }
    for(int i = 0; s2[i]; i++){
      if(isdigit(s2[i]))  B = B * C + s2[i] - '0';
      else B = B * C + s2[i] - 'a' + 10;
    }
    k = A / B;
    d = A % B;
    cout << "(" << k << "," << d << ")" << endl;
  }
}
