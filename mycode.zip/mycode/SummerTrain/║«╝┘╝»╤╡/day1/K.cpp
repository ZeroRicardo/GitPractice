#include <bits/stdc++.h>
using namespace std;
int f[28];
char str[200010];
void debug(){
  for(int i = 1; i <= 26; i++){
    printf("%c - %c\n", i - 1 + 'a', f[i] - 1 + 'a');
  }
}
int main()
{
  int n, m;
  cin >> n >> m;
  cin >> str;
  for(int i = 1; i <= 26; i++)
    f[i] = i;
  for(int i = 1; i <= m; i++)
  {
    char u, v;
    cin >> u >> v;
    int pp;
    for(int j = 1; j <= 26; j++)
      if(f[j] - 1 + 'a' == u){
        f[j] = v + 1 - 'a';
        pp = j;
        break;
      }
    for(int j = 1; j <= 26; j++)
      if(j != pp && f[j] - 1 + 'a' == v){
        f[j] = u + 1 - 'a';
        break;
    }
  //  debug();
  }
  for(int i = 0; i < n; i++)
    str[i] = f[str[i] - 'a' + 1] + 'a' - 1;
  cout << str << endl;
}
