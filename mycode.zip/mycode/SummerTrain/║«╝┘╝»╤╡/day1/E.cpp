#include <iostream>
using namespace std;
#define ll long long
const int maxn = 50010;
ll sum[maxn];
int main()
{
  int n, t;
  cin >> n;
  sum[0] = 0;
  for(int i = 1; i <= n; i++){
    cin >> t;
    sum[i] = sum[i - 1] + t;
  }
  int q;
  cin >> q;
  while(q--)
  {
    int i, l;
    cin >> i >> l;
    cout << sum[i + l - 1] - sum[i - 1] << endl;
  }
}
