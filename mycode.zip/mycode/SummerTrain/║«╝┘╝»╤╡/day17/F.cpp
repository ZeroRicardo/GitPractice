  //dijkstra + vector 被卡, spfa过 ......
  #include <cstdio>
  #include <vector>
  #include <cstring>
  #include <queue>
  #include <algorithm>
  using namespace std;
  using ll = long long;
  const int maxn = 100010;
  const ll inf = 0;
  struct edge{
    int to;
    ll cost;
    edge(){}
    edge(int _to, ll _cost):to(_to), cost(_cost){}
  };
  vector<edge> G[maxn];
  ll dis[maxn];
  bool train[maxn];
  bool vis[maxn], VIS[maxn];
  void init(){
    for(int i = 0; i < maxn; i++)
      G[i].clear();
  }
  void addedge(int u, int v, ll w){
    G[u].push_back(edge(v, w)), G[v].push_back(edge(u, w));
  }
  int n, m, k;
  void spfa(int s){
    memset(dis, 0x3f, sizeof dis);
    memset(vis, 0, sizeof vis);
    queue<int> q;
    q.push(s);
    int ans = 0;
    for(int i = 1; i <= k; i++){
      int p;
      ll d;
      scanf("%d%lld", &p, &d);
      if(d < dis[p]){
        if(vis[p])  ans++;
        vis[p] = 1;
        dis[p] = d;
        q.push(p);
      }
      else ans++;
    }
    dis[s] = 0, VIS[s] = 1;
    while(!q.empty()){
      int u = q.front(); q.pop();
      VIS[u] = 0;
      for(int i = 0; i < G[u].size(); i++){
        int v = G[u][i].to;
        ll w = G[u][i].cost;
        if(dis[v] > dis[u] + w){
          dis[v] = dis[u] + w;
          if(vis[v]){
            vis[v] = 0;
            ans++;
          }
          if(!VIS[v]){
            VIS[v] = 1;
            q.push(v);
          }
        }
        else if(dis[v] == dis[u] + w && vis[v]){
          vis[v] = 0;
          ans++;
        }
      }
    }
    printf("%d\n", ans);
  }
  int main(){
    while(~scanf("%d%d%d", &n, &m, &k)){
      init();
      for(int i = 1; i <= m; i++){
        int u, v, w;
        scanf("%d%d%d", &u, &v, &w);
        addedge(u ,v, w);
      }
      spfa(1);
    }
  }
