#include <cstdio>
#include <vector>
#include <cstring>
#include <queue>
#include <algorithm>
using namespace std;
const int maxn = 1010;
const int inf = 0x3f3f3f3f;
struct edge{
  int to, cost;
  edge(){}
  edge(int _to, int _cost):to(_to), cost(_cost){}
};
vector<edge> G[maxn];
int dis[maxn];
void init(){
  for(int i = 0; i < maxn; i++)
    G[i].clear();
}
void addedge(int u, int v, int w){
  G[u].push_back(edge(v, w)), G[v].push_back(edge(u, w));
}
void dijkstra(int s){
  memset(dis, 0x3f, sizeof dis);
  priority_queue<pair<int, int> > q;
  dis[s] = 0;
  q.push(make_pair(0, s));
  while(!q.empty()){
    int u = q.top().second; q.pop();
    for(int i = 0; i < G[u].size(); i++){
      int v = G[u][i].to, w = G[u][i].cost;
      if(dis[v] > dis[u] + w){
        dis[v] = dis[u] + w;
        q.push(make_pair(-dis[v], v));
      }
    }
  }
}
int main(){
  int t, n;
  while(~scanf("%d%d", &t, &n)){
    init();
    for(int i = 1; i <= t; i++){
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      addedge(u ,v, w);
    }
    dijkstra(1);
    printf("%d\n", dis[n]);
  }
}
