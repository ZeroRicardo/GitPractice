#include <cstdio>
using namespace std;
int mat[110][110];
int main(){
  int n, m;
  scanf("%d%d", &n, &m);
  for(int i = 1; i <= m; i++){
    int u, v;
    scanf("%d%d", &u, &v);
    mat[u][v] = 1;
    mat[v][u] = -1;
  }
  for(int k = 1; k <= n; k++)
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= n; j++)
        if(mat[i][k] == mat[k][j] && mat[i][k] != 0){
          mat[i][j] = mat[i][k];
        }
  int ans = 0;
  for(int i = 1; i <= n; i++){
    bool f = 1;
    for(int j = 1; j <= n; j++){
      if(i != j && mat[i][j] == 0){
        f = 0;
        break;
      }
    }
    ans += f;
  }
  printf("%d\n", ans);
}
