#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
int V, E;
struct Edge{
  int from, to, cost;
  Edge(){}
  Edge(int _from, int _to, int _cost):from(_from), to(_to), cost(_cost){}
  bool operator < (const Edge &x)const{
    return cost < x.cost;
  }
}edge[MAX_E];
int par[MAX_V], ran[MAX_V];
void init(int n)
{
  for(int i = 1; i <= n; i++)
  {
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x)
{
  if(x == par[x]) return x;
  else  return par[x] = find(par[x]);
}
void unite(int x, int y)
{
  x = find(x), y = find(y);
  if(x == y)  return;
  if(ran[x] < ran[y])
    par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
int kruskal()
{
  sort(edge + 1, edge + E + 1);
  int cnt = V;
  int ans = 0;
  init(V);
  for(int i = 1; i <= E; i++){
    int t1 = find(edge[i].from);
    int t2 = find(edge[i].to);
    if(t1 != t2)
    {
      unite(t1, t2);
      ans += edge[i].cost;
      cnt--;
      if(cnt == 1)  break;
    }
  }
  return ans;
}
int main()
{
  while(~scanf("%d", &V)){
    if(V == 0)  break;
    E = 0;
    char c;
    int u, v, w, num;
    for(int i = 1; i <= V - 1; i++){
      scanf(" %c%d", &c, &num);
      u = c - 'A' + 1;
      for(int j = 1; j <= num; j++){
        scanf(" %c%d", &c, &w);
        v = c- 'A' + 1;
        edge[++E] = Edge(u, v, w);
      }
    }
    printf("%d\n", kruskal());
  }
}
