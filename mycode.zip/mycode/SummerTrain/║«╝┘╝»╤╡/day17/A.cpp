#include <bits/stdc++.h>
using namespace std;
const int maxn = 30010;
vector<int> G[maxn];
bool vis[maxn];
void init(){
  for(int i = 0; i < maxn; i++)
    G[i].clear();
  memset(vis, 0, sizeof vis);
}
void addedge(int u, int v){
  G[u].push_back(v);
}
int n, t;
bool dfs(int s){
  vis[s] = 1;
  if(s == t)  return 1;
  for(int i = 0; i < G[s].size(); i++)
    if(!vis[G[s][i]] && dfs(G[s][i]))
      return 1;
  return 0;
}
int main(){

  while(cin >> n >> t){
    for(int i = 1; i <= n - 1; i++){
      int x;
      cin >> x;
      addedge(i, x + i);
    }
    if(dfs(1))  cout << "YES" << endl;
    else  cout << "NO" << endl;
  }
}
