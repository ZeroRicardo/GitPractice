#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;
const int maxn = 2010;
struct edge{
  int to, cost;
  edge(){}
  edge(int _to, int _cost):to(_to), cost(_cost){}
  bool operator < (const edge &t)const{
    return cost < t.cost;
  }
};
vector<edge> G[maxn];
int deg[maxn], ans[maxn], cnt;
bool vis[maxn];
void init(){
  for(int i = 0; i < maxn; i++)
    G[i].clear();
  memset(deg, 0, sizeof deg);
  memset(vis, 0, sizeof vis);
  cnt = 0;
}
void addedge(int u, int v, int w){
  G[u].push_back(edge(v, w)), G[v].push_back(edge(u, w));
  deg[u]++, deg[v]++;
}
void MySort(){
  for(int i = 1; i <= 1996; i++)
    if(G[i].size())
      sort(G[i].begin(), G[i].end());
}
bool judge(){
  for(int i = 1; i < 1996; i++)
    if(deg[i] & 1)  return 0;
  return 1;
}
void dfs(int u){
  for(int i = 0; i < G[u].size(); i++){
    int v = G[u][i].to, w = G[u][i].cost;
    if(!vis[w]){
      vis[w] = 1;
      dfs(v);
      ans[cnt++] = w;
    }
  }
}
int main(){
  int u, v, w;
  while(~scanf("%d%d", &u, &v)){
    if(u == 0 && v == 0)  break;
    init();
    int s = min(u, v);
    scanf("%d", &w);
    addedge(u, v, w);
    while(~scanf("%d%d", &u, &v)){
      if(u == 0 && v == 0)  break;
      scanf("%d", &w);
      addedge(u, v, w);
    }
    if(judge()){
      MySort();
      dfs(s);
      for(int i = cnt - 1; i >= 1; i--)
        printf("%d ", ans[i]);
      printf("%d\n", ans[0]);
    }
    else printf("Round trip does not exist.\n");
  }
}
