#include <cstdio>
#include <vector>
#include <cstring>
#include <queue>
#include <algorithm>
using namespace std;
using ll = long long;
const int maxn = 1010;
struct edge{
  int to;
  int cost;
  edge(){}
  edge(int _to, int _cost):to(_to), cost(_cost){}
};
const int MAX_V = 1010;
const int MAX_E = 100010 * 4;
const int inf = 0x3f3f3f3f;
int tot = 0;
struct EDGE{
  int to, next, c;
}E[MAX_E];
int level[MAX_V], head[MAX_V], thead[MAX_V];
vector<edge> G[maxn];
int dis[maxn];
bool vis[maxn];
void Addedge(int u, int v, int w);
int max_flow(int s, int t);
void init(){
  for(int i = 0; i < maxn; i++)
    G[i].clear();
  tot = 0;
  memset(head, -1, sizeof(head));
}
void addedge(int u, int v, int w){
  G[u].push_back(edge(v, w));
}
void spfa(int s, int t){
  memset(dis, 0x3f, sizeof dis);
  memset(vis, 0, sizeof vis);
  queue<int> q;
  q.push(s);
  dis[s] = 0, vis[s] = 1;
  while(!q.empty()){
    int u = q.front(); q.pop();
    vis[u] = 0;
    for(int i = 0; i < G[u].size(); i++){
      int v = G[u][i].to;
      int w = G[u][i].cost;
      if(dis[v] > dis[u] + w){
        dis[v] = dis[u] + w;
        if(!vis[v]){
          vis[v] = 1;
          q.push(v);
        }
      }
    }
  }
}

void Addedge(int u, int v, int w)
{
  E[tot].to = v, E[tot].c = w, E[tot].next = head[u];
  head[u] = tot++;
  E[tot].to = u, E[tot].c = 0, E[tot].next = head[v];
  head[v] = tot++;
}
bool bfs(int s, int t)
{
  memset(level, -1, sizeof(level));
  queue<int> Q;
  Q.push(s);
  level[s] = 1;
  while(!Q.empty())
  {
    int u = Q.front();
    Q.pop();
    for(int i = head[u]; i != -1; i = E[i].next){
      int v = E[i].to;
      if(E[i].c > 0 && level[v] < 0){
        Q.push(v);
        level[v] = level[u] + 1;
      }
    }
  }
  if(level[t] != -1)  return true;
  else  return false;
}
int dfs(int u, int t, int f)
{
  if(u == t)  return f;
  for(int &i = thead[u]; i != -1; i = E[i].next)
  {
    int v = E[i].to;
    if(E[i].c <= 0 || level[v] <= level[u]) continue;
    int d = dfs(v, t, min(f, E[i].c));
    if(d > 0){
      E[i].c -= d;
      E[i ^ 1].c += d;
      return d;
    }
  }
  return 0;
}
int max_flow(int s, int t)
{
  int ans = 0;
  while(bfs(s, t))
  {
    memcpy(thead, head, sizeof(head));
    int f = 0;
    while(f = dfs(s, t, inf)){
      ans += f;
    }
  }
  return ans;
}
int main(){
  int T;
  scanf("%d", &T);
  while(T--){
    int n, m;
    scanf("%d%d", &n, &m);
    init();
    for(int i = 1; i <= m; i++){
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      addedge(u ,v, w);
    }
    int s, t;
    scanf("%d%d", &s, &t);
    spfa(s, t);
    for(int i = 1; i <= n; i++){
      for(int j = 0; j < G[i].size(); j++){
        if(dis[i] + G[i][j].cost == dis[G[i][j].to]){
          Addedge(i, G[i][j].to, 1);
        }

      }
    }
    printf("%d\n", max_flow(s, t));
  }
}
