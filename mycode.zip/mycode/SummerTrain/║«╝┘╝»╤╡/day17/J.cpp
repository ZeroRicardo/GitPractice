#include <cstdio>
#include <cstring>
#include <queue>
#include <algorithm>
using namespace std;
int val[52][52];
int dis[52][52];
char mat[52][52];
int cost[110][110];
int mincost[110];
bool used[110];
int n;
int prim(){
  memset(mincost, 0x3f, sizeof mincost);
  memset(used, 0, sizeof used);
  mincost[1] = 0;
  int ret = 0;
  while(1){
    int v = - 1;
    for(int i = 1; i <= n; i++)
      if(!used[i] && (v == -1 || mincost[v] > mincost[i])) v = i;
    if(v == -1) break;
    //if(mincost[v] == 0x3f3f3f3f)  return -1;
    ret += mincost[v];
    used[v] = 1;
    for(int i = 1; i <= n; i++)
      mincost[i] = min(mincost[i], cost[v][i]);
  }
  return ret;   //返回边权和
}
void debug();
int r, c;
int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
void bfs(int sx, int sy){
  int S = sx * 100 + sy;
  queue<int> q;
  memset(dis, 0x3f, sizeof dis);
  dis[sx][sy] = 0;
  q.push(S);
  while(!q.empty()){
    int x = q.front() / 100, y = q.front() % 100; q.pop();
    //cout << x << " " << y << endl;
    if(val[x][y] != -1)
      cost[val[sx][sy]][val[x][y]] = dis[x][y];
    for(int i = 0; i < 4; i++){
      int mx = x + dx[i], my = y + dy[i];
      if(1 <= mx && mx <= r && 1 <= my && my <= c && dis[mx][my] > dis[x][y] + 1 && mat[mx][my] != '#'){
        dis[mx][my] = dis[x][y] + 1;
        q.push(mx * 100 + my);
      }
    }
  }
  //debug();
}
void debug(){
  for(int i = 1; i <= n; i++){
    for(int j = 1; j <= n; j++)
      if(cost[i][j] == 0x3f3f3f3f) printf("-1 ");
      else printf("%d ", cost[i][j]);
      //printf("%c", mat[i][j]);
    printf("\n");
  }
}
int main(){
  int T;
  scanf("%d", &T);
  while(T--){
    n = 0;
    scanf("%d%d", &c, &r);
    memset(cost, 0x3f, sizeof cost);
    gets(mat[0]);
    memset(val, -1, sizeof val);
    for(int i = 1; i <= r; i++){
      gets(mat[i]);
      for(int j = 1; j <= c; j++){
        if(mat[i][j] == 'S' || mat[i][j] == 'A')
          val[i][j] = ++n;
        //printf("%c", mat[i][j]);
      }
    }

    for(int i = 1; i <= r; i++)
      for(int j = 1; j <= c; j++)
        if(val[i][j] != -1)
          bfs(i, j);
    //debug();
    printf("%d\n", prim());
  }
}
