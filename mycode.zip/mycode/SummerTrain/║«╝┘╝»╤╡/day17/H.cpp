#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxe = 10010;
const int maxv = 110;
struct edge{
  int u, v, w;
  edge(){}
  edge(int _u, int _v, int _w):u(_u), v(_v), w(_w){}
  bool operator < (const edge &t)const{
    return w < t.w;
  }
}eg[maxe];
int v, e;
int par[maxv];
int ran[maxv];
void init(int n){
  for(int i = 1; i <= n; i++)  par[i] = i;
  memset(ran, 0, sizeof ran);
}
int find(int x){
  return par[x] == x ? x : par[x] = find(par[x]);
}
void unite(int x, int y){
  x = find(x), y = find(y);
  if(x == y)  return;
  if(ran[x] < ran[y]) par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
int kruskal(){
  sort(eg, eg + e);

  int ret = -1;
  for(int k = 0; k <= e - v + 1; k++){
    int cnt = v;
    init(v);
    int maxk = 0, mink = 0x3f3f3f3f;
    for(int i = k; i < e; i++){
      int t1 = find(eg[i].u);
      int t2 = find(eg[i].v);
      if(t1 != t2){
        unite(t1, t2);
        maxk = max(maxk, eg[i].w);
        mink = min(mink, eg[i].w);
        cnt--;
        if(cnt == 1){
          if(ret == -1 || ret > maxk - mink)  ret = maxk - mink;
        }
      }
    }
  }
  return ret;
}
int main(){
  while(~scanf("%d%d", &v, &e)){
    if(v == 0 && e == 0)  break;
    for(int i = 0; i < e; i++){
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      eg[i] = edge(u, v, w);
    }
    int ans = kruskal();
    printf("%d\n", ans);
  }
}
