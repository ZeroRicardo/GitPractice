#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxn = 110;
int a[maxn];
bool on[maxn], off[maxn];
int n, cnt;
struct nod{
  int x[maxn];
  bool operator <(const nod &t)const{
    for(int i = 1; i <= n; i++)
      if(x[i] < t.x[i])
        return 1;
      else if(x[i] > t.x[i])
        return 0;
  }
}ans[32];
int tot = 0;
void cg1(){
  for(int i = 1; i <= n; i++)
    a[i] = !a[i];
}
void cg2(){
  for(int i = 1; i <= n; i += 2)
    a[i] = !a[i];
}
void cg3(){
  for(int i = 2; i <= n; i += 2)
    a[i] = !a[i];
}
void cg4(){
  for(int i = 1; i <= n; i += 3)
    a[i] = !a[i];
}
bool check(int c){
  for(int i = 1; i <= n; i++)
    if(on[i] && !a[i])
      return 0;
  for(int i = 1; i <= n; i++)
    if(off[i] && a[i])
      return 0;
//  cout << cnt << " " << c << endl;
  if(0 == c % 2 && cnt >= c){
    for(int i = 1; i <= n; i++)
      ans[tot].x[i] = a[i];
    tot++;
    return 1;
  }
  return 1;
}
void debug(){
  for(int i = 1; i <= n; i++)
    printf("%d", a[i]);
  puts("");
//  printf("%d\n", check(0));
}
void dfs(int depth, int c){

  if(depth == 4){
    if(c >= 0){
  //    printf("%d %d\n", depth, c);
//      debug();
      check(c);
    }
  }
  switch(depth)
  {
    case 0:
      dfs(1, c);
      cg1();
      dfs(1, c - 1);
      cg1();
      break;
    case 1:
      dfs(2, c);
      cg2();
      dfs(2, c - 1);
      cg2();
      break;
    case 2:
      dfs(3, c);
      cg3();
      dfs(3, c - 1);
      cg3();
      break;
    case 3:
      dfs(4, c);
      cg4();
      dfs(4, c - 1);
      cg4();
      break;
  }
}
int main(){
  scanf("%d%d", &n, &cnt);
  for(int i = 1; i <= n; i++)
    a[i] = 1;
  int t;
  memset(on, 0, sizeof on);
  memset(off, 0, sizeof off);
  while(~scanf("%d", &t)){
    if(t == -1) break;
    on[t] = 1;
  }
  while(~scanf("%d", &t)){
    if(t == -1) break;
    off[t] = 1;
  }
  dfs(0, cnt);
  sort(ans, ans + tot);
  for(int i = 0; i < tot; i++){
    for(int j = 1; j <= n; j++)
      printf("%d", ans[i].x[j]);
    puts("");
  }
}
