import java.util.*;
import java.math.*;
public class Main {

	public static void main(String[] args) {
		Scanner cin = new Scanner(System.in);
		BigInteger[] fib = new BigInteger[1010];
		fib[1] = new BigInteger("1");
		fib[2] = new BigInteger("2");
		//BigInteger x = new BigInteger("10");
		//x = x.pow(100);
		for(int i = 3; i <= 1000; i++)
			fib[i] = fib[i - 1].add(fib[i - 2]);
		//System.out.println(fib[1000].subtract(x));
		BigInteger a, b;
		while(cin.hasNext()) {
			a = cin.nextBigInteger();
			b = cin.nextBigInteger();
			if(a.compareTo(BigInteger.ZERO) == 0 && b.compareTo(BigInteger.ZERO) == 0)	break;
			int ans = 0;
			for(int i = 1; i <= 1000; i++) {
				if(fib[i].compareTo(a) < 0)
					continue;
				else if(fib[i].compareTo(b) > 0)
					break;
				else
					ans++;
			}
			System.out.println(ans);
		}
	}

}
