#include <bits/stdc++.h>
using namespace std;
bool vis[510];
int w[510], order[1010], ans[510];
int main(){
  int n, m;
  cin >> n >> m;
  memset(vis, 0, sizeof vis);
  for(int i = 1; i <= n; i++)
    cin >> w[i];
  int k = 0;
  for(int j = 1; j <= m; j++){
    cin >> order[j];
    if(!vis[order[j]]){
      vis[order[j]] = 1;
      ans[++k] = order[j];
    }
  }
  int sum = 0;
  for(int j = 1; j <= m; j++){
    int pos, tot = 0;
    for(int i = 1; i <= k; i++){
      if(ans[i] != order[j]) tot += w[ans[i]];
      else{
        pos = i;
        break;
      }
    }
    sum += tot;
    int tmp = ans[pos];
    for(int i = pos; i >= 2; i--)
      ans[i] = ans[i - 1];
    ans[1] = tmp;
  }
  cout << sum << endl;
}
