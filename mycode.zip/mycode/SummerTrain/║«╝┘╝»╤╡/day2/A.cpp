#include <bits/stdc++.h>
using namespace std;
int tab[22][22];
int n, m;
bool check(){
  for(int i = 1; i <= n; i++){
    int cnt = 0;
    for(int j = 1; j <= m; j++)
      if(tab[i][j] != j)
        cnt++;
    if(cnt > 2) return 0;
  }
  return 1;
}
void Swap(int x, int y){
  for(int i = 1; i <= n; i++)
    swap(tab[i][x], tab[i][y]);
}
int main()
{
  cin >> n >> m;
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= m; j++)
      cin >> tab[i][j];
  bool flag = 0;
  if(check()) flag = 1;
  else{
  for(int i = 1; i <= m; i++)
    for(int j = i + 1; j <= m; j++){
      Swap(i, j);
      if(check()){
        flag = 1;
        goto out;
      }
      Swap(i, j);
    }
  out:;
  }
  if(flag)  cout << "YES" << endl;
  else  cout << "NO" << endl;
}
