#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn = 100010;
int n, m;
ll a[maxn], b[maxn];
bool check(ll t){
  memcpy(b, a, sizeof a);
  int cur = 1;
  for(int i = 1; i <= m; i++){
    ll tim = t - cur;
    if(tim < 0) return 0;
    while(tim >= b[cur]){
      tim -= b[cur];
      b[cur] = 0;
      if(cur == n && b[cur] == 0) return 1;
      if(tim > 0){
        cur++;
        tim--;
      }
      if(tim == 0) break;
    }
    b[cur] -= tim;
  }
  while(cur <= n && b[cur] == 0)  cur++;
  return cur > n;
//  cout << "cur" << b[cur] << endl;
 return 0;
}
int main(){
  cin >> n >> m;
  ll low = 0, high = 10000000000000000ll, mid;
  for(int i = 1; i <= n; i++){
    cin >> a[i];
  //  high += a[i];
  }
//  cout << check(4) << endl;
  while(low < high){
    mid = (low + high) / 2;
//    cout << mid << endl;
    if(check(mid)) high = mid;
    else  low = mid + 1;
  }
  cout << low << endl;
}
