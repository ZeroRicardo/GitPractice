#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 10010;
int prime[maxn];
void makeprime(){
  memset(prime, 0, sizeof prime);
  for(int i = 2; i < maxn; i++){
    if(!prime[i]) prime[++prime[0]] = i;
    for(int j = 1; j <= prime[0] && prime[j] <= maxn / i; j++){
      prime[prime[j] * i] = 1;
      if(i % prime[j] == 0) break;
    }
  }
}

int main(){
  makeprime();
  int n;
//  for(int i = 1; i <= prime[0]; i++)
//    cout << prime[i] << endl;
  while(cin >> n){
    if(n == 0)  break;
    int ans = 0;
    for(int i = 1; prime[i] <= n; i++)
    {
      int sum = 0;
      for(int j = i; sum < n; j++)
        sum += prime[j];
      if(sum == n)  ans++;
    }
    cout << ans << endl;
  }
}
