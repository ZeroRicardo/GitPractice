#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
typedef long long ll;
ll abs(ll x){
  if(x < 0) x = -x;
  return x;
}
ll extend_gcd(ll a, ll b, ll &x, ll &y){
  if(a == 0 && b == 0)  return -1;
  if(b == 0){
    x = 1, y = 0;
    return a;
  }
  ll d = extend_gcd(b, a % b, y, x);
  y -= a / b * x;
  return d;
}
int main(){
  ll x, y, m, n, L;
  while(cin >> x >> y >> m >> n >> L){
    ll a = n - m;
    ll Q = x - y;
    ll d = extend_gcd(a, -L, x, y);
    if(Q % d) cout << "Impossible" << endl;
    else{
      ll temp = L / d;
      //cout << temp << endl;
      cout << (Q / d * x % temp + temp) % temp << endl;
    }
  }
}
