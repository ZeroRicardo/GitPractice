#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long ll;
const int maxn = 1000000;
ll phi[maxn + 10];
void PhiTable(){
  memset(phi, 0, sizeof phi);
  phi[1] = 1;
  for(ll i = 2; i <= maxn; i++)
    if(!phi[i])
      for(ll j = i; j <= maxn; j += i){
        if(!phi[j]) phi[j] = j;
        phi[j] -= phi[j] / i;
      }
  for(int i = 3; i <= maxn; i++)
    phi[i] += phi[i - 1];
}
int main(){
  PhiTable();
  int n;
  while(cin >> n && n)  cout << phi[n] << endl;
}
