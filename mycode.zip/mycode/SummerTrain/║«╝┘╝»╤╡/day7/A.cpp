#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <cctype>
using namespace std;
typedef long long ll;
char buf[10010];
int prime[55010], cnt[10010];
int makeprime(int n){
  memset(prime, 0, sizeof prime);
  for(int i = 2; i <= n; i++){
    if(!prime[i]) prime[++prime[0]] = i;
    for(int j = 1; j <= prime[0] && prime[j] <= n / i; j++){
      prime[prime[j] * i] = 1;
      if(i % prime[j] == 0) break;
    }
  }
  return prime[0];
}
int main(){
  int tot = makeprime(40000);
  //cout << tot << endl;
  while(1){
    gets(buf);
    //getchar();
    int len = strlen(buf);
    bool flag = 0;
    ll x = 1, t = 0, c = 0;
    for(int i = 0; i <= len; i++){
      if(isdigit(buf[i])){
        if(!flag){
          t = t * 10 + buf[i] - '0';
        }
        else{
          c = c * 10 + buf[i] - '0';
        }
      }
      else{
        if(flag){
          ll tmp = 1;
          for(int i = 1; i <= c; i++)
            tmp *= t;
      //    cout << tmp << endl;
          x = x * tmp;
          t = 0;
          c = 0;
          flag = 0;
        }
        else{
          flag = 1;
        }
      }
    }
    if(x == 1) break;
    x--;
    bool first = 1;
    for(int i = tot; i >= 1; i--){
      if(x % prime[i] == 0){
        if(first) first = 0;
        else putchar(' ');
        int e = 0;
        while(x % prime[i] == 0){
          e++;
          x /= prime[i];
        }
        printf("%d %d", prime[i], e);
      }
    }
    puts("");
  }
}
