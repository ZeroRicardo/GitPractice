#include <cstdio>
#include <iostream>
#include <vector>
using namespace std;
#define LL long long
typedef int gg;
LL extgcd(LL a,LL b,LL &x,LL &y)
{
    LL d=a;
    if(b!=0)
    {
        d=extgcd(b,a%b,y,x);
        y-=(a/b)*x;
    }
    else { x=1; y=0; }
    return d;
}
LL modInverse(LL a,LL m)
{
    LL x,y;
    extgcd(a,m,x,y);
    return (m+x%m)%m;
}
LL gcd(LL x, LL y){
  return y == 0 ? x : gcd(y, x % y);
}
pair<LL,LL> linearCongruence(const vector<LL> &A,const vector<LL> &B,
                               const vector<LL> &M)
{
    int x=0,m=1;
    for(unsigned int i=0;i<A.size();i++)
    {
        int a=A[i]*m,b=B[i]-A[i]*x,d=gcd(M[i],a);
        if(b%d!=0) return make_pair(0,-1); //无解
        int t=b/d*modInverse(a/d,M[i]/d) % (M[i]/d);
        x=x+m*t;
        m*=M[i]/d;
    }
    return make_pair(x%m,m);
}
int main(){
  int k;
  while(~scanf("%d", &k)){
    vector<LL> A, B, M;
    A.clear(), B.clear(), M.clear();
    for(int i = 1; i <= k; i++){
      LL a, r;
      scanf("%lld%lld", &a, &r);
      A.push_back(1), B.push_back(r), M.push_back(a);
    }
    pair<LL, LL> xo = linearCongruence(A, B, M);
    if(xo.second == -1) printf("-1\n");
    else printf("%lld\n", xo.first);
  }
}
