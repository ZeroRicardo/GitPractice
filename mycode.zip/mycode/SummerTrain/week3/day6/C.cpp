#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
char str[2010];
int dp[2010][2010];
int ad[30], del[30];
int M, N;
int main()
{
  ios::sync_with_stdio(false);
  while(cin >> N >> M){
  cin >> str + 1;
  for(int i = 0; i < N; i++)
  {
    char cha;
    cin >> cha;
    cin >> ad[cha - 'a'] >> del[cha - 'a'];
  }
  memset(dp, 0x3f, sizeof dp);

  for(int l = 1; l <= M; l++)
  {
    dp[0][l] = 0;
    dp[1][l] = 0;
  }
  for(int len = 2; len <= M; len++)
  {
    for(int l = 1; l + len - 1<= M; l++)
    {
      int r = l + len - 1;
      if(str[l] == str[r])
        dp[len][l] = dp[len - 2][l + 1];
      else
        dp[len][l] =min(dp[len][l], min(dp[len - 1][l] + min(ad[str[r] - 'a'], del[str[r] - 'a']), dp[len - 1][l + 1] + min(ad[str[l] - 'a'], del[str[l] - 'a'])));
    }
  }
  cout << dp[M][1] << endl;
  }
  return 0;
}
