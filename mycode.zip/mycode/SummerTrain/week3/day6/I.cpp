#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
  int n, ans = 0;
  cin >> n;
  for(int i = 1; i <= n; i++)
  {
    int tmp;
    cin >> tmp;
    if(tmp <= 35)
      ans++;
  }
  cout << ans << endl;
  return 0;
}
