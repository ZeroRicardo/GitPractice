#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int a[1010];
int dp[1010];
int main()
{
  ios::sync_with_stdio(false);
  int n;
  cin >> n;
  for(int i = 1; i <= n; i++)
    cin >> a[i];
  memset(dp, 0, sizeof(dp));
  for(int i = 1; i <= n; i++)
    for(int j = 1; j < i; j++)
      if(a[i] > a[j])
      dp[i] = max(dp[i], dp[j] + 1);
  int ans = 0;
  for(int i = 1; i <= n; i++)
    ans = max(ans, dp[i]);
  cout << ans + 1<< endl;
  return 0;
}
