#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int inf = 0x3f3f3f3f;
int dp[40010];
int a[40010];
int g[40010];
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++)
      cin >> a[i];
    for(int i = 1; i <= n; i++)
      g[i] = inf;
    for(int i = 1; i <= n; i++)
    {
      dp[i] = lower_bound(g + 1, g + n + 1, a[i]) - g;
      g[dp[i]] = a[i];
    }
    int ans = 0;
    for(int i = 1; i <= n; i++)
      ans = max(ans, dp[i]);
    cout << ans << endl;
  }
}
