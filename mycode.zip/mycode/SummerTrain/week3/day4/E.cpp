#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
char str[110];
int dp[110][110];
int main()
{
  ios::sync_with_stdio(false);
  while(cin >> str + 1)
  {
    if(!strcmp(str + 1, "end")) break;
    int n = strlen(str + 1);
    memset(dp, 0, sizeof dp);
    for(int len = 2; len <= n; len++)
      for(int l = 1; l <= n - len + 1; l++)
      {
        int r = l + len - 1;
        if((str[l] == '(' && str[r] == ')') || (str[l] == '[' && str[r] == ']')) dp[l][r] = dp[l + 1][r - 1] + 2;

          for(int k = l; k < r; k++)
          {
            dp[l][r] = max(dp[l][r], dp[l][k] + dp[k + 1][r]);
          }

      //  cout << l << " " << r << " " << dp[l][r] << endl;
      }

    cout << dp[1][n] << endl;
  }
}
