#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
short f[5010][5010];
char str[5010];
int main()
{
  ios::sync_with_stdio(false);
  int n;
  cin >> n;
  cin >> str + 1;

  for(int len = 1; len <= n; len++)
    for(int l =  1; l <= n - len + 1; l++)
    {
      int r = l + len - 1;
      if(l == r ||(l + 1 == r && str[l] == str[r]))
        f[l][r] = 0;
      else if(str[l] == str[r])
        f[l][r] = f[l + 1][r - 1];
      else
      f[l][r] = min(f[l + 1][r], f[l][r - 1]) + 1;
    //  cout << l << " " << r << " " << f[l][r] << endl;
    }
    cout << f[1][n] << endl;
    return 0;
}
