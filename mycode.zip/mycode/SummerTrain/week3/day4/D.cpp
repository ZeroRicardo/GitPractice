#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
long long dp[110][110];
int a[110];
int main()
{
  ios::sync_with_stdio(false);
  int n;
  cin >> n;
  for(int i = 1; i <= n; i++)
    cin >> a[i];
  memset(dp, 0, sizeof dp);
  for(int len = 2; len < n; len++)
    for(int l = 2; l <= n - len + 1; l++)
    {
      int r = l + len - 1;
      dp[l][r] = 0x3f3f3f3f;
      for(int k = l; k < r; k++)
      dp[l][r] = min(dp[l][r], dp[l][k] + dp[k + 1][r] + a[l - 1] * a[k] * a[r]);
    //  cout << dp[l][r] << endl;
    }
  cout << dp[2][n] << endl;

}
