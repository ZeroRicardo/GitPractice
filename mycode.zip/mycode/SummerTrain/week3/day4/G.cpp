#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 50010;
int C[maxn];
int main()
{
  ios::sync_with_stdio(false);
  long long ans = 0;
  int n, x = 0, L;
  cin >> n >> L;
  for(int i = 1; i <= n; i++)
  {
    cin >> C[i];
  }
  x = C[1];
  for(int i = 2; i <= n; i++)
  {
    if(fabs(x + C[i] + 1 - L) < fabs(x - L))
    {
      x += C[i] + 1;
    }
    else
    {
      ans += (x - L) * (x - L);
      x = C[i];
    }
  }
  cout << ans << endl;
}
