#include <set>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 1000010;
int n, dat1[4 * maxn], dat2[4 * maxn], a[maxn], mina[maxn], maxa[maxn];
void init1(int n_)
{
  n = 1;
  while(n < n_) n *= 2;
  for(int i = 0; i <2 * n - 1; i++) dat1[i] = 0x3f3f3f3f;
}
void update1(int k, int a)
{
  k += n - 1;
  dat1[k] = a;
  while(k > 0)
  {
    k = (k - 1) / 2;
    dat1[k] = min(dat1[k * 2 + 1], dat1[k * 2 + 2]);
  }
}
int query1(int a, int b, int k, int l, int r)
{
  if(r <= a || b <= l)  return 0x3f3f3f3f;
  if(a <= l && r <= b)  return dat1[k];
  else{
    int vl = query1(a, b, k * 2 + 1, l, (l + r) / 2);
    int vr = query1(a, b, k * 2 + 2, (l + r) / 2, r);
    return min(vl, vr);
  }
}
void init2(int n_)
{
  n = 1;
  while(n < n_) n *= 2;
  for(int i = 0; i <2 * n - 1; i++) dat2[i] = -0x3f3f3f3f;
}
void update2(int k, int a)
{
  k += n - 1;
  dat2[k] = a;
  while(k > 0)
  {
    k = (k - 1) / 2;
    dat2[k] = max(dat2[k * 2 + 1], dat2[k * 2 + 2]);
  }
}
int query2(int a, int b, int k, int l, int r)
{
  if(r <= a || b <= l)  return -0x3f3f3f3f;
  if(a <= l && r <= b)  return dat2[k];
  else{
    int vl = query2(a, b, k * 2 + 1, l, (l + r) / 2);
    int vr = query2(a, b, k * 2 + 2, (l + r) / 2, r);
    return max(vl, vr);
  }
}
int main()
{
  int N, k;
  scanf("%d%d", &N, &k);
  {
    init1(N);
    init2(N);
    for(int i = 0; i < N; i++)
    {
      scanf("%d", &a[i]);
      update1(i, a[i]);
      update2(i, a[i]);
    }
    for(int i = 0; i <= N - k; i++)
    {
      mina[i] = query1(i, i + k, 0, 0, N);
      maxa[i] = query2(i, i + k, 0, 0, N);
    }
    for(int i = 0; i < N - k; i++)
      printf("%d ", mina[i]);
    printf("\n");
    for(int i = 0; i <= N - k; i++)
      printf("%d ", maxa[i]);
    printf("\n");

  }
  return 0;

}
