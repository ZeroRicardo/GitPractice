#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
const int inf = 0x3f3f3f3f;
int tot = 0;
struct EDGE{
  int to, next, c;
}E[MAX_E];
int level[MAX_V], head[MAX_V], thead[MAX_V];

int X[MAX_V], Y[MAX_V];
int S, T;

void addedge(int u, int v, int w)
{
  E[tot].to = v, E[tot].c = w, E[tot].next = head[u];
  head[u] = tot++;
  E[tot].to = u, E[tot].c = 0, E[tot].next = head[v];
  head[v] = tot++;
}
bool bfs(int s, int t)
{
  memset(level, -1, sizeof(level));
  queue<int> Q;
  Q.push(s);
  level[s] = 1;
  while(!Q.empty())
  {
    int u = Q.front();
    Q.pop();
    for(int i = head[u]; i != -1; i = E[i].next){
      int v = E[i].to;
      if(E[i].c > 0 && level[v] < 0){
        Q.push(v);
        level[v] = level[u] + 1;
      }
    }
  }
  if(level[t] != -1)  return true;
  else  return false;
}
int dfs(int u, int t, int f)
{

  if(u == t)  return f;
  for(int &i = thead[u]; i != -1; i = E[i].next)
  {
    int v = E[i].to;
    if(E[i].c <= 0 || level[v] <= level[u]) continue;
    int d = dfs(v, t, min(f, E[i].c));
    if(d > 0){
      E[i].c -= d;
      E[i + 1].c += d;
      return d;
    }
  }
  return 0;
}
int max_flow(int s, int t)
{
//  printf("t%d\n", t);
  int ans = 0;
  while(bfs(s, t))
  {
    memcpy(thead, head, sizeof(head));
    int f = 0;
    while(f = dfs(s, t, inf)){
      ans += f;
    }
  }
  return ans;
}
void init()
{
  tot = 0;
  memset(head, -1, sizeof(head));
}
int main()
{
  int CAS;
  scanf("%d", &CAS);
  while(CAS--)
  {
  //  printf("***");
    init();
    int m, n;
    int ans = 0;
    scanf("%d%d", &m, &n);
    S = m + n + 1, T = m + n + 2;
    for(int i = 1; i <= m; i++)
    {
      scanf("%d", &X[i]);
      addedge(S, i, X[i]);
      ans += X[i];
    }
    for(int i = 1; i <= n; i++)
    {
      scanf("%d", &Y[i]);
      addedge(i + m, T, Y[i]);
    }
    for(int i = 1; i <= m; i++)
    {
      int ttt = 0;
      scanf("%d", &ttt);
      for(int j = 0; j < ttt; j++)
      {
        int tmp;
        scanf("%d", &tmp);
        addedge(i, tmp + 1 + m, inf);
      }
    }
    ans -= max_flow(S, T);
    printf("%d\n", ans);
  }
  return 0;
}
