#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
const int inf = 0x3f3f3f3f;
int tot = 0;
struct EDGE{
  int to, next, c;
}E[MAX_E];
int level[MAX_V], head[MAX_V], thead[MAX_V];
struct point{
  double x, y;
  int num, C;
}P[300];
int N;
double D;
int S, T;
void addedge(int u, int v, int w)
{
  E[tot].to = v, E[tot].c = w, E[tot].next = head[u];
  head[u] = tot++;
  E[tot].to = u, E[tot].c = 0, E[tot].next = head[v];
  head[v] = tot++;
}
bool bfs(int s, int t)
{
  memset(level, -1, sizeof(level));
  queue<int> Q;
  Q.push(s);
  level[s] = 1;
  while(!Q.empty())
  {
    int u = Q.front();
    Q.pop();
    for(int i = head[u]; i != -1; i = E[i].next){
      int v = E[i].to;
      if(E[i].c > 0 && level[v] < 0){
        Q.push(v);
        level[v] = level[u] + 1;
      }
    }
  }
  if(level[t] != -1)  return true;
  else  return false;
}
int dfs(int u, int t, int f)
{

  if(u == t)  return f;
  for(int &i = thead[u]; i != -1; i = E[i].next)
  {
    int v = E[i].to;
    if(E[i].c <= 0 || level[v] <= level[u]) continue;
    int d = dfs(v, t, min(f, E[i].c));
    if(d > 0){
      E[i].c -= d;
      E[i + 1].c += d;
      return d;
    }
  }
  return 0;
}
int max_flow(int s, int t)
{
//  printf("t%d\n", t);
  int ans = 0;
  while(bfs(s, t))
  {
    memcpy(thead, head, sizeof(head));
    int f = 0;
    while(f = dfs(s, t, inf)){
      ans += f;
    }
  }
  return ans;
}
bool judge(int i, int j)
{
  return D*D >= (P[i].x - P[j].x) * (P[i].x - P[j].x) + (P[i].y - P[j].y) * (P[i].y - P[j].y);
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int judge_ans = 0;
    scanf("%d%lf", &N, &D);
    for(int i = 1; i <= N; i++)
    {
      double x, y;
      int num, C;
      scanf("%lf%lf%d%d", &x, &y, &num, &C);
      P[i].x = x, P[i].y = y, P[i].num = num, P[i].C = C;
      judge_ans += P[i].num;
    }
    S = 0;
    bool flag = false;
    for(int T = 1; T <= N; T++){
      memset(head, -1, sizeof(head));
      tot = 0;
      for(int i = 1; i <= N; i++)
      {
        addedge(i, i + N, P[i].C);
        if(P[i].num)
        addedge(S, i, P[i].num);
      }

      for(int i = 1; i <= N; i++){
        for(int j = 1; j <= N; j++)
        {
          if(i != j && judge(i, j))
          {
              addedge(i + N, j, P[i].C);
          }
        }
      }
      if(judge_ans == max_flow(S, T))
      {
        printf("%d ", T - 1);
        flag = 1;
      }
    }
    if(!flag) printf("-1");
    printf("\n");
}
  return 0;
}
