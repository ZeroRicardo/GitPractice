#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
const int inf = 0x3f3f3f3f;
int tot = 0;
struct EDGE{
  int to, next, c;
}E[MAX_E];
int level[MAX_V], head[MAX_V], thead[MAX_V];
int N, NP, NC, M;
int S, T;
void addedge(int u, int v, int w)
{
  E[tot].to = v, E[tot].c = w, E[tot].next = head[u];
  head[u] = tot++;
  E[tot].to = u, E[tot].c = 0, E[tot].next = head[v];
  head[v] = tot++;
}
bool bfs(int s, int t)
{
  memset(level, -1, sizeof(level));
  queue<int> Q;
  Q.push(s);
  level[s] = 1;
  while(!Q.empty())
  {
    int u = Q.front();
    Q.pop();
    for(int i = head[u]; i != -1; i = E[i].next){
      int v = E[i].to;
      if(E[i].c > 0 && level[v] < 0){
        Q.push(v);
        level[v] = level[u] + 1;
      }
    }
  }
  if(level[t] != -1)  return true;
  else  return false;
}
int dfs(int u, int t, int f)
{

  if(u == t)  return f;
  for(int &i = thead[u]; i != -1; i = E[i].next)
  {
    int v = E[i].to;
    if(E[i].c <= 0 || level[v] <= level[u]) continue;
    int d = dfs(v, t, min(f, E[i].c));
    if(d > 0){
      E[i].c -= d;
      E[i + 1].c += d;
      return d;
    }
  }
  return 0;
}
int max_flow(int s, int t)
{
  int ans = 0;
  while(bfs(s, t))
  {
    memcpy(thead, head, sizeof(head));
    int f = 0;
    while(f = dfs(s, t, inf)){
      ans += f;
    }
  }
  return ans;
}
int main()
{
  ios::sync_with_stdio(false);
  while(cin >> N >> NP >> NC >> M)
  {
    memset(head, -1, sizeof(head));
    tot = 0;
    S = N + 1, T = N + 2;
    int u, v, w;
    char tp;
    for(int i = 0; i < M; i++)
    {

      cin >> tp >> u >> tp >> v >> tp >> w;
    
      addedge(u, v, w);
    }
    for(int i = 0; i < NP; i++)
    {
      cin >> tp >> u >> tp >> w;
      addedge(S, u, w);
    }
    for(int i = 0; i < NC; i++)
    {
      cin >> tp >> u >> tp >> w;
      addedge(u, T, w);
    }
    int ans = max_flow(S, T);
    cout << ans << endl;
  }
  return 0;
}
