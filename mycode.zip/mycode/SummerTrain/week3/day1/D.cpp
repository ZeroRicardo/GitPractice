#include <bits/stdc++.h>
using namespace std;
#define MAX_V 10010
vector<int> G[MAX_V];
bool check[MAX_V];
int matching[MAX_V];
int num_left, num_nodes, num_right, num_edges;
char maze[52][52];
int n, m;
int tot;
void init();
void addedge(int u, int v)
{
  G[v].push_back(u), G[u].push_back(v);
}
bool dfs(int u)
{
  for(int i = 0; i < G[u].size(); i++)
  {
    int v = G[u][i];
    if(!check[v])
    {
      check[v] = true;
      if(matching[v] == -1 || dfs(matching[v]))
      {
        matching[v] = u;
        matching[u] = v;
        return true;
      }
    }
  }
  return false;
}
int hungarian()
{
  int ans = 0;
  memset(matching, -1, sizeof(matching));
  for(int u = 1; u <= num_left; u++)
  {
    if(matching[u] == -1)
    {
      memset(check, 0, sizeof(check));
      if(dfs(u))
        ans++;
    }
  }
  return ans;
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d%d", &m, &n);
    for(int i = 0; i < m; i++)
      for(int j = 0; j < n; j++)
        scanf(" %c", &maze[i][j]);
    tot = 0;
    init();
  //  printf("%d\n", tot);
    hungarian();
    int ans = tot * 2;
    for(int i = 1;  i <= m * m; i++)
    if(matching[i] != -1)
      ans--;
    printf("%d\n", ans / 2);
  }
}
void init()
{
  num_left = num_right = n * m;
  for(int i = 0; i <= 3000; i++)
    G[i].clear();
  for(int i = 0; i < m; i++)
  {
    for(int j = 0; j < n; j++)
    {
      if(maze[i][j] == '*')
      {
        tot++;
        for(int k = j + 1; k < n; k++)
        {
          if(maze[i][k] == '*')
            addedge(i * m + j + 1, i * m + k + 1);
          else
            break;
        }
      }
    }
  }
  for(int i = 0; i < n; i++)
  {
    for(int j = 0; j < m; j++)
    {
      if(maze[j][i] == '*')
      {
        for(int k = j + 1; k < m; k++)
        {
          if(maze[k][i] == '*')
            addedge(j * m + i + 1, k * m + i + 1);
          else
            break;
        }
      }
    }
  }
}
