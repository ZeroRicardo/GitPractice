#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
const int maxn = 510;
const int INF = 0x3f3f3f3f;
int value[maxn][maxn][maxn];
int left_ex[maxn][maxn], right_ex[maxn][1];
bool left_vis[maxn][maxn], right_vis[maxn][1];
int match[maxn], slack[maxn];
int cho[maxn];
int n;
bool dfs(int u, int k)
{
  left_vis[u][k] = true;
  for(int v = 0; v < n; v++){
    if(right_vis[v])  continue;
    int down = left_ex[u][k] + right_ex[v][0] - value[u][k][v];
    if(down == 0){
      right_vis[v][0] = true;
      if(match[v] == -1 || dfs(match[v], 0))
      {
        match[v] = u;
        return true;
      }
    }
    else
    {
      slack[v] = min(slack[v], down);
    }
  }
  return false;
}
int KM()
{
  memset(match, -1, sizeof(match));
  memset(right_ex, 0, sizeof(right_ex));
  memset(left_ex, 0, sizeof(left_ex));
  for(int i = 0; i < n; i++)
  {
    for(int k = 1; k < cho[i]; k++)
    for(int j = 0; j < n; j++){
      left_ex[i][k] = max(left_ex[i][k], value[i][k][j]);
    }
  }
  for(int i = 0; i < n; i++){
    for(int k = 1; k < cho[i]; k++){
    memset(slack, 0x3f, sizeof(slack));
    while(1)
    {
      memset(left_vis, 0, sizeof(left_vis));
      memset(right_vis, 0, sizeof(right_vis));
      if(dfs(i, k))  break;
      int d = INF;
      for(int j = 0; j < n; j++)
        if(!right_vis[j]) d = min(d, slack[j]);
      for(int j = 0; j < n; j++){
        for(int k = 1; k < cho[j]; k++)
        if(left_vis[j][k]) left_ex[j][k] -= d;
        if(right_vis[j][0])  right_ex[j][0] += d;
        else  slack[j] -= d;
      }
    }
  }
  }
  int res = 0;
  for(int i = 0; i < n; i++)
    res += value[match[i]][0][i];
  return res;
}
int main()
{

  while(~scanf("%d", &n))
  {
    for(int i = 0; i < n; i++)
      scanf("%d", &cho[i]);
     for(int i = 0; i < n; i++)
      for(int j = 0; j < n; j++)
      if(cho[j] == 0)
      {
        for(int k = 0; k < cho[i]; k++)
        value[i][k][j] = min(fabs(i - j), fabs(i + j  - 8));
      }
      int ans = KM();
      printf("%d\n", ans);
  }
  return 0;
}
