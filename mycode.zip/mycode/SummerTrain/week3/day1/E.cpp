#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
const int maxn = 510;
const int INF = 0x3f3f3f3f;
int value[maxn][maxn];
int left_ex[maxn], right_ex[maxn];
bool left_vis[maxn], right_vis[maxn];
int match[maxn], slack[maxn];
int n;
bool dfs(int u)
{
  left_vis[u] = true;
  for(int v = 0; v < n; v++){
    if(right_vis[v])  continue;
    int down = left_ex[u] + right_ex[v] - value[u][v];
    if(down == 0){
      right_vis[v] = true;
      if(match[v] == -1 || dfs(match[v]))
      {
        match[v] = u;
        return true;
      }
    }
    else
    {
      slack[v] = min(slack[v], down);
    }
  }
  return false;
}
int KM()
{
  memset(match, -1, sizeof(match));
  memset(right_ex, 0, sizeof(right_ex));
  memset(left_ex, 0, sizeof(left_ex));
  for(int i = 0; i < n; i++)
  {
    for(int j = 0; j < n; j++){
      left_ex[i] = max(left_ex[i], value[i][j]);
    }
  }
  for(int i = 0; i < n; i++){
    memset(slack, 0x3f, sizeof(slack));
    while(1)
    {
      memset(left_vis, 0, sizeof(left_vis));
      memset(right_vis, 0, sizeof(right_vis));
      if(dfs(i))  break;
      int d = INF;
      for(int j = 0; j < n; j++)
        if(!right_vis[j]) d = min(d, slack[j]);
      for(int j = 0; j < n; j++){
        if(left_vis[j]) left_ex[j] -= d;
        if(right_vis[j])  right_ex[j] += d;
        else  slack[j] -= d;
      }
    }
  }
  int res = 0;
  for(int i = 0; i < n; i++)
    res += value[match[i]][i];
  return res;
}
int main()
{

  while(~scanf("%d", &n))
  {
     for(int i = 0; i < n; i++)
      for(int j = 0; j < n; j++)
        scanf("%d", &value[i][j]);
      int ans = KM();
      printf("%d\n", ans);
  }
  return 0;
}
