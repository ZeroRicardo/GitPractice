#include <bits/stdc++.h>
using namespace std;
#define MAX_V 1010
vector<int> G[MAX_V];
bool check[MAX_V];
bool out[MAX_V][MAX_V];
int matching[MAX_V];
int num_left, num_nodes, num_right, num_edges;
bool flag;
void addedge(int u, int v){
   G[v].push_back(u), G[u].push_back(v);
}
bool dfs(int u)
{
  for(int i = 0; i < G[u].size(); i++)
  {
    int v = G[u][i];
    if(!check[v])
    {
      check[v] = true;
      if(matching[v] == -1 || dfs(matching[v]))
      {
        matching[v] = u;
        matching[u] = v;
        return true;
      }
    }
  }
  return false;
}
int hungarian()
{
  int ans = 0;
  memset(matching, -1, sizeof(matching));
  for(int u = 1; u <= num_left; u++)
  {
    if(matching[u] == -1)
    {
      memset(check, 0, sizeof(check));
      if(dfs(u))
        ans++;
    }
  }
  return ans;
}
int main()
{
  int k;
  while(~scanf("%d", &k) && k)
  {
    for(int i = 1; i <= 300; i++)
      G[i].clear();
    num_left = num_right = k;
    for(int i = 1; i <= k; i++)
      for(int j = 1; j <= k; j++)
      {
        int tmp;
        scanf("%d", &tmp);
        if(tmp)
          addedge(i, j + k);
      }
    flag = 1;
    hungarian();
    for(int i = 1; i <= k; i++)
    {
      if(matching[i] == -1)
      {
        flag = 0;
        break;
      }
    }
  //  printf("%d\n", flag);
    int cnt = 0;
    queue<pair<int, int> > q;
    while(!q.empty()) q.pop();
    if(flag)
    {
      int i, j;
      for(i = 1; i <= k; i++)
      {
        for(j = 1; j <= k; j++)
        {
          if(matching[j] == i + k)
            break;
        }
        if(i == j)  continue;
        q.push(make_pair(i, j));
        cnt++;
        swap(matching[i], matching[j]);
      }
      printf("%d\n", cnt);
      while(!q.empty())
      {
        pair<int, int> tmp = q.front();
        q.pop();
        printf("R %d %d\n", tmp.first, tmp.second);
      }
    }
    else
    {
        printf("-1\n");
    }
  }
  return 0;
}
