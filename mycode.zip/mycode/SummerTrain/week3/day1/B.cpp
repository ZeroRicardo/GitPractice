//HDU2063
#include <bits/stdc++.h>
using namespace std;
#define MAX_V 10010
struct Edge{
  int from, to, cost;
  Edge(int from, int to, int cost): from(from), to(to), cost(cost){}
};
vector<int> G[MAX_V];
vector<Edge> edges;
bool check[MAX_V];
int matching[MAX_V];
int num_left, num_nodes, num_right, num_edges;
void addedge(int u, int v)
{
  G[v].push_back(u), G[u].push_back(v);
}
bool dfs(int u)
{
  for(int i = 0; i < G[u].size(); i++)
  {
    int v = G[u][i];
    if(!check[v])
    {
      check[v] = true;
      if(matching[v] == -1 || dfs(matching[v]))
      {
        matching[v] = u;
        matching[u] = v;
        return true;
      }
    }
  }
  return false;
}
int hungarian()
{
  int ans = 0;
  memset(matching, -1, sizeof(matching));
  for(int u = 1; u <= num_left; u++)
  {
    if(matching[u] == -1)
    {
      memset(check, 0, sizeof(check));
      if(dfs(u))
        ans++;
    }
  }
  return ans;
}
int main()
{
  int k;
  while(~scanf("%d", &k) && k)
  {
    for(int i = 1; i <= 1100; i++)
      G[i].clear();
    scanf("%d%d", &num_left, &num_right);
    for(int i = 0; i < k; i++)
    {
      int u, v;
      scanf("%d%d", &u, &v);
      addedge(u, 500 + v);
    }
    int ans = hungarian();
    printf("%d\n", ans);
  }
  return 0;
}
//BFS版本抽空再更
