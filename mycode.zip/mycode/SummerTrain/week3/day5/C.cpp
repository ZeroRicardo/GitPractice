#include <bits/stdc++.h>
using namespace std;
int f[20][10], flag_0;
int getcnt(int x)
{
//  if(x == 0)  return 0;
  int bit[20], tot = 0;
  int ans = 0;
  while(x)
  {
    bit[++tot] = x % 10;
    x /= 10;
  }
  /*cout << tot << endl;
  for(int i = 0; i < tot; i++)
    cout << bit[i] << " ";
  cout << endl;*/
  for(int i = 1; i <= tot - 1; i++)
    for(int j = 1; j <= 9; j++)
    {
    //  cout << f[i][j] << endl;
      ans += f[i][j];
    }
  //cout << ans << endl;
  for(int i = 1; i < bit[tot]; i++)
    ans += f[tot][i];
  //cout << ans << endl;
  for(int i = tot - 1; i > 0; i--)
  {
    for(int j = 0; j < bit[i]; j++)
        if(fabs(j - bit[i + 1]) >= 2)
          ans += f[i][j];
    if(fabs(bit[i] - bit[i + 1]) < 2)
      break;
  }
  return ans;
}
int main()
{
  memset(f, 0, sizeof f);
  for(int i = 0; i <= 9; i++)
  {
    f[1][i] = 1;
  }
  for(int i = 2; i <= 10; i++)
  {
    for(int j = 0; j <= 9; j++)
      for(int k = 0; k <= 9; k++)
      {
        if(fabs(j - k) >= 2)
        {
          f[i][j] += f[i - 1][k];
        }
      }
  }
  int a, b;
//  cout << getcnt(51) << endl;
  cin >> a >> b;
  cout << getcnt(b + 1) - getcnt(a) << endl;
  return 0;

}
