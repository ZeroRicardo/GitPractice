#include <bits/stdc++.h>
using namespace std;
int main()
{
  int cnt = 0;
  for(int i = 1; i <= 10000; i++)
  {
    int tmp = i;
    int sum = 0;
    while(tmp)
    {
      sum += tmp % 10;
      tmp /= 10;
    }
    cnt += !(i % sum);
    if( i % sum == 0)
    {
      cout << i << " " << (i % 3 == 0) << " " << (i % 10 == 0) << endl; 
    }
  }
  return 0;
}
