#include <bits/stdc++.h>
using namespace std;
int cnt[10];
void PRINT()
{
  int sum = 0;
  for(int i = 0; i < 10; i++)
  {
    cout << cnt[i] << " ";
    sum += cnt[i];
  }
  cout << sum << endl;
}
int main()
{
    freopen("out.txt", "w", stdout);
    memset(cnt, 0, sizeof cnt);
    for(int i = 1; i <= 10000; i++)
    {
      int tmp = i;
      while(tmp)
      {
        cnt[tmp % 10]++;
        tmp /= 10;
      }
      if(i == 10 || i == 100 || i == 1000 || i == 110 || i == 1100 || i == 1110)
        PRINT();
    }
    return 0;
}
