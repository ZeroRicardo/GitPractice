#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define eps 1e-8
using namespace std;
struct Point{
  double x, y;
  Point(){};
  Point(double _x, double _y):x(_x), y(_y){}
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
struct Line{
  Point P1, P2;
}L[1000010];
int sgn(double x)
{
  if(fabs(x) < eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool check(Line l1, Line l2)
{
  return
  max(l1.P1.x,l1.P2.x) >= min(l2.P1.x,l2.P2.x) &&
  max(l2.P1.x,l2.P2.x) >= min(l1.P1.x,l1.P2.x) &&
  max(l1.P1.y,l1.P2.y) >= min(l2.P1.y,l2.P2.y) &&
  max(l2.P1.y,l2.P2.y) >= min(l1.P1.y,l1.P2.y) &&
  sgn((l2.P1-l1.P2)^(l1.P1-l1.P2))*sgn((l2.P2-l1.P2)^(l1.P1-l1.P2)) <= 0 &&
  sgn((l1.P1-l2.P2)^(l2.P1-l2.P2))*sgn((l1.P2-l2.P2)^(l2.P1-l2.P2)) <= 0;
}
void PrintLine(Line L)
{
  printf("(%.f, %.f)  (%.f, %.f)\n", L.P1.x, L.P1.y, L.P2.x, L.P2.y);
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int n;
    scanf("%d", &n);
    L[1].P1.x = 0, L[1].P1.y = 0;
    bool flag = 0;
    int ans;
    for(int i = 1; i <= n; i++)
    {
      int tmp;
      scanf("%d", &tmp);
      if(i % 4 == 1)
        L[i].P2.y = L[i].P1.y + tmp;
      else  if(i % 4 == 2)
        L[i].P2.x = L[i].P1.x + tmp;
      else  if(i % 4 == 3)
        L[i].P2.y = L[i].P1.y - tmp;
      else
        L[i].P2.x = L[i].P1.x - tmp;
      L[i + 1].P2.x = L[i + 1].P1.x = L[i].P2.x;
      L[i + 1].P2.y = L[i + 1].P1.y = L[i].P2.y;
    //  PrintLine(L[i]);
     if(!flag)
      {
        for(int j = 1; j <= 10 && i - j - 2 >= 1; j++)
        {
          if(check(L[i], L[i - j - 2]))
          {
          //  printf("%.f, %.f : %.f, %.f\n",L[i].P1.x, L[i].P1.y, L[i].P2.x, L[i].P2.y);
            ans = i;
            flag = 1;
            break;
          }
        }
      }
    }
    if(flag)  printf("%d\n", ans);
    else  printf("Catch you\n");
  }
}
