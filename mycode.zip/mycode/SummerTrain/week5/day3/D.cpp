#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
#define eps 1e-8
using namespace std;
struct Point{
  double x, y;
  Point(){};
  Point(double _x, double _y):x(_x), y(_y){}
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
struct Line{
  Point P1, P2;
}L[100010];
int sgn(double x)
{
  if(fabs(x) < eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool Seg_inter_line(Line l1,Line l2) //判断直线l1和线段l2是否相交
{
return sgn((l2.P2-l1.P1)^(l1.P2-l1.P1))*sgn((l2.P1-l1.P1)^(l1.P2-l1.P1)) <= 0;
}
int main()
{
  int T;
  int n;
  ios::sync_with_stdio(false);
  //scanf("%d", &T);
  cin >> T;
  while(T--)
  {
  //  scanf("%d", &n);
    cin >> n;
    for(int i = 1;i <= n; i++)
      //scanf("%lf%lf%lf%lf", &L[i].P1.x, &L[i].P1.y, &L[i].P2.x, &L[i].P2.y);
      cin >> L[i].P1.x >> L[i].P1.y >> L[i].P2.x >> L[i].P2.y;
    Line ans;
    bool flag = 0;
    for(int i = 1; i <= 2 * n; i++)
    {
      if(i % 2 == 1)
        ans.P1.x = L[(i + 1) / 2].P1.x, ans.P1.y = L[(i + 1) / 2].P1.y;
      else
        ans.P1.x = L[(i + 1) / 2].P2.x, ans.P1.y = L[(i + 1) / 2].P2.y;
      flag = 0;
      for(int j = 1; j <= 2 * n; j++)
      {
      //  if(i == j)  continue;
        flag = 1;
        if(j % 2 == 1)
          ans.P2.x = L[(j + 1) / 2].P1.x, ans.P2.y = L [(j + 1) / 2].P1.y;
        else
          ans.P2.x = L[(j + 1) / 2].P2.x, ans.P2.y = L[(j + 1) / 2].P2.y;
      //  printf("%d: %.f, %.f %d: %.f, %.f\n", i, ans.P1.x, ans.P1.y, j, ans.P2.x, ans.P2.y);
      //  if(fabs(ans.P1.x - ans.P2.x) < eps && fabs(ans.P1.y - ans.P2.y) < eps)  continue;
        for(int k = 1; k <= n; k++)
          if(!Seg_inter_line(ans, L[k]))
          {
            flag = 0;
            break;
          }
      if(flag)  break;
      }
      if(flag)  break;
    }
    //if(flag)  printf("Yes!\n");
    //else  printf("No!\n");
    if(flag)  cout << "Yes!" << endl;
    else  cout << "No!" << endl;
  }
}
