#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define eps 1e-8
using namespace std;
struct Point{
  double x, y;
  Point(){};
  Point(double _x, double _y):x(_x), y(_y){}
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
struct Line{
  Point P1, P2;
};
int sgn(double x)
{
  if(fabs(x) <= eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool Seg_inter_line(Line l1,Line l2) //判断直线l1和线段l2是否相交
{
return sgn((l2.P2-l1.P1)^(l1.P2-l1.P1))*sgn((l2.P1-l1.P1)^(l1.P2-l1.P1)) <= 0;
}
int main()
{
  Line SSR;
  scanf("%lf%lf%lf%lf", &SSR.P1.x, &SSR.P1.y, &SSR.P2.x, &SSR.P2.y);
  int n;
  scanf("%d", &n);
  int ans = 0;
  for(int i = 1; i <= n; i++)
  {
    Line tmp;
    double a, b, c;
    scanf("%lf%lf%lf", &a, &b, &c);
    double z1, z2;
    z1 = a * SSR.P1.x + b * SSR.P1.y + c;
    z2 = a * SSR.P2.x + b * SSR.P2.y + c;
    if(sgn(z1) * sgn(z2) < 0)
      ans++;
  }
  printf("%d\n", ans);
}
