#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
const double eps = 1e-8;
struct Point{
  int x, y;
  Point(){}
  Point(double _x, double _y):x(_x), y(_y){}
  long long operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
char op[1000010];
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    long long ans = 0;
    scanf(" %s", op);
    Point P1, P2, now(0, 0);
    if(strlen(op) <= 3) printf("0\n");
    else
    {
      for(int i = 0; op[i]; i++)
      {
        P1.x = P2.x, P1.y = P2.y;
        P2.x = now.x, P2.y = now.y;
        if(i >= 2)  ans += (P1 ^ P2);
        switch(op[i])
        {
          case '1': now.x = now.x - 1, now.y = now.y - 1; break;
          case '2': now.y = now.y - 1; break;
          case '3': now.x = now.x + 1, now.y = now.y - 1; break;
          case '4': now.x = now.x - 1; break;
          case '6': now.x = now.x + 1; break;
          case '7': now.x = now.x - 1, now.y = now.y + 1; break;
          case '8': now.y = now.y + 1; break;
          case '9': now.x = now.x + 1; now.y = now.y + 1; break;
        }
      }
      if(now.x == 0 && now.y == 0)
      {
        if(ans < 0) ans = -ans;
        if(ans % 2 == 0)  printf("%lld\n", ans / 2);
        else  printf("%lld.5\n", ans / 2);
      }
      else  printf("0\n");
    }
  }
}
