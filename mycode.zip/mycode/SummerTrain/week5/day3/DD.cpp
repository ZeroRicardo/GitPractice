#include <cstdio>
#include <cstring>
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;
const double eps = 1e-8;
struct Point{
  double x, y;
  Point(){}
  Point(double _x, double _y):x(_x), y(_y){}
  Point operator + (const Point &B)const{
    return Point(x + B.x, y + B.y);
  }
  Point operator - (const Point &B)const{
    return Point(x - B.x, y - B.y);
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
};
struct Line
{
  Point P[2];
};
ostream &operator <<(ostream &out, const Line &L)
{
  out << '(' << L.P[0].x << ", " << L.P[0].y << ')' << "; " << '(' << L.P[1].x << ", " << L.P[1].y << ')' ;
  return out;
}
Line L[100010];
int n;
int sgn(double x)
{
  if(fabs(x) < eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool check(Line L1, Line L2){
//  cout << L1 << "&&&" << L2 << endl;
//  cout << ((L2.P[1] - L1.P[0]) ^ (L1.P[1] - L1.P[0])) << "***" << ((L2.P[0] - L1.P[0]) ^ (L1.P[1] - L1.P[0])) << endl;
    return sgn((L2.P[1] - L1.P[0]) ^ (L1.P[1] - L1.P[0])) * sgn((L2.P[0] - L1.P[0]) ^ (L1.P[1] - L1.P[0])) <= 0;
}
bool judge()
{
  bool ret = 0;
  Line ans;
  for(int i = 1; i <= 2 * n; i++)
    for(int j = 1; j <= 2 * n; j++)
    {
      if(i == j)  continue;
      ans.P[0].x = L[(i + 1) / 2].P[(i + 1) % 2].x, ans.P[0].y = L[(i + 1) / 2].P[(i + 1) % 2].y;
      ans.P[1].x = L[(j + 1) / 2].P[(j + 1) % 2].x, ans.P[1].y = L[(j + 1) / 2].P[(j + 1) % 2].y;
      if(fabs(ans.P[0].x - ans.P[1].x) < eps && fabs(ans.P[0].y - ans.P[1].y) < eps)  continue;
      ret = 1;
      for(int k = 1; k <= n; k++)
        if(!check(ans, L[k]))
        {
          ret = 0;
          break;
        }
      if(ret == 1){
        return 1;
      }
    }
  return 0;
}
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
      cin >> L[i].P[0].x >> L[i].P[0].y >> L[i].P[1].x >> L[i].P[1].y;
  //    cout << L[i] << endl;
    }
    if(judge()) printf("Yes!\n");
    else  printf("No!\n");
  }
  return 0;
}
