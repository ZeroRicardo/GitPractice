#include <cstdio>
#include <cstring>
#include <cmath>
#include <queue>
#include <algorithm>
#define eps 1e-8
using namespace std;
struct Point{
  double x, y;
  Point(){};
  Point(double _x, double _y):x(_x), y(_y){}
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
struct Line{
  Point P1, P2;
}L[100010];
int sgn(double x)
{
  if(fabs(x) < eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool check(Line l1, Line l2)
{
  return
  max(l1.P1.x,l1.P2.x) >= min(l2.P1.x,l2.P2.x) &&
  max(l2.P1.x,l2.P2.x) >= min(l1.P1.x,l1.P2.x) &&
  max(l1.P1.y,l1.P2.y) >= min(l2.P1.y,l2.P2.y) &&
  max(l2.P1.y,l2.P2.y) >= min(l1.P1.y,l1.P2.y) &&
  sgn((l2.P1-l1.P2)^(l1.P1-l1.P2))*sgn((l2.P2-l1.P2)^(l1.P1-l1.P2)) <= 0 &&
  sgn((l1.P1-l2.P2)^(l2.P1-l2.P2))*sgn((l1.P2-l2.P2)^(l2.P1-l2.P2)) <= 0;
}
int ans[1010], tot;
int main()
{
  int n;
  while(~scanf("%d", &n) && n)
  {
    for(int i = 1; i <= n; i++)
      scanf("%lf%lf%lf%lf", &L[i].P1.x, &L[i].P1.y, &L[i].P2.x, &L[i].P2.y);
    tot = 0;
    for(int i = 1; i <= n; i++)
    {
      bool flag = 0;
      for(int j = i + 1; j <= n; j++)
        if(check(L[i], L[j]))
        {
          flag = 1;
          break;
        }
      if(!flag) ans[++tot] = i;
    }
    printf("Top sticks: ");
    for(int i = 1; i < tot; i++)
      printf("%d, ", ans[i]);
    printf("%d.\n", ans[tot]);
  }
  return 0;
}
