#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define eps 1e-8
using namespace std;
struct Point{
  double x, y;
  Point(){};
  Point(double _x, double _y):x(_x), y(_y){}
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
struct Line{
  Point P1, P2;
}L[20];
int sgn(double x)
{
  if(fabs(x) < eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool check(Line l1, Line l2)
{
  return
  max(l1.P1.x,l1.P2.x) >= min(l2.P1.x,l2.P2.x) &&
  max(l2.P1.x,l2.P2.x) >= min(l1.P1.x,l1.P2.x) &&
  max(l1.P1.y,l1.P2.y) >= min(l2.P1.y,l2.P2.y) &&
  max(l2.P1.y,l2.P2.y) >= min(l1.P1.y,l1.P2.y) &&
  sgn((l2.P1-l1.P2)^(l1.P1-l1.P2))*sgn((l2.P2-l1.P2)^(l1.P1-l1.P2)) <= 0 &&
  sgn((l1.P1-l2.P2)^(l2.P1-l2.P2))*sgn((l1.P2-l2.P2)^(l2.P1-l2.P2)) <= 0;
}
int par[30], ran[30];
void init(int n)
{
  for(int i = 1; i <= n; i++)
  {
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x)
{
  if(par[x] == x) return x;
  else  return par[x] = find(par[x]);
}
void unite(int x, int y)
{
  x = find(x), y = find(y);
  if(x == y)  return ;
  if(ran[x] < ran[y])
    par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
bool same(int x, int y){
  return find(x) == find(y);
}
int main()
{
  int n;
  double x1, x2, y1, y2;
  while(~scanf("%d", &n) && n)
  {
    for(int i = 1; i <= n; i++)
    {
      scanf("%lf%lf%lf%lf", &x1, &y1, &x2, &y2);
      L[i].P1 = Point(x1, y1), L[i].P2 = Point(x2, y2);
    }
    init(n);
    for(int i = 1; i <= n; i++)
      for(int j = i + 1; j <= n; j++)
      {
        if(check(L[i], L[j]))
          unite(i, j);
      }
    int a, b;
    while(~scanf("%d%d", &a, &b))
    {
      if(a == 0 && b == 0)  break;
      if(same(a, b))  printf("CONNECTED\n");
      else  printf("NOT CONNECTED\n");
    }
  }
}
