#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
const double eps = 1e-8;
struct Point{
  double x, y;
  Point(){}
  Point(double _x, double _y):x(_x), y(_y){}
  double operator ^ (const Point &B)const{
    return x * B.y - y * B.x;
  }
  double operator * (const Point &B)const{
    return x * B.x + y * B.y;
  }
  Point operator - (const Point &B)const{
    return  Point(x - B.x, y - B.y);
  }
  Point operator + (const Point &B)const{
    return  Point(x + B.x, y + B.y);
  }
  bool operator == (const Point &B)const{
    return fabs(x - B.x) <= eps && fabs(y - B.y) <= eps;
  }
};
struct Line{
  Point s, e;
}L[6000];
int sgn(double x)
{
  if(fabs(x) < eps) return 0;
  if(x < 0) return -1;
  else  return 1;
}
bool judge(Point P, Line A, Line B)
{
  return sgn((P - A.s) ^ (A.e - A.s)) * sgn((P - B.s) ^ (B.e - B.s)) <= 0;
}
int cnt[6010];
int main()
{
  int n, m;
  Point ST, ED;
  while(~scanf("%d", &n) && n)
  {
    scanf("%d%lf%lf%lf%lf", &m, &ST.x, &ST.y, &ED.x, &ED.y);
    L[0].s.x = ST.x, L[0].s.y = ED.y;
    L[0].e.x = ST.x, L[0].e.y = ST.y;
    L[n + 1].s.x = ED.x, L[n + 1].s.y = ED.y;
    L[n + 1].e.x = ED.x, L[n + 1].e.y = ST.y;
    for(int i = 1; i <= n; i++)
    {
      double x, y;
      scanf("%lf%lf", &x, &y);
      L[i].s.x = y, L[i].s.y = ED.y;
      L[i].e.x = x, L[i].e.y = ST.y;
    }
    memset(cnt, 0, sizeof cnt);
    for(int i = 1; i <= m; i++)
    {
      Point P;
      scanf("%lf%lf", &P.x, &P.y);
      for(int i = 0; i <= n; i++)
        if(judge(P, L[i], L[i + 1]))
        {
          cnt[i]++;
          break;
        }
    }
    for(int i = 0; i <= n; i++)
      printf("%d: %d\n", i, cnt[i]);
    printf("\n");
  }
  return 0;
}
