#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 100010;
int V;
struct Edge{
  int to, cost;
  Edge(int _to, int _cost):to(_to), cost(_cost){}
};
vector<Edge> G[MAX_V];
vector<int> flag;
int dis[MAX_V];
bool vis[MAX_V];
int ans;
void init()
{
  for(int i = 0; i < MAX_V; i++)
    G[i].clear();
  flag.clear();
}
void addedge(int u, int v, int w)
{
  G[u].push_back(Edge(v, w));
}
void ShortestPath(int num, int x)
{
//  printf("SSS:%d %d\n", num, x);
    priority_queue<pair<int, int> > q;
    memset(dis, 0x3f, sizeof dis);
    memset(vis, 0, sizeof vis);
    /*dis[s] = 0;
    vis[s] = 1;
    q.push(make_pair(0, s));*/
    for(int i = 0; i < flag.size(); i++)
    {
      int u = flag[i];
      if(((u >> num) & 1) == x)
      {
    //    printf("1:%d %d\n", num, u);
        dis[u] = 0;
        vis[u] = 1;
        q.push(make_pair(0, u));
      }
    }
    while(!q.empty())
    {
      int x = q.top().second;  q.pop();
      for(int i = 0; i < G[x].size(); i++)
      {
        int v = G[x][i].to, cost = G[x][i].cost;
        if(dis[v] > dis[x] + cost)
        {
          dis[v] = dis[x] + cost;
          //if(!vis[v])
          {
          //  vis[v] = 1;
            q.push(make_pair(-dis[v], v));
          }
        }
      }
    }
    for(int i = 0; i < flag.size(); i++)
    {
      int u = flag[i];
      if(((u >> num) & 1) != x)
      {
    //    printf("2:%d %d\n", num, u);
        ans = min(ans, dis[u]);
      }
    }
}
void PrintDis()
{
  for(int i = 1; i <= V; i++)
    printf("%d ", dis[i]);
  printf("\n");
}
void PrintVVV(int num)
{
  for(int i = 0; i < flag.size(); i++)
  {
    printf("%d ", (flag[i] >> num) & 1);
  }
  printf("\n");
}
int main()
{
  int T;
  scanf("%d", &T);
  for(int cas = 1; cas <= T; cas++)
  {
    int E;
    scanf("%d%d", &V, &E);
    init();
    for(int i = 1; i <= E; i++)
    {
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      addedge(u, v, w);
    }
    int K;
    scanf("%d", &K);
    for(int i = 1; i <= K; i++)
    {
      int u;
      scanf("%d", &u);
      flag.push_back(u);
    }
    /*for(int i = 1; i <= V; i++)
    {
      ShortestPath(i);
      PrintDis();
    }*/
    ans = 0x3f3f3f3f;
    for(int i = 0; i <= 16; i++)
    {
    //  PrintVVV(i);
      ShortestPath(i, 0);
      ShortestPath(i, 1);
    }
    printf("Case #%d: %d\n", cas, ans);
  }
}
