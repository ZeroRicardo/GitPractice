#include <bits/stdc++.h>
const int maxn = 100000;
int Tree[maxn + 10];
inline int lowbit(int x)
{
  return (x & -x);
}
void add(int x, int value)
{
  for(int i = x; i <= maxn; i += lowbit(i))
    Tree[i] += value;
}
int get(int x)
{
  int sum = 0;
  for(int i = x; i; i -= lowbit(i))
    sum += Tree[i];
  return sum;
}
int main()
{
  int T, cas = 1;
  scanf("%d", &T);
  while(T--)
  {
    printf("Case %d:\n", cas++);
    memset(Tree, 0, sizeof Tree);
    int n;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++){
      int a;
      scanf("%d", &a);
      add(i, a);
    }
    char op[10];
    while(1)
    {
      scanf(" %s", op);
      if(!strcmp(op, "End"))  break;
      if(!strcmp(op, "Query")){
        int l, r;
        scanf("%d%d", &l, &r);
        int ans = get(r) - get(l - 1);
        printf("%d\n", ans);
      }
      else if(!strcmp(op, "Add")){
        int pos, num;
        scanf("%d%d", &pos, &num);
        add(pos, num);
      }
      else if(!strcmp(op, "Sub")){
        int pos, num;
        scanf("%d%d", &pos, &num);
        add(pos, -num);
      }
    }
  }
}
