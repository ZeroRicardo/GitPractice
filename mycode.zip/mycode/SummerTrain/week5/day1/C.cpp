#include <bits/stdc++.h>
using namespace std;
int n, st, x;
int ans, nex;
int rad[50010];
bool flag = 0;
void query(int cnt)
{
  ans = -1, nex = st;
  srand(time(NULL));
  for(int i = 1; i <= n; i++) rad[i] = i;
  for(int i = 1; i <= 100; i++)
  random_shuffle(rad + 1, rad + n + 1);
  for(int i = 1; i <= cnt; i++)
  {
    int num = rad[i];
    printf("? %d\n", num);
    fflush(stdout);
    int tmp, pos;
    scanf("%d %d", &tmp, &pos);
    if(tmp <= x && ans < tmp){
      ans = tmp, nex = pos;
    }
  }
}
int main()
{
  scanf("%d%d%d", &n, &st, &x);
  int cnt = min(n, 1000);
  query(cnt);
    if(ans == x)  printf("! %d\n", ans);
    else
    {
      while(ans < x && nex != -1)
      {
        printf("? %d\n", nex);
        fflush(stdout);
        scanf("%d%d", &ans, &nex);
      }
      if(ans >= x)  printf("! %d\n", ans);
      else  printf("! -1\n");
    }
    fflush(stdout);
}
