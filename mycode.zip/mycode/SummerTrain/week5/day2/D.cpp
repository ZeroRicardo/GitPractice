#include <bits/stdc++.h>
using namespace std;
set<pair<int, int> > s;
set<pair<int, int> >::iterator ite;
int price[50010];
int main()
{
  int N;
  scanf("%d", &N);
  for(int i = 1; i <= N; i++)
    scanf("%d", &price[i]);
  for(int i = 1; i <= N - 1; i++)
  {
    int u, v;
    scanf("%d%d", &u, &v);
    s.insert(make_pair(u, v));
  }
  scanf("%d", &Q);
  for(int i = 1; i <= Q; i++)
  {
    int u, v;
    scanf("%d%d", &u, &v);
    if(s.find(make_pair(u,v)) != s.end())
      printf("%d\n" )
  }
}
