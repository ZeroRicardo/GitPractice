#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <stack>
#include <vector>
using namespace std;
#define MAX_V 5000
vector<int> G[MAX_V + 10];
int DFN[MAX_V + 10], LOW[MAX_V + 10],tot, index, a[MAX_V + 10];
int root[MAX_V + 10];
stack<int> s;
bool visit[MAX_V + 10];
void addedge(int u, int v) //u到v的单向边
{
  G[u].push_back(v);
}
void tarjan(int x)
{

  DFN[x] = LOW[x] = ++tot;

  s.push(x);
  visit[x] = 1;
  int sz = G[x].size();
  for(int i = 0; i < sz; i++)
  {
    if(!DFN[G[x][i]]){
      tarjan(G[x][i]);
      LOW[x] = min(LOW[x], LOW[G[x][i]]);
    }
    else  if(visit[G[x][i]]){
      LOW[x] = min(LOW[x], DFN[G[x][i]]);
    }
  }
  if(LOW[x] == DFN[x])
  {
    int sz = 0;
    while(x != s.top()){
        a[sz++] = s.top();
        visit[s.top()] = 0;
        root[s.top()] = x;
        s.pop();
    }
    a[sz++] = s.top();
    root[s.top()] = x;
    visit[s.top()] = 0;
    s.pop();
    sort(a, a + sz);
    bool flag = 1;

    for(int i = 0; i < sz; i++)
    {
      for(int j = 0; j < G[a[i]].size(); j++)
        if(root[G[a[i]][j]] != x)
        {
          flag = 0;
          break;
        }
    }
    if(flag)
    {
      for(int i = 0; i < sz; i++)
        printf("%d ", a[i]);
      printf("\n");
    }
  }
  return;
}
int main()
{
//  freopen("1.txt", "r", stdin);
  int n, m;
  while(~scanf("%d", &n)){
    if(n == 0)  break;
    scanf("%d", &m);
    memset(DFN, 0, sizeof(DFN));
    memset(visit, 0, sizeof(visit));
    memset(LOW, 0, sizeof(LOW));
    while(!s.empty()) s.pop();
    for(int i = 1; i <= n; i++)
      G[i].clear();
    tot = 0;
    for(int i = 1; i <= m; i++)
    {
      int u, v;
      scanf("%d%d", &u, &v);
      addedge(u, v);
    }
    for(int i = 1; i <= n; i++)
      if(!DFN[i]) tarjan(i);
  }
}
