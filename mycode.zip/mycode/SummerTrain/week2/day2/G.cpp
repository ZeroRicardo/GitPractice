#include <stdio.h>
#include <queue>
#include <vector>
#include <string.h>
using namespace std;
#define MAX_V 1000
vector<int> G[MAX_V + 10];
int in[MAX_V + 10], out[MAX_V + 10];
int N;
queue<int> L, S;
bool vis[28];
char name[110][110];
void addedge(int u, int v)
{
  G[u].push_back(v);
  in[v]++;
  out[u]++;
}
int main()
{
  memset(in, 0, sizeof(in));
  memset(out, 0, sizeof(out));
  memset(vis, 0, sizeof(vis));
  scanf("%d", &N);
  int u, v;
  bool flag = 1;
  for(int i = 1; i <= N; i++)
  {
      scanf(" %s", name[i]);
  }
  for(int i = 1; i <= N; i++)
    for(int j = i + 1; j <= N; j++)
    {
      int len1 = strlen(name[i]);
      int len2 = strlen(name[j]);
      if(len1 > len2)
      {
        bool tmpflag = 0;
        for(int k = 0; k < len2; k++)
          if(name[i][k] != name[j][k])
          {
            tmpflag = 1;
            break;
          }
        if(!tmpflag)  flag = 0;
      }
    }
  if(flag){
    for(int i = 1; i <= N - 1; i++)
    {
      int len1 = strlen(name[i]);
      int len2 = strlen(name[i + 1]);
    //  for(int j = 0; j < len1 && j < len2; j++)
      if(name[i][0] != name[i + 1][0])
        addedge(name[i][0] - 'a' + 1, name[i + 1][0] - 'a' + 1);
    }
    for(int i = 1; i <= 26; i++)
      if(in[i] == 0)
        S.push(i);
    while(!S.empty())
    {
      int u = S.front(); S.pop();
      L.push(u);
      int sz = G[u].size();
      for(int j = 0; j < sz; j++)
      {
        in[G[u][j]]--;
        if(in[G[u][j]] == 0)
        S.push(G[u][j]);
      }
    }
    for(int i = 1; i <= 26; i++)
      if(in[i])
      {
        flag = 0;
        break;
      }

    if(!flag)  printf("Impossible\n");
    else
    {
      while(!L.empty())
      {
        vis[L.front()] = 1;
        printf("%c", L.front() - 1 + 'a');
        L.pop();
      }
      for(int i = 1;i <= 26; i++)
        if(!vis[i])
        printf("%c", i - 1 + 'a');
      printf("\n");
    }
  }
  else
    printf("Impossible\n");
}
