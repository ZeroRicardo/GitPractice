#include <stdio.h>
#include <algorithm>
#include <string.h>
using namespace std;
#define MAX_V 1000
#define MAX_E 100000
struct Edge{
  int to, next;
  bool cut;
}edge[MAX_E + 10];
int head[MAX_V + 10], tot;
int LOW[MAX_V + 10], DFN[MAX_V + 10], Stack[MAX_V + 10];
int Index, top;
bool Instack[MAX_V + 10];
bool cut[MAX_V + 10];
int add_block[MAX_V + 10];
int bridge;
int V;
void addedge(int u, int v)
{
  edge[tot].to = v; edge[tot].next = head[u]; edge[tot].cut = false;
  head[u] = tot++;
  edge[tot].to = u, edge[tot].next = head[v]; edge[tot].cut = false;
  head[v] = tot++;
}
void Tarjan(int u, int pre)
{
  int v;
  LOW[u] = DFN[u] = ++Index;
  Stack[top++] = u;
  Instack[u] = true;
  int son = 0;
  for(int i = head[u]; i != -1; i = edge[i].next)
  {
    v = edge[i].to;
    if(v == pre)  continue;
    if(!DFN[v])
    {
      son++;
      Tarjan(v, u);
      if(LOW[u] > LOW[v]) LOW[u] = LOW[v];
      if(LOW[v] > DFN[u])
      {
        bridge++;
        edge[i].cut = true;
        edge[i ^ 1].cut = true;
      }
      if(u != pre && LOW[v] >= DFN[u])
      {
        cut[u] = true;
        add_block[u]++;
      }
    }
    else if(LOW[u] > DFN[v])
      LOW[u] = DFN[v];
  }
  if(u == pre && son > 1) cut[u] = true;
  if(u == pre)  add_block[u] = son - 1;
  Instack[u] = false;
  top--;
}
int main(){
  int u, v;
  int cas = 1;
  while(~scanf("%d", &u)){
    if(u == 0)  break;
    tot = 0;
    Index = top = 0;
    bridge = 0;
    memset(DFN, 0, sizeof(DFN));
    memset(Instack, 0, sizeof(Instack));
    memset(add_block, 0, sizeof(add_block));
    memset(head, -1, sizeof(head));
    memset(cut, 0, sizeof(cut));
    scanf("%d", &v);
    V = max(u, v);

    addedge(u, v);
    while(~scanf("%d", &u))
    {
      if(u == 0)   break;
      scanf("%d", &v);
      V = max(V, max(u, v));
      addedge(u, v);
    }
    for(int i = 1; i <= V; i++)
      if(!DFN[i])
      {
      //  ComponentNumber = 1;
        Tarjan(i, i);
      }
    printf("Network #%d\n", cas++);
    bool flag = 0;
    for(int i = 1; i <= V; i++)
      if(cut[i]){
        printf("  SPF node %d leaves %d subnets\n", i, add_block[i] + 1);
        flag = 1;
      }
    if(!flag)
      printf("  No SPF nodes\n");
    printf("\n");
  }
}
