#include <bits/stdc++.h>
using namespace std;
#define MAX_N 100010
struct node{
  int key;
  node *l, *r;
}*Tree[MAX_N];
int find(int x)
int main()
{
  return 0;
}
