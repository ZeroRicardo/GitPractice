#include <bits/stdc++.h>
using namespace std;
queue<int> q[1010];
queue<int> no;      //队伍入队序号
bool getin[1010];   //队伍入队标记
map<int, int> se;    //元素序号和队伍编号
int main()
{
  //freopen("in.txt", "r", stdin);
  int cas = 1, n;
  while(~scanf("%d", &n) && n)
  {
    if(n == 0)  break;
    printf("Scenario #%d\n", cas++);
    for(int i = 0; i <= 1000; i++)
      while(!q[i].empty())  q[i].pop();
    while(!no.empty())  no.pop();
    memset(getin, 0, sizeof(getin));
    se.clear();
    //初始将所有元素与其队伍编号插入map,便于查找
    for(int i = 0; i < n; i++)
    {
      int t;
      scanf("%d", &t);
      for(int j = 0; j < t; j++)
      {
        int temp;
        scanf("%d", &temp);
        se[temp] = i;
      }
    }
    //入队出队操作
    char op[50];
    int num, id;
    while(1)
    {
      scanf(" %s", op);
      if(!strcmp(op, "STOP")) break;
      else if(!strcmp(op, "ENQUEUE"))
      {
        scanf("%d", &num);
        id = se[num];
        if(!getin[id])
        {
          no.push(id);
          getin[id] = 1;
        }
        q[id].push(num);
      }
      else if(!strcmp(op, "DEQUEUE"))
      {
        int teamno = no.front();
        int team = q[teamno].front();
        printf("%d\n", team);
        q[teamno].pop();
        if(q[teamno].empty())
        {
          no.pop();
          getin[teamno] = 0;
        }
      }
    }
    printf("\n");
  }
}
