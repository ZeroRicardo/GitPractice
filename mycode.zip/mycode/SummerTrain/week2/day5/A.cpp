#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
map<long long, bool> s;
map<long long, bool>:: iterator ite, it2;
int main()
{
  int n, k;
  scanf("%d%d", &n, &k);
  for(int i = 0; i < n; i++)
  {
    long long tmp;
    scanf("%lld", &tmp);
    s[tmp] = 1;
  }
  long long  ans = 0;
  for(ite = s.begin(); ite != s.end(); ite++)
  {
    if((*ite).second)
    {
      ans++;
      it2 = s.find((*ite).first * k);
      if(it2 != s.end())
        (*it2).second = 0;
    }
  }
  printf("%lld\n", ans);
}
