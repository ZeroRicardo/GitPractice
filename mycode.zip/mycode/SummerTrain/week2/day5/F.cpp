#include <bits/stdc++.h>
using namespace std;
#define  ll long long
#define  LL long long
const int maxn = 100010;
struct node{
  ll height, widght;
  bool operator < (const node b)const{
    return height < b.height;
  }
};
node alice[maxn], bob[maxn];
multiset<long long> s;
multiset<long long>::iterator ite2;
multiset<long long>::reverse_iterator ite;
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int n;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
    {
      scanf("%lld%lld", &alice[i].height, &alice[i].widght);
    }
    for(int i = 1; i <= n; i++)
    {
      scanf("%lld%lld", &bob[i].height, &bob[i].widght);
    }
    sort(alice + 1, alice + n + 1);
    sort(bob + 1, bob + 1 + n);
    s.clear();
    int  j = 1;
    int ans = 0;
    for(int i = 1; i <= n; i++)
    {
      for(; j <= n; j++)
      {
        if(alice[i].height >= bob[j].height)
        {
      //    printf("\n%d %d\n", i, j);
          s.insert(bob[j].widght);
        }
        else break;
      }
      if(!s.empty())
      {
        ite2 = s.lower_bound(alice[i].widght);
        if(ite2 == s.begin() && *ite2 > alice[i].widght) continue;
        if(ite2 == s.end() || *ite2 > alice[i].widght)  ite2--;
        if(*ite2 <= alice[i].widght)
        {
        //  printf("%d %d\n", i, j);
          ans++;
          s.erase(ite2);
        }
      }
    }
    printf("%d\n", ans);
  }
}
