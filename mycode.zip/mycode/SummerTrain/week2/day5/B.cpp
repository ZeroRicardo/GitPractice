#include <bits/stdc++.h>
using namespace std;
multimap<long long, long long> mmp;
multimap<long long, long long>::iterator ite1, ite2;
int main()
{
  int n;
  while(~scanf("%d", &n) && n)
  {
    mmp.clear();
    mmp.insert(make_pair(1000000000, 1));
    for(int i = 1; i <= n; i++)
    {
      long long id, grade;
      scanf("%lld%lld", &id, &grade);
      mmp.insert(make_pair(grade, id));
      ite2 = ite1 = mmp.upper_bound(grade);
      if(ite2 != mmp.begin())
        ite2--;
      if(ite2 != mmp.begin())
        ite2--;
      if((*ite2).second == id)  ite2++;
      if((*ite2).first + (*ite1).first < 2 * grade)
        printf("%lld %lld\n", id, (*ite1).second);
      else
        printf("%lld %lld\n", id, (*ite2).second);
    }
  }
}
