#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;
#define MAX_V 100000
#define MAX_E 10000
#define INF 0x3f3f3f3f
struct edge{
  int to, cost;
};
int V, E, K;
vector<edge> G[MAX_V + 10];
int cnt[MAX_V + 10];
int dis[MAX_V + 10], dis2[MAX_V + 10];
int a[MAX_V + 10];
void addedge(int u,int v,int w)
{
  edge a, b;
  a.to = u, a.cost = w;
  b.to = v, b.cost = w;
  G[u].push_back(b);
  G[v].push_back(a);
}
int dijkstra(int s)
{
  int ret = 0;
  priority_queue<int, vector<int>, greater<int> > que;
  memset(dis, 0x3f, sizeof(dis));
  dis[s] = 0;
  que.push(s);
  while(!que.empty()){
    int v = que.top();que.pop();
    for(int i = 0; i < G[v].size(); i++){
      edge e = G[v][i];
      if(dis[e.to] > dis[v] + e.cost){

        dis[e.to] = dis[v] + e.cost;
        que.push(e.to);
      }
    }
  }

  memset(dis2, 0x3f, sizeof(dis2));
  dis2[s] = 0;
  que.push(s);
  while(!que.empty()){
    int v = que.top();que.pop();
    for(int i = 0; i < G[v].size(); i++){
      edge e = G[v][i];
      if(dis2[e.to] > dis2[v] + e.cost){

        dis2[e.to] = dis2[v] + e.cost;
        if(dis2[e.to] == dis[e.to]) cnt[e.to]++;
        que.push(e.to);
      }
      else if(dis2[e.to] == dis[e.to]) cnt[e.to]++;
    }
  }
  return ret;
}
int main()
{
  scanf("%d%d%d", &V, &E, &K);
  for(int i = 1; i <= E; i++)
  {
    int u, v, w;
    scanf("%d%d%d", &u, &v, &w);
    addedge(u, v, w);
  }
  memset(cnt, 0, sizeof(cnt));
  for(int i = 1; i <= K; i++)
  {
    int w;
    scanf("%d%d", &a[i], &w);
    addedge(1, a[i], w);
  }
  dijkstra(1);
  int ans = 0;
  for(int i = 1; i <= K; i++)
    ans += cnt[a[i]] - 1;
  printf("%d\n", ans);
}
