#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;
#define maxn 100
bool dis[maxn + 10][maxn + 10];
int ran[maxn + 10];
int n, M;
void Floyd()
{
  for(int k = 1; k <= n; k++)
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= n; j++)
      {
        if(dis[i][k] == 1 && dis[k][j] == 1)  dis[i][j] = 1;
        else  if(dis[i][k] == -1 && dis[k][j] == -1) dis[i][j] = -1;
      }

}
int main()
{
  memset(dis, 0, sizeof(dis));
  scanf("%d%d", &n, &M);
  memset(ran, 0, sizeof(ran));
  for(int i = 1; i<= M; i++)
  {
    int a, b;
    scanf("%d%d", &a, &b);
    dis[a][b] = 1;
    dis[b][a] = -1;
  }
  Floyd();
  int ans = 0;

  for(int i = 1; i <= n; i++)
  {
    int sum = 0;
    for(int j = 1; j <= n; j++)
      if(dis[i][j])
        sum++;
    if(sum == n - 1)
      ans++;
  }
  printf("%d\n", ans);

}
