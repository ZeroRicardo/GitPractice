#include <bits/stdc++.h>
using namespace std;
#define MAX_V 1000
#define MAX_E 10000
#define INF 0x3f3f3f3f
struct edge{
  int to, cost;
};
int V, E;
int T, S, D;
vector<edge> G[MAX_V + 10];
int dis[MAX_V + 10];

void addedge(int u,int v,int w)
{
  edge a, b;
  a.to = u, a.cost = w;
  b.to = v, b.cost = w;
  G[u].push_back(b);
  G[v].push_back(a);
}

void dijkstra(int s)
{
  priority_queue<int, vector<int>, greater<int> > que;
  memset(dis, 0x3f, sizeof(dis));
  dis[s] = 0;
  que.push(s);
  while(!que.empty()){
    int v = que.top();que.pop();
    for(int i = 0; i < G[v].size(); i++){
      edge e = G[v][i];
      if(dis[e.to] > dis[v] + e.cost){
        dis[e.to] = dis[v] + e.cost;
        que.push(e.to);
      }
    }
  }
}



int main()
{
  while(~scanf("%d%d%d", &T, &S, &D)){
    memset(dis, 0x3f, sizeof(dis));
    for(int i = 0; i <= 1000; i++)
      G[i].clear();
    for(int i = 0; i < T; i++)
    {
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      addedge(u, v, w);
    }
    for(int i = 0; i < S; i++){
      int tmp;
      scanf("%d", &tmp);
      addedge(0, tmp, 0);
    }
    dijkstra(0);
    int ans = 0x3f3f3f3f;
    for(int i = 0; i < D; i++)
    {
      int tmp;
      scanf("%d", &tmp);
      ans = min(dis[tmp], ans);
    }
    printf("%d\n", ans);
  }
}
