#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;
#define MAX_V 110
#define MAX_E 1000
#define INF 0x3f3f3f3f
int n, m;
struct Edge{
  int u, v, w;
  bool operator >(const struct Edge x)const{
    return w > x.w;
  }
}edge[10010];
int fa[10010];
bool cmp(struct Edge a, struct Edge b)
{
  return a.w < b.w;
}
int getfather(int x){
  if(x == fa[x])  return x;
  else return fa[x] = getfather(fa[x]);
}
int kruskal(){
    int ans = 0x3f3f3f3f;
    sort(edge + 1, edge + 1 + m, cmp);

    for(int k = 1; k <= m; k++){
      int cnt = n;
      for(int i = 1; i <= n; i++)
        fa[i] = i;
      int maxt = 0, mint = 0x3f3f3f3f, tmp = 0;
      bool flag = 0;

      for(int i = k; i <= m; i++){
        int t1 = getfather(edge[i].u);
        int t2 = getfather(edge[i].v);
          if(t1 != t2){
            cnt--;
            fa[t1] = t2;
            maxt = max(maxt, edge[i].w);
            mint = min(mint, edge[i].w);
            tmp += edge[i].w;
            if(cnt == 1){
              flag = 1;
              break;
            }
          }
      }
      if(!flag) break;
      ans = min(ans, maxt - mint);
    //  printf("%d\n", tmp);
    }
    if(ans == 0x3f3f3f3f) ans = -1;
    return ans;
}
int main()
{
  while(~scanf("%d%d", &n, &m) && (n != 0 || m != 0))
  {
    for(int i = 1; i <= m; i++)
      scanf("%d%d%d", &edge[i].u, &edge[i].v, &edge[i].w);
    printf("%d\n", kruskal());
  }

}
