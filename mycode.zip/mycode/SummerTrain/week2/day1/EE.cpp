#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
int V, E;
struct Edge{
  int from, to, cost;
  Edge(){}
  Edge(int _from, int _to, int _cost):from(_from), to(_to), cost(_cost){}
  bool operator < (const Edge &x)const{
    return cost < x.cost;
  }
}edge[MAX_E];
int tot = 0;
void addedge(int u, int v, int w)
{
  edge[tot] = Edge(u, v, w);
  tot++;
}
int par[MAX_V], ran[MAX_V];
void init(int n)
{
  for(int i = 1; i <= n; i++){
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x)
{
  if(par[x] == x) return x;
  else  return par[x] = find(par[x]);
}
void unite(int x, int y)
{
  x = find(x), y = find(y);
  if(x == y)  return ;
  if(ran[x] < ran[y])
    par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
int kruskal()
{
  sort(edge, edge + E);
  int ret = 0x3f3f3f3f;
  for(int k = 0; k < E; k++)
  {
    int maxt = 0, mint = 0x3f3f3f3f, cnt = V;
    init(V);
    for(int i = k; i < E; i++)
    {
      int t1 = edge[i].from, t2 = edge[i].to, cost = edge[i].cost;
      if(find(t1) != find(t2))
      {
    //    printf("%d\n", i);
        unite(t1, t2);
        cnt--;
        maxt = max(maxt, cost);
        mint = min(mint, cost);
        if(cnt == 1)  break;
      }
    }
    if(cnt == 1)
      ret = min(ret, maxt - mint);
    else
      break;
  }
  if(ret == 0x3f3f3f3f) ret = -1;
  return ret;
}
int main()
{
  while(~scanf("%d%d", &V, &E))
  {
    if(V == 0 && E == 0)  break;
    tot = 0;
    for(int i = 0; i < E; i++)
    {
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      addedge(u, v, w);
    }
    printf("%d\n", kruskal());
  }
  return 0;
}
