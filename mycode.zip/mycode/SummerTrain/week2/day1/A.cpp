#include <bits/stdc++.h>
using namespace std;
#define MAX_V 30000
#define MAX_E 10000
#define INF 0x3f3f3f3f
int n, t;
vector<int> G[MAX_V + 10];
int a[MAX_V + 10];
bool vis[MAX_V + 10];
void addedge(int u, int v)
{
  G[u].push_back(v);
}
bool flag = 0;
void dfs(int v)
{
  if(flag ||  v == t){
    flag = 1;
    return;
  }
  int sz = G[v].size();
  for(int j = 0; j < sz; j++)
  if(!vis[G[v][j]])
  {
    vis[G[v][j]] = 1;
    dfs(G[v][j]);
  }
}
int main()
{
  scanf("%d%d", &n, &t);
  for(int i = 1; i <= n - 1; i++)
  {
    scanf("%d", &a[i]);
    addedge(i, i + a[i]);
  }
  memset(vis, 0, sizeof(vis));
  flag = 0;
  vis[1] = 1;
  dfs(1);
  if(flag)  printf("YES\n");
  else   printf("NO\n");
}
