#include <stdio.h>
#include <algorithm>
#include <string.h>
using namespace std;
#define MAX_V 100
#define MAX_E 100
#define INF 0x3f3f3f3f
int cost[MAX_V + 10][MAX_V + 10];
int mincost[MAX_V + 10];
bool used[MAX_V];
int V;
int prim(){
  for(int i = 1; i <= V; i++){
    mincost[i] = INF;
    used[i] = 0;
  }
  mincost[1] = 0;
  int res = 0;
  while(true){
    int v = -1;
    for(int u = 1; u <= V; u++){
      if(!used[u] && (v == -1 || mincost[u] < mincost[v]))
        v = u;
    }
    if(v == -1) break;
    used[v] = true;
  //  if(mincost[v] < INF)
      res += mincost[v];
    for(int u = 1; u <= V; u++)
      mincost[u] = min(mincost[u], cost[v][u]);
  }
  return res;
}
int main()
{

  while(~scanf("%d", &V) && V)
  {

    char str[1010], c;
    int u, v, w, num;
    memset(cost, 0x3f, sizeof(cost));
    memset(used, 1, sizeof(used));
    for(int k = 0; k < V - 1; k++)
    {
      scanf(" %c %d", &c, &num);
    //  printf("%c %d\n", c, num);
      u = c - 'A' + 1;
    //  used[u] = 0;
      for(int i = 0; i < num; i++){
        scanf(" %c %d", &c, &w);
    //    printf("%c %d\n", c, w);
        v = c - 'A' + 1;
    //    used[v] = 0;
        cost[u][v] = min(cost[u][v], w);
        cost[v][u] = cost[u][v];
      }
    }

    printf("%d\n", prim());
  }
}
