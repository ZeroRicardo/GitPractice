#include <stdio.h>
#include <queue>
#include <vector>
#include <string.h>
using namespace std;
#define MAX_V 500
int in[MAX_V + 10], out[MAX_V + 10];
int N, M;
vector<int> G[MAX_V + 10];
priority_queue<int, vector<int>, greater<int> > S;
queue<int> L;
bool vis[MAX_V + 10];

void addedge(int u, int v)
{
  G[u].push_back(v);
  in[v]++;
  out[u]++;
}
int main()
{
  while(~scanf("%d%d", &N, &M)){
      memset(in, 0, sizeof(in));
      memset(out, 0, sizeof(out));
      memset(vis, 0, sizeof(vis));

      for(int i = 1; i <= N; i++)
        G[i].clear();
      for(int i = 0; i < M; i++)
      {
        int u, v;
        scanf("%d%d", &u, &v);
        addedge(u, v);
      }
    //  printf("%d\n", in[3]);
        for(int i = 1; i <= N; i++)
          if(in[i] == 0)
            S.push(i);
        while(!S.empty())
        {
          int u = S.top(); S.pop();
    //      printf("%d\n", u);
          L.push(u);
          int sz = G[u].size();
          for(int j = 0; j < sz; j++)
          {
            in[G[u][j]]--;
            if(in[G[u][j]] == 0)
            S.push(G[u][j]);
          }
        }
        bool first = 1;
          while(!L.empty())
          {

            if(first){
              first = 0;
              printf("%d", L.front());
            }
            else
            {
              printf(" %d", L.front());
            }

            L.pop();
          }
          printf("\n");

    }
}
