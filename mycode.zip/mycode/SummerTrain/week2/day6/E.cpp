#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;
const int maxn = 1000010;
struct node{
  int x, id;
};
node a[maxn], b[maxn], c[maxn];
long long num[maxn][2];
long long ans;
void mergesort1(int l,int r){
	int mid=(l+r)/2,i,j,k;
	if(l<mid)mergesort1(l,mid);
	if(mid+1<r)mergesort1(mid+1,r);
	i=l;j=mid+1;k=l;
	bool flag = 1;
	while(i<=mid || j<=r){
		if(j>r)b[k++]=a[i++];
		else if(i>mid)b[k++]=a[j++];
		else if(a[i].x<= a[j].x)
		{
			b[k++]=a[i++];
		}
		else {
			num[a[j].id][0] += mid - i + 1;
      b[k++]=a[j++];
		}
	}
	for(int i=l;i<=r;i++)a[i]=b[i];
}
void mergesort2(int l,int r){
	int mid=(l+r)/2,i,j,k;
	if(l<mid)mergesort2(l,mid);
	if(mid+1<r)mergesort2(mid+1,r);
	i=l;j=mid+1;k=l;
	bool flag = 1;
	while(i<=mid || j<=r){
		if(j>r)b[k++]=c[i++];
		else if(i>mid)b[k++]=c[j++];
		else if(c[i].x >= c[j].x)
		{
			b[k++]=c[i++];
		}
		else {
    //  printf("****");
			num[c[j].id][1] += mid - i + 1;
      b[k++]=c[j++];
		}
	}
	for(int i=l;i<=r;i++)c[i]=b[i];
}

int main()
{
  int n;

    while(~scanf("%d", &n)){
    if(n == 0)  break;
    memset(num, 0, sizeof(num));

    for(int i = 0, j = n - 1; i < n; i++, j--)
    {
      scanf("%d", &a[i].x);
      a[i].id = i;
      c[j] = a[i];
    }
    ans = 0;
		mergesort1(0, n - 1);
    mergesort2(0, n - 1);
//    for(int i = 0; i < n; i++)
  //    printf("%d\n", A[i]);
    for(int i = 0; i < n; i++){
    //  printf("%d %d\n", num[i][0], num[i][1]);
      ans += num[i][0] * num[i][1];
    }
    printf("%lld\n", ans);
  }
}
