#include <bits/stdc++.h>
using namespace std;
#define MAX_V 200000
#define MAX_E 10000
#define INF 0x3f3f3f3f
int V, E;
vector<int> G[MAX_V + 10];
set<int> res, dle, add;
set<int>::iterator ite;
int dis[MAX_V + 10];
void addedge(int u,int v)
{
  G[u].push_back(v);
  G[v].push_back(u);
}
void dijkstra(int s)
{
  priority_queue<int, vector<int>, greater<int> > que;
  memset(dis, 0x3f, sizeof(dis));
  dis[s] = 0;
  que.push(s);
  dle.clear();
  add.clear();
  dle.insert(s);
  while(!que.empty()){
    int v = que.top();que.pop();
    for(int i = 0; i < G[v].size(); i++)
    {
      if(res.find(G[v][i]) != res.end())
      {
        add.insert(G[v][i]);
        res.erase(G[v][i]);
      }
    }
      for(ite = res.begin(); ite != res.end(); ite++)
      {
        int u = *ite;
        if(dis[u] > dis[v] + 1)
        {
          dis[u] = dis[v] + 1;
          que.push(u);
          dle.insert(u);
        }
      }
    for(ite = add.begin();ite != add.end(); ite++)
    {
      res.insert(*ite);
    }
    add.clear();
    for(ite = dle.begin(); ite != dle.end(); ite++)
    {
      res.erase(*ite);
    }
    dle.clear();
  }
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d%d", &V, &E);
    res.clear();
    for(int i = 1; i <= V; i++)
    {
      G[i].clear();
      res.insert(i);
    }
    for(int i = 1; i <= E; i++)
    {
      int u, v;
      scanf("%d%d", &u, &v);
      addedge(u, v);
    }
    int s;
    scanf("%d", &s);
    dijkstra(s);
    bool flag = 1;
    for(int i = 1; i <= V; i++)
    {
    //  printf("%d ", dis[i]);
      if(i != s)
      {
        if(dis[i] == INF)
        {
          flag = 0;
          break;
        }
      }
    }
    if(!flag) printf("-1\n");
    else
    {
      bool first = 1;
      for(int i = 1; i <= V; i++)
        if(i != s)
        {
          if(first){
            first = 0;
            printf("%d", dis[i]);
          }
          else
            printf(" %d", dis[i]);
      }
      printf("\n");
    }

  }
}
