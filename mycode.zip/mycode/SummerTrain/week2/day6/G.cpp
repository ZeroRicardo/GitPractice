#include <bits/stdc++.h>
using namespace std;
multiset<int> s;
multiset<int>::iterator ite, ite2;
int ans[510], tot;
int gcd(int a, int b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int main()
{
  int n;
  scanf("%d", &n);
  s.clear();
  tot = 0;
  for(int i = 0; i < n * n; i++)
  {
    int tmp;
    scanf("%d", &tmp);
    s.insert(tmp);
  }
  while(!s.empty())
  {
    ite = s.end();
    ite--;
    for(int i = 0; i < tot; i++)
    {
      int del = gcd(ans[i], *ite);
      ite2 = s.find(del);
      s.erase(ite2);
      ite2 = s.find(del);
      s.erase(ite2);
    }
    ans[tot++] = *ite;
    s.erase(ite);
  }
  for(int i = 0; i < tot; i++)
    printf("%d ", ans[i]);
  printf("\n");
}
