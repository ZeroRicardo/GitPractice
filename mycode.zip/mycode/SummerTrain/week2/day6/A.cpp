#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;
#define MAX_V 100010
#define MAX_E 1000010
#define INF 0x3f3f3f3f
int n, m;
struct Edge{
  int u, v, w;
  bool operator >(const struct Edge x)const{
    return w > x.w;
  }
};
vector<Edge> edge;
int fa[MAX_V];
struct node{
  int to, cost;
};
vector<node> P[MAX_V];
int cnt[MAX_V];
double sum[MAX_V];
bool cmp(struct Edge a, struct Edge b)
{
  return a.w < b.w;
}
int getfather(int x){
  if(x == fa[x])  return x;
  else return fa[x] = getfather(fa[x]);
}
void dfs(int v, int pre)
{
    cnt[v] = 1;
    for(int i = 0; i<P[v].size(); i++)
    {
        int nex = P[v][i].to;
        int val = P[v][i].cost;
        if(nex == pre)
            continue;
        dfs(nex, v);
        cnt[v] += cnt[nex];
        sum[v] = (double)(cnt[v] - 1) * (n - cnt[v] + 1) * val;
    }
}
long long kruskal(){
    long long ans = 0;
    sort(edge + 1, edge + 1 + m, cmp);
      int cnt = n;
      for(int i = 1; i <= n; i++)
        fa[i] = i;
      for(int i = 1; i <= m; i++){
        int t1 = getfather(edge[i].u);
        int t2 = getfather(edge[i].v);
          if(t1 != t2){
            cnt--;
            fa[t1] = t2;
            ans += edge[i].w;
            node a, b;
            a.to = edge[i].u, a.cost = edge[i].w;
            b.to = edge[i].v, b.cost = edge[i].w;
            P[edge[i].u].push_back(b);
            P[edge[i].v].push_back(a);
            if(cnt == 1)  break;
          }
        }
    return ans;
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d%d", &n, &m);
    edge.clear();
    Edge a;
    a.u = a.v = v, a.w = w;
    edge.push_back(a);
    for(int i = 1; i <= m; i++)
    {
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      a.u = u, a.v = v, a.w = w;
      edge.push_back(a);
    }
    long long ans = kruskal();
    /*for(int i = 1; i <= n; i++)
    {
      for(int j = 0; j < P[i].size(); j++)
        printf("%d %d %d\n", i, P[i][j].to, P[i][j].cost);
    }*/
    dfs(1, -1);
    double tot = 0;
    for(int i = 1; i <= n; i++)
    {
      tot += sum[i];
    //  printf("%d\n", cnt[i]);
    //  printf("%.2f\n", sum[i]);
    }
    tot = tot * 2 / n / (n - 1);
    printf("%lld %.2f\n", ans, tot);
  }
}
