#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define ll long long
const int MAX_N = 200010;
ll Tree1[MAX_N], Tree2[MAX_N];
int n;
int lowbit(int x){
  return x & -x;
}
void add(int x, ll val){
  for(int i = x; i <= n; i += lowbit(i))
    Tree1[i] += val;
  for(int i = x; i <= n; i += lowbit(i))
    Tree2[i] += x * val;
}
ll get(int x){
  ll ret = 0;
  for(int i = x; i; i -= lowbit(i))
    ret += Tree1[i];
  ret = ret * (x + 1);
  for(int i = x; i; i -= lowbit(i))
    ret -= Tree2[i];
  return ret;
}
void update(int l, int r, ll val)
{
  add(l, val);
  add(r + 1, -val);
}
ll query(int l, int r)
{
  return get(r) - get(l - 1);
}
int main()
{
    int m;
    scanf("%d%d", &n, &m);
    memset(Tree1, 0, sizeof Tree1);
    memset(Tree2, 0, sizeof Tree2);
    for(int i = 1; i <= n; i++)
    {
      ll tmp;
      scanf("%lld", &tmp);
      update(i, i, tmp);
    }
    for(int i = 1; i <= m; i++)
    {
      char op;
      int l, r;
      ll val;
      scanf(" %c", &op);
      if(op == 'C'){
        scanf("%d%d%lld", &l, &r, &val);
        update(l, r, val);
      }
      else{
        scanf("%d%d", &l, &r);
        printf("%lld\n", query(l, r));
      }
    }
  return 0;
}
