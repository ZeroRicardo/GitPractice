#include <stdio.h>
void outchar(char c)
{
  if(c == '\r') printf("\\r ");
  else if(c == '\n')  printf("\\n ");
  else if(c == '\t')  printf("\\t ");
  else  printf(" %c ", c);
}
int main()
{
  freopen("in.txt", "r", stdin);
  char c;
  int tmp[16];
  int cnt = 0, i = 0;
  while(1)
  {
    c = getchar();
    if(c != EOF)
    {
      outchar(c);
      tmp[cnt++] = c;
    }
    if(cnt == 16 || c == EOF)
    {
      printf("\n");
      for(i = 0; i < cnt; i++)
      {
        printf("%02x ", tmp[i]);
      }
      printf("\n");
      cnt = 0;
      if(c == EOF)  break;
    }
  }
}
