#include <stdio.h>
int threefourth(int x)
{
  unsigned int s = x >> 31;
  int b0 = x >> 2, b1 = x & 3;
  return (b0 << 1) + b0 + b1 - (b1 && 1) + (s && b1);
}
int main()
{
  int n;
  while(~scanf("%d", &n))
  {
    printf("%d\n\n", threefourth(n));
  }
}
