#include <stdio.h>
#define ll long long
ll two_to_ten(ll x)
{
  int ret = 0, bit[100], tot = 0;
  while(x)
  {
    bit[tot++] = x % 10;
    x /= 10;
  }
  for(int i = tot - 1; i >= 0; i--)
    ret = ret * 2 + bit[i];
  return ret;
}
int main()
{
  ll n;
  while(~scanf("%lld", &n))
  {
    printf("%lld\n", two_to_ten(n));
  }
}
