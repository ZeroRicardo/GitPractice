#include <stdio.h>
typedef unsigned char *byte_pointer;
int isLittleEndian()
{
  int x = 0x12345678;
  byte_pointer p = (byte_pointer) &x;
  int i;
  if(*p == 0x78)   return 1;
  return 0;
}
int main()
{
  printf("%s\n", isLittleEndian() ? "yes, it is littleendian.": "no");
}
