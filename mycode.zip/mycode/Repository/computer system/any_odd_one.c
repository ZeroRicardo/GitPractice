#include <stdio.h>
int any_odd_one(unsigned x)
{
  return !!(x & 0x55555555);
}
int main()
{
  unsigned x;
  while(~scanf("%d", &x))
  {
    printf("%d\n\n", any_odd_one(x));
  }
}
