#include <bits/stdc++.h>
using namespace std;
char str[210];
char s1[20] = "LSC", s2[20] = "PCMS";
int main()
{
  while(~scanf("%s", &str))
  {
    int cnt1 = 0, cnt2 = 0;
    for(int i = 0; str[i]; i++)
    {
      bool flag = 1;
      for(int j = 0; s1[j]; j++)
        if(str[i + j] != s1[j])
        {
          flag = 0;
          break;
        }
      cnt1 += flag;
      flag = 1;
      for(int j = 0; s2[j]; j++)
        if(str[i + j] != s2[j])
        {
          flag = 0;
          break;
        }
      cnt2 += flag;
    }
    if(cnt1 > cnt2) printf("LSC\n");
    else  if(cnt1 < cnt2) printf("PCMS\n");
    else  printf("Tie\n");
  }
}
