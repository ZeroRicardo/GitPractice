#include <stdio.h>
typedef unsigned char *byte_pointer;
unsigned replace_byte(unsigned x, int i, unsigned char b)
{
  byte_pointer p = (byte_pointer) &x;
  *(p + i) = b;
  return x;
}
int main()
{
  int a = 0x12345678;
  printf("0x%X\n", replace_byte(a, 0, 0xAB));
  printf("0x%X\n", replace_byte(a, 2, 0xAB));
}
