#include <stdio.h>
#include <string.h>
unsigned int f2u(float f)
{
	unsigned int i;
	memcpy(&i, &f, 4);
	return i;
}

int float_le(float x, float y){
    unsigned ux = f2u(x);
    unsigned uy = f2u(y);
    unsigned sx = ux >> 31;
    unsigned sy = uy >> 31;
    return ((ux << 1) == 0 && (uy << 1) == 0) ||
           (sx && !sy) ||
           (!sx && !sy && ux <= uy) ||
           (sx && sy && ux >= uy);
}

int main()
{
  float x, y;
  while(~scanf("%f%f", &x, &y))
  {
    printf("%d\n", float_le(x, y));
  }
}
