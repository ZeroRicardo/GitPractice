#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void *calloc(size_t nmemb, size_t size)
{
  void *s = malloc(nmemb * size);
  memset(s, 0, nmemb);
  return s;
}
int main()
{
  char *p = (char *) calloc(3, sizeof(char));
  p[1] = 1, p[2] = 2, p[3] = 3;
  printf("%d\n%d\n%d\n", p[1], p[2], p[3]);
  return 0;
}
