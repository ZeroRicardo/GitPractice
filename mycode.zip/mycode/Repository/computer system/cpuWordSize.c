#include <stdio.h>
int cpuWordSize()
{
  return sizeof(void *);
}
int main()
{
  printf("%d\n", cpuWordSize());
}
