#include <stdio.h>
const int w = 32;
int lower_one_mask(int n)
{
  return (1 << 1 << (n - 1)) - 1;
}
int main()
{
  int n;
  while(~scanf("%d", &n))
  {
    printf("0x%X\n", lower_one_mask(n));
  }
}
