#include <stdio.h>
typedef unsigned char *byte_pointer;
void show_bytes(byte_pointer start, size_t len)
{
  size_t i;
  for(i = 0; i < len; i++)
    printf(" %.2x", start[i]);
  printf("\n");
}
int main()
{
   //char/ int/short/long/float/double/struct/union/enum/数组/指针;
   char a = 'v';
   int b = 123;
   short c = 345;
   long d = 65758;
   float e = 1.2334;
   double f = 3.32408;
   struct node{
     int x, y;
   }g;
   printf("变量名\t内容\t地址\t内存各字节\n");
   printf("a\t%c\t%p\t", a, &a);
   show_bytes((byte_pointer) &a, sizeof (a));
   printf("b\t%d\t%p\t", b, &b);
   show_bytes((byte_pointer) &b, sizeof (b));
   printf("c\t%d\t%p\t", c, &c);
   show_bytes((byte_pointer) &c, sizeof (c));
   printf("d\t%d\t%p\t", d, &d);
   show_bytes((byte_pointer) &d, sizeof (d));
   printf("e\t%f\t%p\t", e, &e);
   show_bytes((byte_pointer) &e, sizeof (e));
   printf("f\t%f\t%p\t", f, &f);
   show_bytes((byte_pointer) &f, sizeof (f));
}
