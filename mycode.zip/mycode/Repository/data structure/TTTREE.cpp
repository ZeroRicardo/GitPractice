#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
#define CSSZ sizeof(struct CSnode)
#define BSZ sizeof(struct node)
typedef char DataType;
struct CSnode{
  DataType data;
  struct CSnode *firstchild, *rightsib;
};
typedef struct CSnode *CSTREE;
struct node{
  DataType data;
  struct node *lchild, *rchild;
  int start, end;
};
typedef struct node *BTREE;
BTREE Stack[maxn];
int top = -1;
struct STACK{
  BTREE ptr;
  int flag;
}S[maxn];
void CreateCS(CSTREE &T)
{
  DataType ch;
  cin >> ch;
  if(ch == '#') T = NULL;
  else
  {
    T = (CSTREE)malloc(CSSZ);
    T -> data = ch;
    CreateCS(T -> firstchild);
    CSTREE p = T -> firstchild;
    while(p != NULL)
    {
      CreateCS(p -> rightsib);
      p = p -> rightsib;
    }
  }
}
void BuildCS(CSTREE &T)
{
  DataType ch = '^';
    T = (CSTREE)malloc(CSSZ);
    T -> data = ch;
    T -> firstchild = NULL;
    T -> rightsib = NULL;
    CreateCS(T -> firstchild);
    CSTREE p = T -> firstchild;
    while(p != NULL)
    {
      CreateCS(p -> rightsib);
      p = p -> rightsib;
    }
}
void Transform(CSTREE CS, BTREE &BT)
{
  if(CS != NULL)
    BT -> data = CS -> data;
  else
  {
    BT = NULL;
    return;
  }
  BT -> lchild = (BTREE) malloc(BSZ);
  BT -> rchild = (BTREE) malloc(BSZ);
  Transform(CS -> firstchild, BT -> lchild);
  Transform(CS -> rightsib, BT -> rchild);
}
void UnPreOrder(BTREE BT)
{
  top = -1;
  if(BT == NULL)  return;
  while(BT != NULL || top != -1)
  {
    while(BT != NULL){
      if(BT -> data != '^')
        cout << BT -> data;
      Stack[++top] = BT;
      BT = BT -> lchild;
    }
    if(top != -1){
      BT = Stack[top--];
      BT = BT -> rchild;
    }
  }
}
void UnInOrder(BTREE BT)
{
  top = -1;
  while(BT != NULL || top != -1)
  {
    while(BT != NULL){
      Stack[++top] = BT;
      BT = BT -> lchild;
    }
    if(top != -1){
      BT = Stack[top--];
      if(BT -> data != '^')
        cout << BT -> data;
      BT = BT -> rchild;
    }
  }
}
void UnPostOrder(BTREE BT)
{
  top = -1;
  BTREE Root = BT;
  bool flag = 0;
  while(BT != NULL || top != -1){
    while(BT != NULL){
      top++;
      S[top].ptr = BT;
      S[top].flag = 1;
      BT = BT -> lchild;
    }
    while(top  != -1 && S[top].flag == 2){
      BT = S[top--].ptr;
      if(BT -> data != '^')
        cout << BT -> data;
      if(BT == Root)
      {
        flag = 1;
      }
    }
    if(flag)  break;
    if(top != -1){
      S[top].flag = 2;
      BT = S[top].ptr -> rchild;
     }
  }
}
void CSPreOrder(CSTREE T)
{
  if(T != NULL)
  {
    cout << "{";
    if(T -> data != '^')
    {
      cout << T -> data;
      if(T -> firstchild != NULL) cout << ",";
    }
    else cout << "#";
    CSPreOrder(T -> firstchild);
    CSTREE p = T -> firstchild;
    while(p != NULL)
    {
      if(p -> rightsib != NULL) cout << ",";
      if(T -> data == '^' && p -> rightsib != NULL)
        cout << "#";
        CSPreOrder(p -> rightsib);
      p = p -> rightsib;
    }
  }
  else  cout << "}";
}
int Mark(BTREE BT, int x)
{
  int ret = 0;
  BT -> start = x;
  BT -> end = 0;
  if(BT -> lchild == NULL)
    BT -> end = x + 1;
  else
  {
    ret = max(ret, Mark(BT -> lchild, x + 1));
    BT -> end = ret;
  }
  if(BT -> rchild != NULL)
  {
    ret = max(ret, Mark(BT -> rchild, BT -> end + 1));
  }
  else
    ret = max(ret, BT -> end + 1);
  return ret;
}
void PreOrder(BTREE BT)
{
  if(BT != NULL)
  {
    if(BT -> data != '^')
      cout << BT -> data << " start:" << BT -> start << " end:" << BT -> end << endl;
    PreOrder(BT -> lchild);
    PreOrder(BT -> rchild);
  }
}
int main()
{
  //freopen("in.txt", "r", stdin);
  //freopen("out.txt", "w", stdout);
  CSTREE CS = NULL;
  BTREE BT = (BTREE)malloc(BSZ);
  BuildCS(CS);
  cout << "树、森林的存储：" ;
  CSPreOrder(CS);
  cout << endl;
  Transform(CS, BT);              //树、森林转化为二叉树；
  cout << "二叉树的先序遍历：";
  UnPreOrder(BT);
  cout << endl;
  cout << "二叉树的中序遍历：";
  UnInOrder(BT);
  cout << endl;
  cout << "二叉树的后序遍历：";
  UnPostOrder(BT);
  cout << endl;
  Mark(BT, 0);
  PreOrder(BT);
}
/*
example:
AB#CE#F##D##GH#I###
*/
