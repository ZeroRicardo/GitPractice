//线性表, 链接表
#include <bits/stdc++.h>
using namespace std;
typedef int ElemType;
struct celltype{
  ElemType element;
  celltype *next;
};
typedef celltype *LIST;
typedef celltype *position;
void Insert(ElemType x, position p, LIST &L)
{
  position q;
  q = new celltype;
  q -> element = x;
  q -> next = p -> next;
  p -> next = q;
}
void Delete(position p, LIST &L)
{
  position q;
  if(p -> next != NULL)
  {
    q = p -> next;
    p -> next = q -> next;
    delete q;
  }
}
position Locate(ElemType x, LIST L)
{
  position p;
  p = L;
  while(p -> next != NULL)
  {
    if(p -> next -> element == x)
      return p;
    else
      p = p -> next;
  }
  return p;
}
ElemType Retrieve(position p, LIST L)
{
  return p -> next -> element;
}
position Previous(position p, LIST L)
{
  position q;
  if(p == L -> next)
    cout << "The prvious position doesn't exist." << endl;
  else
  {
    q = L;
    while(q -> next != p) q = q -> next;
    return q;
  }
}
position Next(position p, LIST L)
{
  position q;
  if(p -> next == NULL)
    cout << "The next position doesn't exist." << endl;
  else{
    q = p -> next;
    return q;
  }
}
position MakeNull(LIST &L)
{
  LIST p1 = L, p2 = NULL;
  while(p1 != NULL)
  {
    p2 = p1 -> next;
    free(p1);
    p1 = p2;
  }
  L = new celltype;
  L -> next = NULL;
  return L;
}
position First(LIST L)
{
  return L;
}
position End(LIST L)
{
  position q;
  q = L;
  while(q -> next != NULL)  q = q -> next;
  return q;
}
void Print(LIST L)
{
  LIST p = L;
  cout << "The elements of the list are: ";
  while(p -> next != NULL)
  {
    p = p -> next;
    cout << p -> element << " ";
  }
  cout << endl;
}
int main()
{
  LIST L = NULL;
  position p;
  MakeNull(L);
  Insert(2, First(L), L);
  Print(L);
  Insert(3, End(L), L);
  Print(L);
  Insert(4, First(L), L);
  Print(L);
  Insert(5, Next(First(L), L), L);
  Print(L);
  Insert(6, First(L), L);
  Print(L);
  Insert(9, End(L), L);
  Print(L);
  cout << "The first element is " << Retrieve(First(L), L) << endl;
  Print(L);
  Delete(Locate(4, L), L);
  Print(L);
  p = Locate(3, L);
  cout << "The position is " << p << endl;
  cout << "The elements is " << Retrieve(Next(p, L), L) << endl;
  cout << "The end element is " << Retrieve(Previous(End(L), L), L) << endl;
  Delete(Previous(End(L), L), L);
  Print(L);
  Delete(First(L), L);
  Print(L);
  cout << "The second element is " << Retrieve(Next(First(L), L), L) << endl;
  return 0;
}
