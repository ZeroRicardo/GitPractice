#include <bits/stdc++.h>
using namespace std;
#define VertexData int
#define EdgeData int
#define InfoType int
const int NumVertices = 1010;
int TYPE;   // the type of graph, 0 represents undirected graph,
            // 1 represents directed graph
struct MTGraph{
  EdgeData edge[NumVertices][NumVertices];
  int n, e;
  MTGraph(){
    memset(edge, 0, sizeof edge);
    n = 0, e = 0;
  }
  Print(){
    cout << "The MTGraph:" << endl;
    for(int i = 0; i < n; i++){
      for(int j = 0; j < n; j++)
        cout << edge[i][j] << " ";
      cout << endl;
    }
    cout << endl;
  }
};

struct EdgeNode{
  int adjvex;
  EdgeData cost;
  struct EdgeNode *next;
  EdgeNode(){
    adjvex = -1, cost = -1;
    next = NULL;
  }
};
struct VertexNode{
  EdgeNode *firstedge;
  VertexNode(){
    firstedge = NULL;
  }
};
struct AdjGraph{
  VertexNode vexlist[NumVertices];
  int n, e;
  AdjGraph(){
    n = 0, e = 0;
  }
  void addedge(int u, int v, int w){
    EdgeNode *p = new EdgeNode;
    p -> adjvex = v, p -> cost = w;
    p -> next = vexlist[u].firstedge;
    vexlist[u].firstedge = p;
    e++;
  }
  void Print(){
    cout << "In AdjGraph:" << endl;
    for(int i = 0; i < n; i++)
    {
      cout << "vertex " << i << ":" << " ";
      EdgeNode *p = vexlist[i].firstedge;
      while(p != NULL){
        cout << p -> adjvex << " " << p -> cost << "; ";
        p = p -> next;
      }
      cout << endl;
    }
    cout << endl;
  }
};

struct ArcBox{
  int tailvex, headvex;
  struct ArcBox *hlink, *tlink;
  InfoType info;
  ArcBox(){
    tailvex = -1, headvex = -1;
    hlink = NULL, tlink = NULL;
  }
};
struct VexNode{
  ArcBox *firstin, *firstout;
  VexNode(){
    firstin = NULL, firstout = NULL;
  }
};
struct OLGraph{
  VexNode xlist[NumVertices];
  int n, arcnum;
  OLGraph(){
    n = 0, arcnum = 0;
  }
  void addedge(int u, int v, int w){
    ArcBox *p = new ArcBox;
    p -> tailvex = u, p -> headvex = v;
    p -> hlink = xlist[v].firstin, p -> tlink = xlist[u].firstout;
    p -> info = w;
    xlist[v].firstin = xlist[u].firstout = p;
    arcnum++;
  }
  void Print(){
    cout << "In OLGraph: " << endl;
    for(int i = 0; i < n; i++)
    {
      cout << "vertex " << i << ":" << endl;
      cout << "in: ";
      ArcBox *p = xlist[i].firstin;
      while(p != NULL){
        cout << p -> tailvex << " " << p -> info << "; ";
        p = p -> hlink;
      }
      cout << endl;
      cout << "out: ";
      p = xlist[i].firstout;
      while(p != NULL){
        cout << p -> headvex << " " << p -> info << "; ";
        p = p -> tlink;
      }
      cout << endl;
    }
    cout << endl;
  }
};

struct EBox{
  int u, v;                  // u → v
  struct EBox *ulink, *vlink;
  InfoType info;
  EBox(){
    ulink = NULL, vlink = NULL;
  }
};
struct VexBox{
  EBox *firstedge;
  VexBox(){
    firstedge = NULL;
  }
};
struct AMLGraph{
    VexBox adjmulist[NumVertices];
    int n, e;
    AMLGraph(){
      n = 0, e = 0;
    }
    void addedge(int u, int v, int w){
      EBox *p = new EBox;
      p -> u = u, p -> v = v, p -> info = w;
      p -> ulink = adjmulist[u].firstedge, p -> vlink = adjmulist[v].firstedge;
      adjmulist[u].firstedge = adjmulist[v].firstedge = p;
    }
    void Print(){
      cout << "In AMLGraph:" << endl;
      for(int i = 0; i < n; i++){
        cout << "for vertex " << i << ":" << endl;
        EBox *p = adjmulist[i].firstedge;
        if(p != NULL){
          cout << p -> u <<" " << p -> v << " " << p -> info << endl;
          EBox *u = p -> ulink, *v = p -> vlink;
          while(u != NULL){
            cout << u -> u << " " << u -> v << " " << u -> info << "; ";
            u = u -> ulink;
          }
          cout << endl;
          while(v != NULL){
            cout << v -> u << " " << v -> v << " " << v -> info << "; ";
            v = v -> vlink;
          }
          cout << endl;
        }
      }
      cout << endl;
    }
};
bool vis[NumVertices];
void CreateMTGraph(MTGraph &G){
  memset(G.edge, 0, sizeof G.edge);
  cin >> TYPE;
  cin >> G.n;
  int u, v, w;
  while(cin >> u >> v >> w){
      G.edge[u][v] = w;
      G.e++;
      if(TYPE == 0) G.edge[v][u] = w;
  }
}
void MTtoAdj(MTGraph &M,AdjGraph &Adj){
  Adj.n = M.n;
  Adj.e = 0;
  for(int i = 0; i < M.n; i++)
    for(int j = 0; j < M.n; j++){
      if(M.edge[i][j]){
        Adj.addedge(i, j, M.edge[i][j]);
      }
    }
}
void MTtoOL(MTGraph &M, OLGraph &OL){
  OL.n = M.n;
  for(int i = 0; i < M.n; i++)
    for(int j = 0; j < M.n; j++){
      if(M.edge[i][j]){
        OL.addedge(i, j, M.edge[i][j]);
      }
    }
}
void MTtoAML(MTGraph &M, AMLGraph &AML){
  AML.n = M.n;
  for(int i = 0; i < M.n; i++)
    for(int j = 0; j < M.n; j++){
      if(M.edge[i][j]){
        AML.addedge(i, j, M.edge[i][j]);
      }
    }
}
void dfs(AdjGraph &Adj, int u){
  cout << u << " ";
  vis[u] = true;
  EdgeNode *p = Adj.vexlist[u].firstedge;
  while(p != NULL){
    if(!vis[p -> adjvex])
      dfs(Adj, p -> adjvex);
    p = p -> next;
  }
}
void DFSAdj(AdjGraph &Adj){
  cout << "the DFS order of AdjGraph: ";
  memset(vis, false, sizeof vis);
  for(int i = 0; i < Adj.n; i++)
    if(!vis[i])
      dfs(Adj, i);
  cout << endl << endl;
}
int que[NumVertices], front, rear;
void bfs(MTGraph &MT, int u){
  front = rear = 0;
  que[rear++] = u;
  vis[u] = true;
  while(front < rear){
    int t = que[front++];
    cout << t << " ";
    for(int i = 0; i < MT.n; i++)
      if(MT.edge[t][i] && !vis[i])
      {
        vis[i] = true;
        que[rear++] = i;
      }
  }
}
void BFSMT(MTGraph &MT){
  cout << "the BFS order of MTGraph: ";
  memset(vis, false, sizeof vis);
  for(int i = 0; i < MT.n; i++)
  {
    if(!vis[i])
      bfs(MT, i);
  }
  cout << endl << endl;
}
int mincost[NumVertices], clostset[NumVertices];
int prim(MTGraph &MT){
  memset(mincost, 0x3f, sizeof mincost);
  memset(vis, false, sizeof vis);
  memset(clostset, 0, sizeof clostset);
  mincost[0] = 0;
  int ret = 0;
  while(true)
  {
    int v = -1;
    for(int u = 0; u < MT.n; u++)
      if(!vis[u] && (v == -1 || mincost[u] < mincost[v]))
        v = u;
    if(v == -1) break;
    vis[v] = true;
    if(v != 0)  cout << "(" << v << "," << clostset[v] << ")" << endl;
    ret += mincost[v];
    for(int u = 0; u < MT.n; u++)
      if(MT.edge[v][u] && mincost[u] > MT.edge[v][u]){
        mincost[u] = MT.edge[v][u];
        clostset[u] = v;
      }
  }
  return ret;
}
int dis[NumVertices];
void dijkstra(MTGraph &MT, int s){
  memset(dis, 0x3f, sizeof dis);
  dis[s] = 0;
  front = rear = 0;
  que[rear++] = s;
  while(front < rear){
    int v = que[front++];
    for(int i = 0; i < MT.n; i++){
      if(MT.edge[v][i] && dis[i] > dis[v] + MT.edge[v][i]){
        dis[i] = dis[v] + MT.edge[v][i];
          que[rear++] = i;
      }
    }
  }
}
void PrintDis(MTGraph &G){
  cout << "the min distance:" << endl;
  for(int i = 0; i < G.n; i++)
    cout << "for vertex " << i << ": " << dis[i] << endl;
  cout << endl;
}
int in_order[NumVertices], cnt;
void DFS(OLGraph &G, int v){
  vis[v] = true;
  for(ArcBox *p = G.xlist[v].firstout; p != NULL; p = p -> tlink)
    if(!vis[p -> headvex])
      DFS(G, p -> headvex);
  in_order[cnt++] = v;
}
void Rev_DFS(OLGraph &G, int v){
  vis[v] = true;
  cout << v << " ";
  for(ArcBox *p = G.xlist[v].firstin; p != NULL; p = p -> hlink)
    if(!vis[p -> tailvex])
      Rev_DFS(G, p -> tailvex);
}
void Strongly_Connected_Component(OLGraph &G){
  int k = 1;
  cnt = 0;
  memset(vis, false, sizeof vis);
  for(int v = 0; v < G.n; v++)
    if(!vis[v]) DFS(G, v);
  memset(vis, false, sizeof vis);
  for(int j = G.n - 1; j >= 0; j--){
    int v = in_order[j];
    if(!vis[v]){
      cout << "\nthe " << k++ << "th Connected Component:";
      Rev_DFS(G, v);
    }
  }
  cout << endl << endl;
}
int in[NumVertices], SortVer[NumVertices];
void TopSort(MTGraph &MT){
  front = rear = 0;
  int cnt = 0;
  memset(in, 0, sizeof in);
  for(int i = 0; i < MT.n; i++)
    for(int j = 0; j < MT.n; j++)
      if(MT.edge[j][i])
        in[i]++;
  for(int i = 0; i < MT.n; i++)
    if(in[i] == 0)
      que[rear++] = i;
  while(front < rear){
    int u = que[front++];
    SortVer[cnt++] = u;
    for(int i = 0; i < MT.n; i++)
      if(MT.edge[u][i])
      {
        in[i]--;
        if(in[i] == 0)
          que[rear++] = i;
      }
  }
  if(cnt < MT.n)  cout << "There is circle(s) in Graph" << endl;
  else{
    cout << "after topologicalsorted:";
    for(int i = 0; i < MT.n; i++)
      cout << SortVer[i] << " ";
    cout << endl;
  }
}
MTGraph G;
AdjGraph Adj;
OLGraph OL;
AMLGraph AML;
int main(){
  ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
  freopen("in.txt", "r", stdin);
  CreateMTGraph(G);

  G.Print();
  MTtoAdj(G, Adj);
  MTtoOL(G, OL);
  MTtoAML(G, AML);

  Adj.Print();
  OL.Print();
  AML.Print();
  DFSAdj(Adj);
  BFSMT(G);
  int fee = prim(G);
  cout << "the mincost of the minimum spanning tree of G:" << fee << endl << endl;

  dijkstra(G, 0);
  PrintDis(G);

  Strongly_Connected_Component(OL);
  for(int i = 0; i < 5; i++)
   cout << in_order[i] << endl;
     TopSort(G);
}
