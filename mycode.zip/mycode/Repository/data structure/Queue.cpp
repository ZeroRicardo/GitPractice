//队列
#include <bits/stdc++.h>
using namespace std;
typedef int ElemType;
struct celltype{
  ElemType data;
  celltype *next;
};
struct Queue{
  celltype *front;
  celltype *rear;
};
void MakeNull(Queue &Q)
{
  Q.front = new celltype;
  Q.front -> next = NULL;
  Q.rear = Q.front;
}
bool Empty(Queue &Q)
{
  return Q.front == Q.rear;
}
ElemType Front(Queue Q)
{
  if(Q.front -> next)
    return Q.front -> next -> data;
  else
    return -1;
}
void EnQueue(ElemType x, Queue &Q)
{
  celltype *q;
  q = new celltype;
  q -> data = x;
  q -> next = NULL;
  Q.rear -> next = q;
  Q.rear = q;
}
void DeQueue(Queue &Q)
{
  celltype *p;
  if(Q.rear == Q.front)  cout << "The queue is empty." << endl;
  else{
    p = Q.front -> next;
    Q.front -> next = p -> next;
    if(p -> next == NULL) Q.rear = Q.front;
    delete p;
  }
}
int main()
{
  Queue Q;
  MakeNull(Q);
  EnQueue(4, Q);
  EnQueue(5, Q);
  EnQueue(8, Q);
  cout << "The front data is " << Front(Q) << endl;
  DeQueue(Q);
  EnQueue(11, Q);
  EnQueue(15, Q);
  EnQueue(3, Q);
  cout << "The front data is " << Front(Q) << endl;
  DeQueue(Q);
  EnQueue(2, Q);
  EnQueue(7, Q);
  cout << "The front data is " << Front(Q) << endl;
  DeQueue(Q);
  cout << "The front data is " << Front(Q) << endl;
  DeQueue(Q);
  cout << "The front data is " << Front(Q) << endl;
  DeQueue(Q);
  cout << "The front data is " << Front(Q) << endl;
  DeQueue(Q);
  EnQueue(23, Q);
  while(!Empty(Q))
  {
    cout << "The front data is " << Front(Q) << endl;
    DeQueue(Q);
  }
}
