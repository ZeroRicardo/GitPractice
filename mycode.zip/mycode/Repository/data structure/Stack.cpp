//栈
#include <bits/stdc++.h>
using namespace std;
const int maxn = 10010;
typedef int ElemType;
typedef struct{
  ElemType elements[maxn];
  int top;
}Stack;
void MakeNull(Stack &S)
{
  S.top = -1;
}
bool Empty(Stack S)
{
  return S.top < 0;
}
ElemType Top(Stack S)
{
  if(Empty(S))
    return -1;
  else
    return S.elements[S.top];
}
void Pop(Stack &S)
{
  if(Empty(S))
    cout << "Stack is empty." << endl;
  else
    S.top--;
}
void Push(ElemType x, Stack &S)
{
  if(S.top == maxn - 1)
    cout << "Stack is full." << endl;
  else
  {
    S.top++;
    S.elements[S.top] = x;
  }
}
int main()
{
    Stack S;
    MakeNull(S);
    Push(4, S);
    Push(5, S);
    Push(8, S);
    cout << "The top element is " << Top(S) << endl;
    Pop(S);
    Push(11, S);
    Push(15, S);
    Push(3, S);
    cout << "The top element is " << Top(S) << endl;
    Pop(S);
    Push(2, S);
    Push(7, S);
    cout << "The top element is " << Top(S) << endl;
    Pop(S);
    cout << "The top element is " << Top(S) << endl;
    Pop(S);
    cout << "The top element is " << Top(S) << endl;
    Pop(S);
    cout << "The top element is " << Top(S) << endl;
    Pop(S);
    Push(23, S);
    while(!Empty(S))
    {
      cout << "The top element is " << Top(S) << endl;
      Pop(S);
    }
}
