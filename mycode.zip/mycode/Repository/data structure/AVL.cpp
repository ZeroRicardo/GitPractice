#include <bits/stdc++.h>
using namespace std;
#define datatype int
typedef struct cell{
  datatype val;
  int height;
  struct cell *lch, *rch;
  cell(){
    lch = rch = NULL;
  }
}AVLNode;
typedef AVLNode *AVL;
int calh(AVL F){
  if(F == NULL) return 0;
  else  return F -> height;
}
void LeftRotation(AVL &F){
  AVL p = F -> rch;
  F -> rch = p -> lch;
  p -> lch = F;
  F -> height = max(calh(F -> lch), calh(F -> rch)) + 1;
  p -> height = max(calh(p -> lch), calh(p -> rch)) + 1;
  F = p;
}
void RightRotation(AVL &F){
  AVL p = F -> lch;
  F -> lch = p -> rch;
  p -> rch = F;
  F -> height = max(calh(F -> lch), calh(F -> rch)) + 1;
  p -> height = max(calh(p -> lch), calh(p -> rch)) + 1;
  F = p;
}
void RightLeftRotation(AVL &F){
  RightRotation(F -> rch);
  LeftRotation(F);
}
void LeftRightRotation(AVL &F){
  LeftRotation(F -> lch);
  RightRotation(F);
}
AVLNode *search(datatype key, AVL F){
  if(F == NULL || F -> val == key)  return F;
  else if(key < F -> val) return search(key, F -> lch);
  else return search(key,  F -> rch);
}
void insert(datatype key, AVL &F){
  if(F == NULL){
    F = new AVLNode;
    F -> val = key;
  }
  else if(key < F -> val){
    insert(key, F -> lch);
    if(calh(F -> lch) - calh(F -> rch) == 2){
      if(key < F -> lch -> val) RightRotation(F);
      else LeftRightRotation(F);
    }
  }
  else{
    insert(key, F -> rch);
    if(calh(F -> rch) - calh(F -> lch) == 2){
      if(key > F -> rch -> val) LeftRotation(F);
      else  RightLeftRotation(F);
    }
  }
  F -> height = max(calh(F -> lch), calh(F -> rch)) + 1;
}
datatype deletemin(AVL &F){
  datatype ret;
  AVL p = F;
  if(F -> lch == NULL){
    ret = F -> val;
    F = F -> rch;
    delete p;
    return ret;
  }
  else  return deletemin(F -> lch);
}
void deleteB(datatype key, AVL &F){
  if(F == NULL) return;
  if(key < F -> val){
    deleteB(key, F -> lch);
    if(calh(F -> rch) - calh(F -> lch) == 2){
      if(calh(F -> rch -> lch) > calh(F -> rch -> rch)) RightLeftRotation(F);
      else  LeftRotation(F);
    }
  }
  else if(key > F -> val){
    deleteB(key, F -> rch);
    if(calh(F -> lch) - calh(F -> rch) == 2){
      if(calh(F -> lch -> rch) > calh(F -> lch -> lch)) LeftRightRotation(F);
      else RightRotation(F);
    }
  }
  else{
    AVL p = F;
    if(F -> lch == NULL){
      F = F -> rch;
      delete p;
    }
    else if(F -> rch == NULL){
      F = F -> lch;
      delete p;
    }
    else  F -> val = deletemin(F -> rch);
  }
}
void InOrder(AVL F){
  if(F == NULL) return;
  InOrder(F -> lch);
  cout << F -> val << " ";
  InOrder(F -> rch);
}
void PreOrder(AVL F){
  if(F == NULL) return;
  cout << "the vertex is " << F -> val << " ,";
  cout << "left children is ";
  if(F -> lch != NULL)  cout << F -> lch -> val << " ,";
  else  cout << "NULL ,";
  cout << "right children is ";
  if(F -> rch != NULL)  cout << F -> rch -> val << " ,";
  else  cout << "NULL ,";
  cout << endl;
  PreOrder(F -> lch);
  PreOrder(F -> rch);
}
void LastOrder(AVL F){
  if(F == NULL) return;
  LastOrder(F -> lch);
  LastOrder(F -> rch);
  cout << F -> val << " ";
}
int main()
{
  //freopen("in.txt", "r", stdin);
  char op[20];
  AVL head = NULL;
  while(~scanf(" %s", op)){
    if(!strcmp(op, "insert")){
      int tmp;
      scanf("%d", &tmp);
      insert(tmp, head);
    }
    else if(!strcmp(op, "search")){
      int tmp;
      scanf("%d", &tmp);
      AVL p = search(tmp, head);
      if(p == NULL) cout << "Not found" << endl;
      else cout << "Found " << p -> val << endl;
      continue;
    }
    if(!strcmp(op, "delete")){
      int tmp;
      scanf("%d", &tmp);
      deleteB(tmp, head);;
    }
    PreOrder(head);
    cout << endl;
  }
}
