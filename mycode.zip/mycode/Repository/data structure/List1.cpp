//线性表, 顺序表
#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
typedef int position;
typedef int ElemType;
struct LIST{
  ElemType elements[maxn];
  int last;
};
void Insert(ElemType x, position p, LIST &L);
position Locate(ElemType x, position L);
ElemType Retrieve(position p, LIST L);
void Delete(position p, LIST &L);
position Previous(position p, LIST L);
position Next(position p, LIST L);
position MakeNull(LIST &L);
position First(LIST L);
position END(LIST L);
void Insert(ElemType x, position p, LIST &L)
{
  position q;
  if(L.last >= maxn - 1)
    cout << "The list is full." << endl;
  else if((p > L.last + 1) || (p < 1))
    cout << "This position doesn't exist." << endl;
  else{
    for(q = L.last; q >= p; q--)
      L.elements[q + 1] = L.elements[q];
    L.elements[p] = x;
    L.last = L.last + 1;
  }
}
position Locate(ElemType x, LIST L)
{
  position q;
  for(q = 1; q <= L.last; q++)
    if(L.elements[q] == x)
      return q;
  return L.last + 1;
}
ElemType Retrieve(position p, LIST L)
{
  if(p > L.last)
    cout << "This position doesn't exist." << endl;
  else
    return L.elements[p];
}
void Delete(position p,LIST &L)
{
  position q;
  if((p > L.last) || (p < 1))
    cout << "This position doesn't exist." << endl;
  else{
    L.last = L.last - 1;
    for(q = p; q <= L.last; q++)
      L.elements[q] = L.elements[q + 1];
  }
}
position Previous(position p, LIST L)
{
  if((p <= 1) || (p > L.last + 1))
    cout << "The previous position doesn't exist." << endl;
  else
    return p - 1;
}
position Next(position p, LIST L)
{
  if((p < 1) || (p >= L.last))
    cout << "The next position doesn't exist." << endl;
  else
    return p + 1;
}
position MakeNull(LIST &L)
{
  L.last = 0;
  return (L.last + 1);
}
position First(LIST L)
{
  if(L.last > 0)  return 1;
  else  cout << "The list is null." << endl;
}
position End(LIST L)
{
  return (L.last + 1);
}
void Print(LIST L)
{
  cout << "The elements of the list are: ";
  for(int i = 1; i <= L.last; i++)
    cout << L.elements[i] << " ";
  cout << endl;
}
int main()
{
  LIST L;
  position p;
  MakeNull(L);
  Insert(2, 1, L);
  Print(L);
  Insert(3, End(L), L);
  Print(L);
  Insert(4, First(L), L);
  Print(L);
  Insert(5, 2, L);
  Print(L);
  Insert(6, First(L), L);
  Print(L);
  Insert(9, End(L), L);
  Print(L);
  cout << "The first element is " << Retrieve(First(L), L) << endl;
  Print(L);
  Delete(Locate(4, L), L);
  Print(L);
  p = Locate(3, L);
  cout << "The position is " << p << endl;
  cout << "The elements is " << Retrieve(Next(p, L), L) << endl;
  cout << "The end element is " << Retrieve(Previous(End(L), L), L) << endl;
  Delete(Previous(End(L), L), L);
  Print(L);
  Delete(First(L), L);
  Print(L);
  cout << "The second element is " << Retrieve(Next(First(L), L), L) << endl;
  return 0;
}
