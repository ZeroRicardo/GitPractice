//二叉树
#include <bits/stdc++.h>
using namespace std;
#define SZ sizeof(struct node)
typedef char datatype;
struct node{
  datatype data;
  struct node *lchild, *rchild;
  bool ltag, rtag;
};
typedef struct node *BTREE;
void CreateBT(BTREE &T)
{
  datatype ch;
  cin >> ch;
  if(ch == '#') T = NULL;
  else
  {
    T = (BTREE) malloc(SZ);
    T -> data = ch;
    CreateBT(T -> lchild);
    CreateBT(T -> rchild);
  }
}
void PreOrder(BTREE BT)
{
  if(BT != NULL)
  {
    cout << BT -> data;
    PreOrder(BT -> lchild);
    PreOrder(BT -> rchild);
  }
  else  cout << "#";
}
void InOrder(BTREE BT)
{
  if(BT != NULL)
  {
    InOrder(BT -> lchild);
    cout << BT -> data;
    InOrder(BT -> rchild);
  }
  else  cout << "#";
}
void PostOrder(BTREE BT)
{
  if(BT != NULL)
  {
    PostOrder(BT -> lchild);
    PostOrder(BT -> rchild);
    cout << BT -> data;
  }
  else  cout << "#";
}
int main()
{
  freopen("in.txt", "r", stdin);
  BTREE head = NULL;
  CreateBT(head);
  PreOrder(head);
  cout << endl;
  InOrder(head);
  cout << endl;
  PostOrder(head);
  cout << endl;
}
