#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

#define maxn 10010
bool matrixA[maxn][maxn], matrixT[maxn][maxn],
    matrixM[maxn][maxn], matrixN[maxn][maxn];
int n;
int main()
{
  system("color f4");
//  freopen("C:/Users/Master/Desktop/1/test1.txt","r", stdin);
int m = 800;
  int cnt = 1;
while(m <= 10000){
  FILE *p1;
  p1 = fopen("C:/Users/Master/Desktop/1/test.txt", "w");
  fprintf(p1,"%d ", m);
  srand(time(NULL));
  for(int i = 1; i <= m; i++)
  {
    for(int j = 1; j <= m; j++)
    {
      int p = rand() % 1000 * 1000;
      if(p < 1.1 * m)
        fprintf(p1,"1 ");
      else
        fprintf(p1,"0 ");
    }
    //printf("\n");
  }
  fclose(p1);

  //  freopen("C:/Users/Master/Desktop/1/test.txt","r", stdin);
//  cout << "Please input the size of the matrix:" << endl;
FILE *p2 = fopen("C:/Users/Master/Desktop/1/test.txt", "r");

    //freopen("C:/Users/Master/Desktop/1/test.txt","r", stdin);
fscanf(p2,"%d", &n);
//  cout << "Please input the matrix:" << endl;
for(int i = 1; i <= n; i++)
  for(int j = 1; j <= n; j++)
  {
    fscanf(p2, "%d", &matrixM[i][j]);
    matrixT[i][j] = matrixM[i][j];
  }

  //算法的主要部分，即传递闭包的计算
  double a = clock();
  int tmp = cnt;
  while(tmp--)
  {
  for(int k = 1; k <= n; k++)
    for(int i = 1; i <= n; i++)
      for(int j = 1;j <= n; j++)
        matrixT[i][j] = matrixT[i][j] | (matrixT[i][k] & matrixT[k][j]);
    }
    double b = clock();
    double sum = b - a;
  //闭包矩阵的输出
/*  cout << "Output the transitive closure matrix :" << endl;
  for(int i = 1; i <= n; i++){
    for(int j = 1; j <= n; j++)
      cout <<matrixT[i][j] << " ";
    cout << endl;
  }*/
  //if(cnt % 100 == 0)
  cout << "the size of the matrix is:" << n << "  ";

  printf("the average runtime is %.6fs\n",sum/cnt/1000);

  m += 100;

fclose(p2);
}
}
