#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#define MAXN 10010
bool flag[MAXN][MAXN];
int main(){
    freopen("C:/Users/Master/Desktop/1/test.txt","w", stdout);
    srand(time(NULL));
    int n =900, m;
    m = n;
    memset(flag, 0, sizeof(flag));
    printf("%d %d\n", n, m);
    for(int i = 0; i < m; i++)
    {
      int a, b, c;
      a = rand() % n + 1;
      do{
        b = rand() % n + 1;
      }while(a == b || flag[a][b]);
      c = rand() % 1000 + 1;
      flag[a][b] = flag[b][a] = 1;
      printf("%d %d %d\n", a, b, c);
    }
    int a, b;
    a = rand() % n + 1;
    do{
      b = rand() % n + 1;
    }while(a == b);
    printf("%d %d\n",a, b);

  }
