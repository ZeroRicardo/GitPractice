#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;
const int MAXN = 10010;

const int INF = 0x3f3f3f3f;
bool vis[MAXN];
int pre[MAXN], cost[MAXN][MAXN], lowcost[MAXN];
void Dijkstra(int n, int beg)
{
  for(int i = 1; i <= n; i++)
  {
    lowcost[i] = INF; vis[i] = false; pre[i] = -1;
  }
  lowcost[beg] = 0;
  for(int j = 1; j <= n; j++)
  {
    int k = -1;
    int Min = INF;
    for(int i = 1; i <= n; i++)
      if(!vis[i] && lowcost[i] < Min)
      {
        Min = lowcost[i];
        k = i;
      }
    if(k == -1) break;
    vis[k] = true;
    for(int i = 1; i <= n; i++)
      if(!vis[i] && lowcost[k] + cost[k][i] < lowcost[i])
      {
        lowcost[i] = lowcost[k] + cost[k][i];
        pre[i] = k;
      }
  }
}

int main()
{
  double sum = 0;
  int cnt = 10, cnt2;
  int tmp = cnt;
  while(tmp--){
    freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
    //system("color f4");





    int n, m, st, ed;
    memset(cost, INF, sizeof(cost));


  //  cout << "Please input the number of nodes:" <<endl;
    scanf("%d", &n);

  //  cout << "Please input the number of edges:" <<endl;
    scanf("%d", &m);
  //  cout << "Please input the edges and weight of edges:" << endl;
    for(int i = 0; i < m; i++)
    {
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      cost[u][v] = w;
      cost[v][u] = w;
    }
  //  cout << "Please Input the Starting point and the destination:" <<endl;
    //cin >> st >> ed;
    scanf("%d%d",&st, &ed);
     double a = clock();
     cnt2 = 10;
     int tmp2 = cnt2;
     while(tmp2--)
    {
        Dijkstra(n, st);
    }
     double b = clock();
    printf("%.6f\n", b - a);
    sum += b - a;
}
    printf("%.6f\n", sum/cnt / cnt2 / 1000);
//  cout << "the shrotest distance is:" << lowcost[ed] << endl;
  return 0;
}
