#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

#define maxn 10010
bool matrixA[maxn][maxn], matrixT[maxn][maxn], matrixM[maxn][maxn], matrixN[maxn][maxn];
int n;
// 矩阵乘法 矩阵 A 表示矩阵 M 的 i 次幂矩阵，每调用一次该函数，幂次加 1
void matrix_multiply(){

  for(int i = 1; i <= n; i++)
  {
    for(int j = 1; j <= n; j++)
    {
      matrixN[i][j] = 0;
      for(int k = 1; k <= n; k++)
        matrixN[i][j] += matrixA[i][k] * matrixM[k][j];
    }
  }

    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= n; j++)
      {
        matrixA[i][j] = matrixN[i][j];

      }

}
int main()
{
  system("color f4");

  int m = 1000;
  while(m <= 10000){
  FILE *p1;
  //freopen("C:/Users/Master/Desktop/1/test.txt","w", stdout);
  p1 = fopen("C:/Users/Master/Desktop/1/test1.txt", "w");
  fprintf(p1,"%d ", m);
  srand(time(NULL));
  for(int i = 1; i <= m; i++)
  {
    for(int j = 1; j <= m; j++)
    {
      int p = rand() % 1000 * 1000;
      if(p < 1.1 * m)
        fprintf(p1,"1 ");
      else
        fprintf(p1,"0 ");
    }
    //printf("\n");
  }
  fclose(p1);
  FILE *p2 = fopen("C:/Users/Master/Desktop/1/test1.txt", "r");

      //freopen("C:/Users/Master/Desktop/1/test.txt","r", stdin);
  fscanf(p2,"%d", &n);
//  cout << "Please input the matrix:" << endl;
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= n; j++)
    {
      fscanf(p2, "%d", &matrixM[i][j]);
      matrixT[i][j] = matrixM[i][j];
    }
  //  cout << endl;
    //算法的主要部分，即传递闭包的计算
    double a = clock();
    double sum = 0;
    int cnt = 1;
    while(cnt--)
    {
    for(int i = 2; i <= n - 1; i++)
    {
      matrix_multiply();
      for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
          matrixT[i][j] = matrixT[i][j] | matrixA[i][j] ;
        }
    }

    }
    double b = clock();
    sum += b - a;
    //闭包矩阵的输出
  //  cout << "Output the transitive closure matrix :" << endl;

    /*for(int i = 1; i <= n; i++)
    {
      for(int j = 1; j <= n;j++)
      {
        cout << matrixT[i][j] << " ";
      }
      cout << endl;
    }*/
    cout << "the size of the matrix is:" << n << "  ";

    printf("the average runtime is %.6fs\n",sum/CLOCKS_PER_SEC);

  m += 1000;

  fclose(p2);
}
}
