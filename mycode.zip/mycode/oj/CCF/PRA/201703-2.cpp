#include <bits/stdc++.h>
using namespace std;
int pos[1010], num[1010]; // pos为学号为i的同学的位置, num为位置为i的同学的编号
void init(int n)
{
  for(int i = 1; i <= n; i++)
    pos[i] = num[i] = i;
}
void move(int no, int stp)
{
  if(stp == 0)  return;
  int p = pos[no], d = (stp > 0 ? 1 : -1);
  for(int i = p; i != p + stp; i += d)
  {
    num[i] = num[i + d];
    pos[num[i]] = i;
  }
  num[p + stp] = no;
  pos[num[p + stp]] = p + stp;
}
void Print(int n)
{
  for(int i = 1; i <= n; i++)
    cout << num[i] << " ";
  cout << endl;
//  for(int i = 1; i <= n; i++)
//    cout << pos[i] << " ";
//  cout << endl;
}
int main()
{
  ios::sync_with_stdio(false);
  int n, m;
  cin >> n >> m;
  init(n);
  for(int i = 1; i <= m; i++)
  {
    int no, stp;
    cin >> no >> stp;
    move(no, stp);
  }
    Print(n);
}
