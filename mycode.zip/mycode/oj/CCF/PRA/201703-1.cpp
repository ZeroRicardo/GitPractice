#include <bits/stdc++.h>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int n, k, tmp, a, ans;
  cin >> n >> k;
  tmp = 0, ans = 0;
  for(int i = 0; i < n; i++)
  {
    cin >> a;
    tmp += a;
    if(tmp >= k){
      ans++;
      tmp = 0;
    }
  }
  if(tmp) ans++;
  cout << ans << endl;
  return 0;
}
