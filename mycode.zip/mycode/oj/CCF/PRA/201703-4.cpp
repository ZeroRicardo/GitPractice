#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int MAX_V = 100010;
struct Edge{
  int to, cost;
  Edge(){}
  Edge(int _to, int _cost):to(_to), cost(_cost){}
};
vector<Edge> G[MAX_V];
ll dis[MAX_V];
void init()
{
  for(int i = 0; i < MAX_V; i++)
    G[i].clear();
}
void addedge(int u, int v, int w)
{
  G[u].push_back(Edge(v, w));
  G[v].push_back(Edge(u, w));
}
void dijkstra(int s)
{
  memset(dis, 0x7f, sizeof dis);
  priority_queue<pair<ll, int> > q;
  dis[s] = 0;
  q.push(make_pair(0, s));
  while(!q.empty())
  {
    int u = q.top().second; q.pop();
    for(int i = 0; i < G[u].size(); i++)
    {
      int v = G[u][i].to, cost = G[u][i].cost;
      if(dis[v] > dis[u] && dis[v] > cost)
      {
        dis[v] = max(dis[u], (ll)cost);
        q.push(make_pair(-dis[v], v));
      }
    }
  }
}
int main()
{
  int V, E;
  int u, v, w;
  scanf("%d%d", &V, &E);
  for(int i = 1; i <= E; i++)
  {
    scanf("%d%d%d", &u, &v, &w);
    addedge(u, v, w);
  }
  dijkstra(1);
//  for(int i = 1; i <= V; i++)
    printf("%lld\n", dis[V]);
  return 0;
}
