#include <bits/stdc++.h>

using namespace std;
int score[110], cost[110];
bool path[110];
int dp[110][1010];
int pre[110][1010];
int main()
{
  int T;
  //freopen("1.txt", "r", stdin);
  scanf("%d", &T);
  for(int cas = 1; cas <= T; cas++)
  {
    int N, B;
    scanf("%d%d", &B, &N);
     for(int i = 1; i <= N; i++)
     scanf("%d%d", &score[i], &cost[i]);
     memset(dp, 0, sizeof(dp));
     memset(path, 0, sizeof(path));
     for(int i = 1; i <= N; i++)
      {
        for(int v = B; v >= 0; v--)
        if(v >= cost[i]){
          if(dp[i - 1][v] >= dp[i - 1][v - cost[i]] + score[i])
          {
            dp[i][v] = dp[i - 1][v];
            pre[i][v] = (i - 1) * 1010 + v;
          }
          else{
            dp[i][v] = dp[i - 1][v - cost[i]] + score[i];
            pre[i][v] = (i - 1) * 1010 + v - cost[i];
          }
        }
        else{
          dp[i][v] = dp[i -1][v];
          pre[i][v] = (i - 1) * 1010 + v;
        }
      }
      int re = N, rom = B;
      int tot = 0;
      while(re >= 1)
      {
        int prerom = pre[re][rom] % 1010;
        if(dp[re][rom] != dp[re - 1][prerom]){
          path[re] = 1;
          rom = prerom;
          tot += cost[re];
        }
        re--;

      }

      printf("Case #%d:\n", cas);
      printf("%d %d\n", dp[N][B], tot);
      bool flag = 0;
      for(int i = 1; i <= N; i++)
      {
        if(path[i])
        {
          if(!flag)
            printf("%d", i);
          else
            printf(" %d", i);
            flag = 1;
        }

      }
      if(flag)
      printf("\n");
  }
  return 0;
}
