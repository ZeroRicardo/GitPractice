#include <bits/stdc++.h>

using namespace std;
int a[100000 + 10], b[100000 + 10], k[1010], p[1010];
long long dp[20][1010];
int main()
{
  int n, m;
  while(~scanf("%d%d", &n, &m)){
    int maxb = 0, maxp = 0, maxa = 0;
    for(int i = 0; i < n; i++)
    {
      scanf("%d%d", &a[i], &b[i]);
      maxa = max(maxa, a[i]);
      maxb = max(maxb, b[i]);
    }
    for(int i = 0; i < m; i++)
    {
      scanf("%d%d", &k[i], &p[i]);
      maxp = max(maxp, p[i]);
    }
    if(maxb >= maxp)
      printf("-1\n");
    else{
      long long ans = 0;
      memset(dp, 63, sizeof(dp));
      for(int i = 0; i <= 10; i++)
        for(int j = 1; j <= maxa; j++)
        {
          for(int v = 0; v < m; v++)
          {
            long long hurt = p[v] - i;
            if(hurt <= 0) continue;
            else{
              if(hurt >= j) dp[i][j] = min(dp[i][j], (long long)k[v]);
              else  dp[i][j] = min(dp[i][j], dp[i][j - hurt] + k[v]);
            }
          }
        }
      for(int i = 0; i < n; i++)
        ans += dp[b[i]][a[i]];
      printf("%lld\n", ans);
    }
  }
}
