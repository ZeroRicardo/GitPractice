#include <bits/stdc++.h>

using namespace std;
int main()
{
  freopen("1.txt", "w", stdout);
  for(int i = 1; i <= 100; i++)
    printf("%d %d\n", i, i);
}
