#include <bits/stdc++.h>
using namespace std;
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int ans = 0, n;
    scanf("%d", &n);
    for(int i = 1; i * i <= n - 1; i++)
    {
      if((n - 1) % i == 0)
      {
        ans += 2;
      //  printf("%d\n", i);
        if(i * i == n - 1)  ans--;
      }
    }
    printf("%d\n", ans);
  }
  return 0;
}
