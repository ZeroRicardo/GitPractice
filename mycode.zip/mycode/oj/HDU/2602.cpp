#include <bits/stdc++.h>
using namespace std;
int f[1010], a[1010], w[1010];
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int n, V;
    scanf("%d%d", &n, &V);
    for(int i = 1; i <= n; i++)
      scanf("%d", &a[i]);
    for(int i = 1; i <= n; i++)
      scanf("%d", &w[i]);
    memset(f, 0, sizeof f);
    for(int i = 1; i <= n; i++)
      for(int j = V; j >= w[i]; j--)
        f[j] = max(f[j], f[j - w[i]] + a[i]);
    printf("%d\n", f[V]);
  }
  return 0;
}
