#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

struct no{
  char name[12];
  int ac, pen;
}stu[10];
bool cmp(struct no a, struct no b)
{
  if(a.ac == b.ac)
  {
    if(a.pen == b. pen)
    {
      return strcmp(a.name, b.name) < 0;
    }
    return a.pen < b.pen;
  }
  return a.ac > b.ac;
}
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int n, m, T = 0, i = 0;
  scanf("%d%d", &n, &m);
  while(scanf(" %s", &stu[i].name) == 1)
  {
    char temp[20];
    T++;

  //  printf("%s\n", stu[i].name);
    stu[i].ac = 0, stu[i].pen = 0;
    for(int j = 0; j < n; j++)
    {
      scanf(" %s", temp);
    //  printf(" %s ", temp);
      int len = strlen(temp);
      if(temp[0] == '0' || temp[0] == '-')
        continue;
      else
      {
        stu[i].ac++;
        int wa = 0, sub = 0, flag = 0;
        for(int k = 0; k < len; k++)
        {

          if(temp[k] == '(')
          {
            k++;
            flag = 1;
            while(temp[k]!=')')
            {
              wa *= 10;
              wa += temp[k] - '0';
              k++;
            }
          }
        //  printf("%d %d wa = %d\n", i, j, wa);
          if(k >= len - 1 && flag)
            break;
          sub *= 10;
          sub += temp[k] - '0';

        }
      //  printf("%d %d sub = %d\n", i, j, sub);
        stu[i].pen += sub + wa * m;

      }
    }
    i++;
  }
  sort(stu, stu + T, cmp);
  for(int j = 0; j < T; j++)
  {
    printf("%-10s %2d %4d\n", stu[j].name, stu[j].ac, stu[j].pen);
  }
  return 0;
}
