#include <bits/stdc++.h>
using namespace std;
int cnt[210];
int main()
{
  ios::sync_with_stdio(false);
  int T, n, x, y;
  cin >> T;
  while(T--)
  {
    cin >> n;
    memset(cnt, 0, sizeof cnt);
    for(int i = 1; i <= n; i++)
    {
      cin >> x >> y;
      x = (x + 1) / 2;
      y = (y + 1) / 2;
      if(y < x) swap(x, y);
      for(int j = x; j <= y; j++)
        cnt[j]++;
    }
    int ans = 0;
    for(int i = 1; i <= 200; i++){
      ans = max(ans, cnt[i]);
    }
    cout << ans * 10 << endl;
  }
  return 0;
}
