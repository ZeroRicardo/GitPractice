#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;
int main()
{
  int T, h, m, s;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d%d%d", &h, &m, &s);
    double angle1, angle2, ans;
    int ou = 0;
    angle1 = 30 * (h % 12) + 0.5 * m + 0.5 * s / 60;
    angle2 = 6 * m + 0.1 * s;
    ans = fabs(angle1 - angle2);
    if(ans > 180) ans = 360 - ans;
    ou = ans;
    printf("%d\n", ou);
  }
}
