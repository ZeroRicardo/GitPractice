#include <stdio.h>
#include <string.h>

int main()
{
  //freopen("1.txt","r",stdin);
  int n,mt;
  char ball[1010][20];
  char m[20];
  int cnt[1010];
  while(scanf("%d", &n)!=EOF){
    if(n == 0)
      break;
    mt = 0;
    memset(cnt, 0, sizeof(cnt));
    memset(ball, 0, sizeof(ball));
    for(int i=0; i<n;i++)
    {
      scanf(" %s", m);
      int flag = 1;
      for(int i = 0; i < mt; i++)
      {
        if(strcmp(m,ball[i]) == 0)
          {flag = 0;cnt[i]++;break;}
      }
      if(flag)
      strcpy(ball[mt++],m);
    }
    int maxi = 0;
    for(int i = 1; i < mt; i++)
    {
      if(cnt[maxi] < cnt[i])
        maxi = i;
    }
    printf("%s\n", ball[maxi]);
  }

}
