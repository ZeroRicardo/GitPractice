#include <stdio.h>
#define maxn 110
int f[maxn];
int main()
{
  int a, b, n;

  while(scanf("%d%d%d", &a, &b, &n)!=EOF)
  {
    if(a == 0 && b == 0 && n == 0)
      break;
    a %= 7;
    b %= 7;
    int beg, end, flag = 0;
    f[1] = 1, f[2] = 1;
    for(int i = 3; i <= n; i++)
    {
    //  printf("%d\n", i);
        f[i] = (a * f[i - 1] + b * f[i - 2]) % 7;
        for(int j = 2; j <= i - 1; j++)
        if(f[i] == f[j] && f[i - 1] == f[j - 1])
        {
          beg = i, end = j;
          flag = 1;
          break;
        }
    //    printf("%d\n", f[i]);
        if(flag)
        break;
  //      printf("%d\n", flag);
      }
    if(flag)
      printf("%d\n", f[(n - beg) % (beg - end) + end]);
    else
      printf("%d\n", f[n]);
  }
}
