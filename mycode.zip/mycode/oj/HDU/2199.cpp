#include <bits/stdc++.h>
using namespace std;
double f(double x,double y)
{
  return 8 * x * x * x * x + 7 * x * x * x + 2 * x * x + 3 * x + 6 - y;
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    double Y;
    scanf("%lf", &Y);
    double low = 0, high = 100, ans = -1, mid;
    for(int cnt = 1; cnt <= 500; cnt++)
    {
      ans = mid = (low + high) / 2;
      if(f(mid, Y)>= 0)
        high = mid;
      else
        low = mid;
    }
    if(fabs(f(ans, Y)) > 1e-6) printf("No solution!\n");
     else printf("%.4f\n", ans);
  }
}
