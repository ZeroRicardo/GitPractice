#include <bits/stdc++.h>
using namespace std;
int par[1010], ran[1010];
void init(int n)
{
  for(int i = 1; i <= n; i++){
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x)
{
  if(par[x] == x) return x;
  else  return par[x] = find(par[x]);
}
void unite(int x, int y)
{
  x = find(x), y = find(y);
  if(x == y)  return;
  if(ran[x] < ran[y])
    par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
int main()
{
  int n, m, a, b;
  while(~scanf("%d", &n))
  {
    if(n == 0)  break;
    scanf("%d", &m);
    init(n);
    int ans = n - 1;
    for(int i = 1; i <= m; i++)
    {
      scanf("%d%d", &a, &b);
      if(find(a) != find(b))
      {
        unite(a, b);
        ans--;
      }
    }
    printf("%d\n", ans);
  }
  return 0;
}
