#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 1
using namespace std;

long long dp[50];

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);

  dp[1] = dp[0] = 1;
  for(int i = 2; i <= 50; i++)
    dp[i] = dp[i - 1] + dp[i - 2];
  int n;
  scanf("%d", &n);
  while(n--){
    int a, b;
    scanf("%d%d", &a, &b);
    printf("%lld\n", dp[b - a]);
  }
  return 0;
}
