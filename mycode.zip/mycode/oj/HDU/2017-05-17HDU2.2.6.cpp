#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
//#define maxn 100000000
//using namespace std;
//int f[maxn + 10];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int a, b, n;
  int c, d, e, t;
  while(scanf("%d%d%d", &a, &b, &n) != EOF){
    if(a == 0 && b == 0 && n == 0)
      break;
    a = a % 7;
    b = b % 7;
    c = d = 1;
    if(n <= 2)
      printf("1\n");
    else
    {
      for(int i = 3; i <= n; i++)
      {
        e = (a * d + b * c) % 7;
        c = d;
        d = e;
      }
      printf("%d\n", e);
    }
  }
  return 0;

}
