#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <math.h>
#include <stdlib.h>
#include <string.h>

using namespace std;
typedef long long ll;
ll gcd(ll a, ll b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    ll a, b, c, d, e, f, t;
    scanf("%I64d/%I64d %I64d/%I64d", &a, &b, &c, &d);
    t = gcd(a, b);
    a /= t;
    b /= t;
    t = gcd(c, d);
    c /= t;
    d /= t;

    e = a * c / gcd(a, c);
    f = gcd(b , d);
      ll g = gcd(e, f);


    //  printf("g = %I64d\n", g);
      e = e / g, f = f / g;
      if(f == 1)
        printf("%I64d\n", e);
      else
        printf("%I64d/%I64d\n", e, f);

  }
}
