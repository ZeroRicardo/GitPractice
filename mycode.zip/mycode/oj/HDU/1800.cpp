#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int M = 10007;
int a[M];
int cnt[M];
int hash_int(unsigned int x)
{
  int k = x % M;
  while(cnt[k] && a[k] != x)  k = (k + 1) % M;
  return k;
}
int main()
{
  int n, tmp, p, k, t, ans;
  while(~scanf("%d", &n))
  {
    ans = 0;
    memset(cnt, 0, sizeof cnt);
    for(int i = 1; i <= n; i++)
    {
      scanf("%d", &tmp);
      p = hash_int(tmp);
      cnt[p]++;
      a[p] = tmp;
      ans = max(cnt[p], ans);
    }
    printf("%d\n", ans);
  }
}
