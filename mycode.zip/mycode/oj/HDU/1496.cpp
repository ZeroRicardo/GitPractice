#include <cstdio>
#include <cstring>
using namespace std;
const int mod = 50021;
int cnt[mod];
int f[mod];
int hash_int(int x)
{
  int p = x % mod;
  if(p < 0) p += mod;
  while(cnt[p] && f[p] != x)  p = (p + 1) % mod;
  return p;
}
int main()
{
  int a, b, c, d, p, t;
  while(~scanf("%d%d%d%d", &a, &b, &c, &d))
  {
    if((a > 0 && b > 0 && c > 0 && d > 0) || (a < 0 && b < 0 && c < 0 && d < 0))
    {
      printf("0\n");
      continue;
    }
    memset(cnt, 0, sizeof cnt);
    for(int i = 1; i <= 100; i++)
      for(int j = 1; j <= 100; j++)
      {
        p = hash_int(a * i * i + b * j * j);
        cnt[p]++;
        f[p] = a * i * i + b * j * j;
      }
    int ans = 0;
    for(int i = 1; i <= 100; i++)
      for(int j = 1; j <= 100; j++)
      {
        p = hash_int(-c * i * i - d * j * j);
        ans += cnt[p];
      }
    printf("%d\n", ans * 16);
  }
  return 0;
}
