#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;





int main()
{
  int a, b, st, ed, r;
  while(scanf("%d%d", &a, &b) != EOF)
  {
    st = a, ed = b;
    if(st > ed)
    {
      int t = st;
      st = ed;
      ed =t;
    }

    int ans = 0;
    for(int i = st; i <= ed; i++)
    {
      int tmp = i;
      r = 0;
        while(tmp != 1)
        {
          if(tmp % 2) tmp = tmp * 3 + 1;
          else tmp /= 2;
          r++;
        }
        r++;

      ans = max(ans, r);
    }
    printf("%d %d %d\n", a, b, ans);
  }

}
