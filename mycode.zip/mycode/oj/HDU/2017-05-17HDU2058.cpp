#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 100000
using namespace std;

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int N, M;
  while(scanf("%d%d", &N, &M) != EOF){
    if(N == 0 && M == 0)
      break;
    int n = sqrt(2 * M) + 1, a;
    for(; n >= 1; n--)
    {
      a = (M - (n * n - n) / 2) / n;
      if(a * n + (n * n - n) / 2 == M && a >= 1)
        printf("[%d,%d]\n", a, a + n - 1);
    }
    printf("\n");
  }
}
