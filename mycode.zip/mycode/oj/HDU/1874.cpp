#include <bits/stdc++.h>

using namespace std;
#define maxn 200
#define maxm 1000
int V, s, t, E;
int dis[maxn + 10], path[maxn + 10];
int cnt[maxn + 10];
bool vis[maxn + 10];
struct edge{
  int to, cost;
};
vector<edge> G[maxn + 10];

void addedge(int u, int v, int w)
{
  edge a, b;
  a.to = u, a.cost = w;
  b.to = v, b.cost = w;
  G[u].push_back(b);
  G[v].push_back(a);
}
bool spfa_dfs(int u)
{
  vis[u] = 1;
  for(int j = 0; j < G[u].size(); j++)
  {
    int v = G[u][j].to, w = G[u][j].cost;
    if(dis[v] > dis[u] + w)
    {
      dis[v] = dis[u] + w;
      if(!vis[v])
      {
        if(spfa_dfs(v))
          return 1;
      }
      else
        return 1;
    }
  }
  vis[u] = 0;
  return 0;
}
int main()
{
  while(~scanf("%d%d", &V, &E))
  {
    memset(dis, 0x3f, sizeof(dis));
    memset(path, 0, sizeof(path));
    memset(vis, 0, sizeof(vis));
    memset(cnt, 0, sizeof(cnt));
    for(int i = 0; i < maxn; i++)
      G[i].clear();
    for(int i = 0; i < E; i++)
    {
      int u, v, w;
      scanf("%d%d%d", &u, &v, &w);
      addedge(u, v, w);
    }
    scanf("%d%d", &s, &t);
    dis[s] = 0;
    spfa_dfs(s);
    if(dis[t] != 0x3f3f3f3f)
      printf("%d\n", dis[t]);
    else
      printf("%d\n", -1);
  }
}
