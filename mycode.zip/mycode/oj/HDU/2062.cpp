#include <bits/stdc++.h>
using namespace std;
long long F[22];
bool vis[22];
int n;
long long m;
void dfs(int len, long long tot)
{
  //cout << len << " " << tot << endl;
  if(len <= 0 || tot <= 0)  return;
  long long num = (tot - 1) / F[len] + 1;
  tot -= (num - 1) * F[len] + 1; 
  for(int i = 1; i <= n; i++)
  {
    if(!vis[i])
    {
      num--;
      if(num == 0)
      {
        vis[i] = 1;
        cout << i;
        if(len == 1 || tot == 0)  cout << endl;
        else  cout << " ";
        break;
      }
    }
  }
  dfs(len - 1, tot);
}
int main()
{
  F[1] = 1;
  for(int i = 2; i <= 20; i++)
    F[i] = (i - 1) * F[i - 1] + 1;
  while(cin >> n >> m)
  {
    memset(vis, 0, sizeof vis);
    dfs(n, m);
  }
}
