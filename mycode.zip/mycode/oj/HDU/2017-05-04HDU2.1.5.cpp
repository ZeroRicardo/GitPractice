#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
using namespace std;
// 改进筛法求素数的算法
int prime[1000010];

int main()
{
  int n;
  memset(prime, 0, sizeof(prime));

  int sum = 0;
  for(int i = 2; i <= 1000000; i++)
  {

    if(prime[i] == 0)
    {
      sum++;
      prime[i] = sum;
      for(int j = 2; j * i <= 1000000; j++)
      prime[i * j] = sum;
    }
  }


  while(scanf("%d", &n) != EOF)
  {
    printf("%d\n", prime[n]);
  }
}
