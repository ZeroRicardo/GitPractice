#include <bits/stdc++.h>
using namespace std;
int a[110];
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    int n, m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++)
      cin >> a[i];
    a[0] = 100;
    sort(a, a + n + 1);
    int ans = 0;
    ans = (a[n] - a[0]) * (a[n] - a[0]);
    cout << ans << endl;
  }
  return 0;
}
