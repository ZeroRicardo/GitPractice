//#define LOCAL
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;

#define LL long long
#define ll long long
#define INF 0x3f3f3f3f
#define maxn MAX_N
#define MOD mod
#define MMT(x,i) memset(x,i,sizeof(x))
#define REP(i, n) for(int i = 0; i < n; i++)
#define FOR(i, n) for(int i = 1; i <= n; i++)
#define pb push_back
#define mp make_pair
#define X first
#define Y second

const LL MOD = 1e9 + 7;
const double pi = acos(-1.0);
const double E = exp(1);
const double EPS = 1e-8;

const int MAX_N = 1000010;
int dp[10010][4];
int main()
{
  #ifdef LOCAL
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
  #endif
  ios::sync_with_stdio(false);
  dp[0][0] = dp[0][1] = dp[0][2] = 1;
  dp[1][0] = 2, dp[1][1] = dp[1][2] = 1, dp[1][3] = 0;
  for(int i = 2; i <= 130; i++)
  {
    dp[i][0] = (dp[i - 1][0] * 2 + dp[i - 1][1] + dp[i - 1][2]) % 10000;
    dp[i][1] = (dp[i - 1][0]  + dp[i - 1][1] * 2 + dp[i - 1][3]) % 10000;
    dp[i][2] = (dp[i - 1][0]  + dp[i - 1][2] * 2 + dp[i - 1][3]) % 10000;
    dp[i][3] = (dp[i - 1][1] + dp[i - 1][2] + dp[i - 1][3] * 2) % 10000;
//    cout << i << " " << dp[i][0] % 100 << endl;
  }
  int T;
  while(cin >> T)
  {
    if(T == 0)  break;
    for(int cas = 1; cas <= T; cas++)
    {
      long long n;
      cin >> n;
      int ans = 0;
      if(n <= 11) ans = dp[n][0];
      else  ans = dp[(n - 11) % (ll)20 + 11][0];
      cout << "Case " << cas <<": " << ans % 100<< endl;
    }
    cout << endl;
  }
  return 0;
}
