#include <bits/stdc++.h>
using namespace std;
int gcd(int a, int b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int main()
{
  int x, y;
  while(~scanf("%d%d", &x, &y))
    printf("%d\n", x * y / gcd(x, y));
  return 0;
}
