#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;
int tian[1010], king[1010];
bool cmp(int a, int b){
  return a > b;
}
int main()
{
  int n;
  while(scanf("%d", &n) == 1)
  {
    if(n == 0)
      break;
    for(int i = 0; i < n; i++){
      scanf("%d", &tian[i]);
    }
    for(int i = 0; i < n; i++){
      scanf("%d", &king[i]);
    }
    sort(tian, tian + n, cmp);
    sort(king, king + n, cmp);

    int  st1 = 0, ed1 = n - 1, st2 = 0, ed2 = n - 1, win = 0;
    while(st1 <= ed1)
    {
  //    printf("st1 = %d ed1 = %d st2 = %d ed2 = %d\n", st1, ed1, st2, ed2);
  //    printf("%d\n", tian[ed1] < king[st2]);
      if(tian[st1] > king[st2])
      {
        win++;
        st1++, st2++;
      }
      else if(tian[ed1] > king[ed2])
      {
        win++;
        ed1--, ed2--;
      }
      else if(tian[ed1] < king[st2]){
        win--;
        ed1--, st2++;
      }
      else
        break;
    //  printf("st1 = %d ed1 = %d st2 = %d ed2 = %d\n", st1, ed1, st2, ed2);
    }
    win *= 200;
    printf("%d\n", win);
  }
}
