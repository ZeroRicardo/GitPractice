#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
int flag[14];
int solve[14];
int main()
{
  int k;
  for(k = 1; k < 14; k++)
  {
    int m = 1 ,mark = 0;
    while(mark == 0){

      memset(flag, 0, sizeof(flag));
      for(int i = 1; i <= 2 * k; i++)
        flag[i] = 1;
      int cnt = 0, j = 1, dead = 0;
      mark = 1;
      while(dead < k)
      {
        if(flag[j])
          cnt++;
        if(cnt == m)
        {
          flag[j] = 0;
          if(j <= k)
          {
            mark = 0;
            break;
          }
          cnt = 0;
          dead++;
        }
        j++;
        j = (j - 1) % (2 * k) + 1;
      }
      if(mark)
      break;
      m++;
    }
    printf("%d\n", m);
  }

  
}
