#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll dp[1010];
int a[1010];
int main()
{
  int n;
  while(~scanf("%d", &n) && n)
  {
    memset(dp, 0, sizeof dp);
    for(int i = 1; i <= n; i++)
    {
      scanf("%d", &a[i]);
      dp[i] = a[i];
    }
    ll ans = 0;
    for(int i = 1; i <= n; i++)
    {
      for(int j = 1; j < i; j++)
      {
        if(a[i] > a[j])
          dp[i] = max(dp[i], dp[j] + a[i]);
      }
      ans = max(ans, dp[i]);
    }
//    for(int i = 1; i <= n; i++)
//      printf("%lld\n", dp[i]);
    printf("%lld\n", ans);
  }
}
