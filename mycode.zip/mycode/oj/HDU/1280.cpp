#include <bits/stdc++.h>
using namespace std;
int mark[10010], a[3010];
int main()
{
  int n, m;
  while(~scanf("%d%d", &n, &m))
  {
    memset(mark, 0, sizeof mark);
    for(int i = 1; i <= n; i++)
      scanf("%d", &a[i]);
    for(int i = 1; i <= n; i++)
      for(int j = i + 1; j <= n; j++)
        mark[a[i] + a[j]]++;
    for(int i = 10000; m; i--)
    {
        while(mark[i] && m)
        {
          m--;
          mark[i]--;
          printf("%d", i);
          if(m)
          printf(" ");

        }
    }
    printf("\n");
  }
  return 0;
}
