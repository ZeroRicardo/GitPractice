#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 100000
using namespace std;
int lamp[maxn + 10];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int n, T, ans;
  char c;
  scanf("%d", &T);
  while(T--){
    scanf(" %c %d", &c, &n);
    if('A' <= c && c <= 'Z')
      ans = c - 'A' + 1 + n;
    else if('a' <= c && c <= 'z')
      ans = n - (c - 'a' + 1);
    printf("%d\n", ans);
  }

}
