#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 100000
using namespace std;
int lamp[maxn + 10];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int n;
  while(scanf("%d", &n) != EOF){
    memset(lamp, 0, sizeof(lamp));
    for(int i = 1; i <= n; i++)
      for(int j = 1; j * i <= n; j++)
      {
        lamp[j * i] = !lamp[j * i];
      }
    printf("%d\n", lamp[n]);
  }
}
