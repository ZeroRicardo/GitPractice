#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;
struct cor{
  int x, y;
}pa[110];
double edge(double x1, double y1, double x2, double y2){
  return sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}
double cal(double x1, double y1, double x2, double y2, double x3, double y3){
  double p1 = edge(x1, y1, x2, y2), p2 = edge(x2, y2, x3, y3), p3 = edge(x3, y3, x1, y1), p0;
  p0 = (p1 + p2 + p3) / 2;
  return sqrt(p0 * (p0 - p1) * (p0 - p2) * (p0 - p3));
}
double call(double x0, double y0, double x1,double y1, double x2,double y2){
   return (x0*y1 + x2*y0 + x1*y2 - x2*y1 - x0*y2 - x1*y0 ) / 2;
}
int main()
{
  int n;
  while(scanf("%d", &n) != EOF){
    if(n == 0)
      break;
    double x0 = 0, y0 = 0, area = 0;
    for(int i = 0; i < n; i++)
    {
      scanf("%d%d", &pa[i].x, &pa[i].y);

    }

    for(int i = 1; i < n - 1; i++)
    {
      area += call(pa[0].x, pa[0].y, pa[i].x, pa[i].y, pa[i + 1].x, pa[i + 1].y);
    }
    printf("%.1f\n", area);
  }
}
