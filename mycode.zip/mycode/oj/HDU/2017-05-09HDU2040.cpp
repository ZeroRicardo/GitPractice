#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define long long ll
#define maxn 600000
using namespace std;

int list[maxn + 10];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  memset(list, 0, sizeof(list));

  int T;
  scanf("%d", &T);
  while(T--)
  {
    int a, b;
    int sa = 0, sb = 0;
    scanf("%d%d", &a, &b);
    for(int i = 1; i < a; i++)
    {
        if(a % i == 0)
          sa += i;
    }
    for(int i = 1; i < b; i++)
    {
        if(b % i == 0)
          sb += i;
    }

    if(a == sb && b == sa)
      printf("YES\n");
    else
      printf("NO\n");
  }



}
