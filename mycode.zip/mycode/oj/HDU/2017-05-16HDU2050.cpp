#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 1
using namespace std;

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int n;
  while(scanf("%d", &n) != EOF){
    int n;
    scanf("%d", &n);
    printf("%d\n", 2 * n * n - n + 1);
  }
  return 0;
}
