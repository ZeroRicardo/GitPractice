#include <bits/stdc++.h>
using namespace std;
#define MAX_V 10010
const int N = 500;
vector<int> G[MAX_V];
bool check[MAX_V];
int matching[MAX_V];
int num_left, num_nodes, num_right, num_edges, n;
int w[510], h[510], l[510];
void addedge(int u, int v)
{
  G[v].push_back(u), G[u].push_back(v);
}
bool dfs(int u)
{
  for(int i = 0; i < G[u].size(); i++)
  {
    int v = G[u][i];
    if(!check[v])
    {
      check[v] = true;
      if(matching[v] == -1 || dfs(matching[v]))
      {
        matching[v] = u;
        matching[u] = v;
        return true;
      }
    }
  }
  return false;
}
int hungarian()
{
  int ans = 0;
  memset(matching, -1, sizeof(matching));
  for(int u = 1; u <= num_left; u++)
  {
    if(matching[u] == -1)
    {
      memset(check, 0, sizeof(check));
      if(dfs(u))
        ans++;
    }
  }
  return ans;
}
int main()
{
  while(~scanf("%d", &n) && n)
  {
    num_left = num_right = n;
    for(int i = 1; i <= 2000; i++)
      G[i].clear();
    for(int i = 1; i <= n; i++)
      scanf("%d%d%d", &w[i], &h[i], &l[i]);
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= n; j++)
      {
        if(w[i] < w[j] && h[i] < h[j] && l[i] < l[j])
          addedge(i, j + n);
      }
    int ans = n - hungarian();
    printf("%d\n", ans);
  }
  return 0;
}
