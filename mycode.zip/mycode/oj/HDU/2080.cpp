#include <bits/stdc++.h>
using namespace std;
double getangle(double x, double y)
{
  double ret = 0;
  if(fabs(x) < 1e-8){
    if(y > 0) ret = 90;
    else ret = -90;
  }
  else if(fabs(y) < 1e-8)
  {
    if(x > 0) ret = 0;
    else ret = 180;
  }
  else
    ret = atan(y / x) / acos(-1.0) * 180;
  return ret;
}
int main()
{
  int T;
  double x1, x2, y1, y2, angle1, angle2, ans;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%lf%lf%lf%lf", &x1, &y1, &x2, &y2);
    angle1 = getangle(x1, y1);
    angle2 = getangle(x2, y2);
  //  printf("%.2f %.2f\n", angle1, angle2);
    ans = fabs(angle2 - angle1);
    if(ans > 180) ans = 360 - ans;
    printf("%.2f\n", ans);
  }
  return 0;
}
