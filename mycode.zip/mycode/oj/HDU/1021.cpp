#include <bits/stdc++.h>
using namespace std;
int F[1000010];
int main()
{
  F[0] = 7 % 3, F[1] = 11 % 3;
  for(int i = 2; i <= 1000000; i++)
    F[i] = (F[i - 1] % 3 + F[i - 2] % 3) % 3;
  int n;
  while(~scanf("%d", &n))
    printf("%s\n", F[n] ? "no" : "yes");
  return 0;
}
