#include <bits/stdc++.h>
using namespace std;
int main()
{
  int T;
  cin >> T;
  while(T--)
  {
    int n, m;
    int cas = 1;
    while(cin >> n >> m)
    {
      if(n == 0 && m == 0)  break;
      int ans = 0;
      for(int a = 1; a < n; a++)
        for(int b = a + 1; b < n; b++)
          if((a * a + b * b + m) / a / b * a * b == (a * a + b * b + m))
            ans++;
      cout << "Case " << cas++ << ": " << ans << endl;
    }
    if(T)
    cout << endl;
  }
}
