#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define long long ll

using namespace std;
struct pro{
  int s, e;
}T[110];

bool cmp(struct pro a, struct pro b){
  return a.e == b.e ? a.s < b.s : a.e < b.e;
}
int main()
{
      //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
    int n;
    while(scanf("%d", &n) != EOF)
    {
      if(n == 0)
        break;
      else
        for(int i = 0; i < n; i++){
          scanf("%d%d", &T[i].s, &T[i].e);
        }
        sort(T, T + n, cmp);
      /*  for(int i = 0; i < n; i++){
          printf("%d %d\n", T[i].s, T[i].e);
        }*/
        int ans = 1, curi = 0;
        for(int i = 1; i < n; i++)
        {
          if(T[i].s >= T[curi].e)
          {
            ans++;
            curi = i;
          }
        }
        printf("%d\n", ans);

    }
}
