#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 1
using namespace std;

long long dp[50];

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  dp[1] = 3, dp[2] = 8;
  for(int i = 3; i <= 40; i++)
    dp[i] = 2 * (dp[i - 1] + dp[i - 2]);
  int n;
  while(scanf("%d", &n) != EOF){
    printf("%lld\n", dp[n]);
  }
  return 0;
}
