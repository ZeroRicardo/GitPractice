#include <bits/stdc++.h>
using namespace std;
double y;
double f(double x)
{
  return x * (-y + x * (5 + x * (7 + x * x * x * (8 + x * 6))));
}
double ff(double x)
{
  return -y + x * (10 + x * (21 + x * x * x * (48 + 42 * x)));
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%lf", &y);
    double low = 0, high = 100, ans;
    for(int cnt = 1; cnt <= 100; cnt++)
    {
      double mid = (low + high) / 2;
      if(ff(mid) - 1e-7 <= 0)  ans = low = mid;
      else  high = mid;
    }
    printf("%.4f\n", f(ans));
  }
}
