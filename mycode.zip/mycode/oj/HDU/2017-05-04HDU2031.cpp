#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
char s[110];
int main()
{
  int n, r;
  while(scanf("%d%d", &n, &r) != EOF){
    int i = 0, t, flag = 0;
    if(n < 0)
    {
       n = - n;
       flag = 1;
    }
    while(n != 0)
    {
       t = n % r;
      n /= r;
      if(t <= 9)
        s[i++] = t + '0';
      else
        s[i++] = t - 10 + 'A';
    }
    int len = i;
    if(flag)
      printf("-");
    for(int i = len - 1; i >= 0; i--)
      printf("%c",s[i]);
    printf("\n");
  }
}
