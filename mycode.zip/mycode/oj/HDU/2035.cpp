#include <bits/stdc++.h>
using namespace std;
int quick_pow(int x, int n)
{
  x = x % 1000;
  int ret = 1;
  while(n)
  {
    if(n % 2) ret = (ret * x) % 1000;
    x = (x * x) % 1000;
    n >>= 1;
  }
  return ret;
}
int main()
{
  int a, b;
  while(~scanf("%d%d", &a, &b) && (a || b))
    printf("%d\n", quick_pow(a, b));
  return 0;
}
