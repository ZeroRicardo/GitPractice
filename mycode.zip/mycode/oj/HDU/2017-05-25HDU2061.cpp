#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

int main()
{
  int t, n, flag;
  double gpa, sumc,c,s, sums;
  string str;
  cin >> t;
  while(t--){
    getchar();
    cin >> n;
    flag = sumc = sums = 0;
    while(n--){
      cin >> str >> c >> s;
      if(s < 60)
        flag = 1;
      sumc += c;
      sums += c * s;
    }
    gpa = sums / sumc;
    if(flag)
      cout << "Sorry!" << endl;
    else
      printf("%.2lf\n", gpa);
    if(t)
      cout << endl;
  }
  return 0;
}
