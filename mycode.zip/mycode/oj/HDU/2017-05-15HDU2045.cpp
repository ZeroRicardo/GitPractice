#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 1
using namespace std;

long long dp[50];

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  dp[1] = 3, dp[2] = 6, dp[3] = 6;
  for(int i = 4; i <= 50; i++)
    dp[i] = dp[i - 2] * 2 + dp[i - 1];
  int n;
  while(scanf("%d", &n) != EOF){
    printf("%lld\n", dp[n]);
  }
  return 0;
}
