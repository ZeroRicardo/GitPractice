#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define long long ll

using namespace std;
bool judge(double a, double b, double c){
  return a < b + c && b < a + c && c < a + b;
}
int main()
{
      //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
      int T;
    scanf("%d", &T);
    while(T--)
    {
      double a, b, c;
      scanf("%lf%lf%lf", &a, &b, &c);
      if(judge(a, b, c))
        printf("YES\n");
      else
        printf("NO\n");
    }
    return 0;
}
