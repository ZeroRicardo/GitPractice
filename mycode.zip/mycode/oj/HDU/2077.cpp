#include <bits/stdc++.h>
using namespace std;
int dp[50];
int main()
{
  memset(dp, 0, sizeof dp);
  dp[0] = 0;
  for(int i = 1; i <= 20; i++)
    dp[i] = 3 * dp[i - 1] + 1;
  int T;
  cin >> T;
  while(T--)
  {
    int n;
    cin >> n;
    cout << 2 * dp[n - 1] + 2 << endl; 
  }
}
