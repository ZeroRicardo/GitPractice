#include <bits/stdc++.h>
using namespace std;
struct node{
  int w, s, id;
  bool operator < (const node &x)const{
    return w < x.w;
  }
}a[1010];
int pre[1010], dp[1010];
int main()
{
  int i = 0, n, ans;
  while(~scanf("%d%d", &a[i].w, &a[i].s))
  {
    a[i].id = i + 1;
    i++;
  }
  n = i;
  sort(a, a + n);
  ans = 0;
  memset(dp, 0, sizeof dp);
  memset(pre, -1, sizeof pre);
  for(i = 0; i < n; i++)
    for(int j = 0; j < i; j++)
    {
      if(a[i].w > a[j].w && a[i].s < a[j].s)
      {
        if(dp[i] < dp[j] + 1)
        {
          dp[i] = dp[j] + 1;
          pre[i] = j;
        }
      }
    }
  int pos;
  for(i = 0; i < n; i++)
    if(dp[i] > ans)
    {
      ans = dp[i];
      pos = i;
    }
  printf("%d\n", ans + 1);
  stack<int> out;
  while(pos != -1)
  {
    out.push(pos);
    pos = pre[pos];
  }
  while(!out.empty())
  {
    int p = out.top();
    printf("%d\n", a[p].id);
    out.pop();
  }
  return 0;
}
