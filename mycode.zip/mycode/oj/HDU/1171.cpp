#include <bits/stdc++.h>
using namespace std;
int dp[105010];
int a[1052], b[1052];
int main()
{
  int n;
  while(cin >> n)
  {
    if(n < 0) break;
    int sum = 0, V = 0;
    for(int i = 1; i <= n; i++)
    {
      cin >> a[i] >> b[i];
      sum += a[i] * b[i];
    }
    V = sum / 2;
    memset(dp, 0, sizeof dp);
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= b[i]; j++)
        for(int k = V; k >= a[i]; k--)
          dp[k] = max(dp[k], dp[k - a[i]] + a[i]);
    cout << sum - dp[V] << " " << dp[V] << endl;
  }
}
