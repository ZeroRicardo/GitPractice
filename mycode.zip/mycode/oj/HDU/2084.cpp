#include <bits/stdc++.h>
using namespace std;
int dp[110][110];
int a[110][110];
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--){
    memset(dp, 0, sizeof dp);
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= i; j++)
        cin >> a[i][j];
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= i; j++)
        dp[i][j] = max(dp[i - 1][j], dp[i - 1][j - 1]) + a[i][j];
    int ans = 0;
    for(int i = 1; i <= n; i++)
      ans = max(ans, dp[n][i]);
    cout << ans << endl;
  }
  return 0;
}
