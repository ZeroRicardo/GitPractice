#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>

int tria[32][32];
int main()
{
  memset(tria, 0, sizeof(tria));
  for(int i = 1; i <= 30; i++)
  {
     tria[i][1] = 1;
     tria[i][i] = 1;
  }
  for(int i = 3; i <= 30; i++)
  {
    for(int j = 2; j <= i - 1; j++)
      tria[i][j] = tria[i - 1][j - 1] + tria[i - 1][j];
  }
  int n;
  while(scanf("%d", &n) != EOF){
    for(int i = 1; i <= n; i++){
      for(int j = 1; j <= i; j++){
          if(j == 1) printf("%d", tria[i][j]);
          else
             printf(" %d", tria[i][j]);
      }
      printf("\n");
    }
    printf("\n");
  }
}
