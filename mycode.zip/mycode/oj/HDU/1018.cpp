#include <bits/stdc++.h>
using namespace std;
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int n;
    scanf("%d", &n);
    double ans = 0;
    for(int i = 1; i <= n; i++)
      ans += log(i * 1.0) / log(10.0);
    printf("%.f\n", ans + 0.5);
  }
}
