#include <bits/stdc++.h>
using namespace std;
int main()
{
  int n, m;
  while(~scanf("%d%d", &n, &m))
  {
    if(n == 0 && m == 0)  break;
    if(n % 2 && m % 2)
      printf("What a pity!\n");
    else
      printf("Wonderful!\n");
  }
  return 0;
}
