#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>

using namespace std;

long long gcd(long long a, long long b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int main()
{
  int T;
  long long lit1, lit2, len1, len2;
  char s[20];
  scanf("%d", &T);
  while(T--){
    scanf("%s", s);
//    printf("%s", s);
    lit1 = lit2 = 0;
    len1 = len2 = 0;
    for(int i = 2; s[i]; i++)
    {
      if(s[i] == '(')
      {
        i++;
        while(s[i] != ')')
        {
          lit2 *= 10;
          lit2 += s[i] - '0';
          len2++;
          i++;
        }
      }
      else
      {
        lit1 *= 10;
        lit1 += s[i] - '0';
        len1++;
      }
    }

    long long a = 1 , b = 1;
    for(int i = 1; i <= len1; i++)
      a *= 10;
    for(int i = 1; i <= len2; i++)
      b *= 10;
    b = b - 1;
    long long m = lit1 * b + lit2, l = a * b, g;
    if(b == 0)
    {
      g = gcd(lit1, a);
      printf("%I64d/%I64d\n", lit1 / g, a / g);
    }
    else
    {
      g = gcd(m, l);
      printf("%I64d/%I64d\n", m / g, l / g);
    }

  }
  return 0;
}
