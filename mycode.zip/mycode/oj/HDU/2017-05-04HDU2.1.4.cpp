#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

int gcd(int a, int b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int main()
{
  int p, q;
  while(scanf("%d%d", &p, &q) != EOF){
    printf("%d\n", p + q - gcd(p, q));
  }
  return 0;
}
