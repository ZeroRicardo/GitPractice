#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std;

int main()
{
  long long m = 1, a, b;
  freopen("1.txt", "r", stdin);
  scanf("%d%d",&a,&b);
  printf("%d\n", a + b);
  for(int i = 1; i <= 20; i++)
  m *= i;
  printf("%lld\n", m);
  return 0;
}
