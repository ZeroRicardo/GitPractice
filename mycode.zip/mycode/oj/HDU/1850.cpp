#include <bits/stdc++.h>
using namespace std;
int main()
{
  int a[210];
  int n;
  int t, ans;
  while(~scanf("%d", &n))
  {
    if(n == 0)  break;
    ans = 0;
    for(int i = 1; i <= n; i++)
    {
      scanf("%d", &a[i]);
      ans = ans ^ a[i];
    }
    if(ans == 0)  printf("0\n");
    else
    {
      int ct = 0;
      for(int i = 1; i <= n; i++)
      {
        t = ans ^ a[i];
        if(t < a[i])  ct++;
      }
      printf("%d\n", ct);
    }
  }
}
