//dp unsolved
// f(4, 2) = f(3, 2)
// f(3, 2) = f(2, 2) + f()
#include <bits/stdc++.h>
using namespace std;
const int maxn = 510;
int dp[maxn][maxn];
int main(){
  dp[1][1] = 1;
  for(int i = 2; i <= 500; i++){
    dp[i][1] = dp[i - 1][1];
    int t = sqrt(i);
    if(t * t != i)  dp[i][1]++;
  }
  for(int i = 2; i <= 500; i++)
    for(int j = 2; j <= 500; j++){
      dp[i][j] = dp[i - 1][j];
      int t = sqrt(i);
      if(t * t != i)  dp[i][j] += dp[i - 1][j - 1];
    }
  for(int i = 1; i <= 10; i++){
    for(int j = 1; j <= 10; j++)
      printf("%d ", dp[i][j]);
    printf("\n");
  }
  /*
  int n, m, T;
  scanf("%d", &T);
  while(T--){
    scanf("%d%d", &n, &m);
    printf("%d\n", dp[n][m]);
  }
  */
}
