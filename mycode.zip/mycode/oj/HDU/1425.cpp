#include <bits/stdc++.h>
using namespace std;
bool mark[1000010];
int main()
{
  ios::sync_with_stdio(false);
  int n, m, tmp;
  while(cin >> n >> m)
  {
    memset(mark, 0, sizeof mark);
    for(int i = 1; i <= n; i++)
    {
      cin >> tmp;
      mark[tmp + 500000] = 1;
    }
    for(int i = 1000000, cnt = m; cnt;i--)
    {
      if(mark[i])
      {
        cnt--;
        cout << i - 500000;
        if(cnt)
        cout << " ";
      }
    }
    cout << endl;
  }
}
