#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll f[110];
int main()
{
  f[0] = 1;
  for(int i = 1; i <= 100; i++)
    f[i] = f[i - 1] * (4 * i - 2) / (i + 1);
  int n;
  while(~scanf("%d", &n))
  {
    if(n == -1) break;
    printf("%lld\n", f[n]);
  }
}
