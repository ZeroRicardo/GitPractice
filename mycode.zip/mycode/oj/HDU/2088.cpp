#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
  ios::sync_with_stdio(false);
  int n, h[110];
  bool first = true;
  while(cin >> n)
  {
    if(n == 0)  break;
    if(first) first = false;
    else  cout << endl;
    int sum = 0, ans = 0;
    for(int i = 0; i < n; i++)
    {
      cin >> h[i];
      sum += h[i];
    }
    sum /= n;
    for(int i = 0; i < n; i++)
    {
      if(h[i] > sum)
        ans += h[i] - sum;
    }
    cout << ans ;
  }
  return 0;
}
