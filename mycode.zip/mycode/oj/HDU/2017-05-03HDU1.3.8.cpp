#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;
struct no{
  int num, mark;
}stu[1010];
bool cmp(struct no a, struct no b){
  return a.mark == b.mark ? a.num < b.num : a.mark > b.mark;
}
int main()
{
  int numj, markj, ans;
  priority_queue<int> q;
  while(scanf("%d", &numj) != EOF){
    int i = 0, n = 0, tnum, tmark;
    while(1){
      scanf("%d%d", &tnum, &tmark);
      q.push(tmark);
      if(tnum == 0 && tmark == 0)
        break;
      if(numj == tnum) markj = tmark;
      stu[i++].num = tnum, stu[i++].mark = tmark;
      n++;
    }
    ans = 1;
    while(markj < q.top())
    {
      q.pop();
      ans++;
    }
    while(q.size()) q.pop();
    
  /*  sort(stu, stu + n, cmp);
    ans = 1;
    for(i = 0; i < n; i++){
      if(stu[i].mark > markj)
        ans++;
      else
        break;
    }*/
    printf("%d\n", ans);
  }
  return 0;
}
