#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>

using namespace std;
//fibnocci数列通项公式，再用log函数处理取前几位。
#define maxn 100000000
int fib[1000];
int main()
{
  fib[0] = 0, fib[1] = 1;
  for(int i = 2; i <= 20; i++)
  {
    if(fib[i - 1] > 100000 && fib[i - 2] > 100000)
    {
      fib[i - 1] /= 10, fib[i - 2] /= 10;
    }
    fib[i] = fib[i - 1] + fib[i - 2];
  }
//  printf("%d\n", fib[20]);
  int n;
  while(scanf("%d", &n) != EOF){
    if(n <= 20)
      {
        while(fib[n] > 10000) fib[n] /= 10;
        printf("%d\n", fib[n]);
      }
    else
    {
      double num = - 0.5 * log(5.0) / log(10.0) + (double) n * log((sqrt(5.0) + 1.0)/2.0)/log(10.0);
      num -= int(num);
      num = pow(10.0, num);
      while(num < 1000) num *= 10;
      printf("%d\n", (int)num);
    }
  }
  return 0;
}
