#include <stdio.h>
#include <string.h>
#include <algorithm>

using namespace std;
#define maxn 100000
const int MOD = 1e9 + 7;
struct NUM{
  int bit[maxn + 10];
}num[26];
bool cmp(struct NUM x, struct NUM y){
  for(int i = maxn + 4; i >= 0; i--)
  {
    if(x.bit[i] != y.bit[i])
      return x.bit[i] > y.bit[i];
  }
  return 0;
}
int main()
{
  int n;
  char s[maxn + 10];
  int cas = 1;
  while(~scanf("%d", &n)){
    for(int i = 0; i < 26; i++)
      memset(num[i].bit, 0, sizeof(num[i].bit));
    for(int i = 0; i < n; i++){
      scanf(" %s", s);
      int len = strlen(s);
      for(int i = len - 1, j = 0; i >= 0; i--, j++){
        num[s[i] - 'a'].bit[j]++;
      }
  }
    for(int i = 0; i < 26; i++)
      for(int j = 0; j < maxn + 5; j++)
      {
        while(num[i].bit[j] >= 26){
          num[i].bit[j + 1]++;
          num[i].bit[j] -= 26;
        }
      }
    sort(num, num + 26, cmp);

    /*for(int i = 0; i < 26; i++){
      for(int j = 0; j < 5; j++)
        printf("%d ", num[i].bit[j]);
      printf("\n");
    }*/

    long long ans = 0, sum = 0;
    for(int cnt = 25; cnt >= 0; cnt--){
      sum = 0;
      for(int i = maxn + 5; i >= 0; i--)
      {
        sum = (sum * 26 + num[25 - cnt].bit[i]) % MOD;
      }
      sum = (cnt * sum) % MOD;
      ans = (ans + sum) % MOD;
    }
    printf("Case #%d: %lld\n", cas++,  ans);
  }
  return 0;
}
