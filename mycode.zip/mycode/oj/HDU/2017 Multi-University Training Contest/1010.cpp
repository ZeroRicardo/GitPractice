#include <bits/stdc++.h>
using namespace std;
struct P{
  int st, ed;
  bool operator < (const P &x)const{
    return st == x.st ? ed > x.ed : st < x.st;
  }
}TIM[100010];
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int n;
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
      scanf("%d%d", &TIM[i].st, &TIM[i].ed);
    sort(TIM, TIM + n);
  }
}
