#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
using namespace std;
long long mylove[500010];
int main()
{
  int T;
  memset(mylove, 0, sizeof(mylove));
  for(int i = 1; i <= 250000; i++){
    for(int j = 2 * i; j <= 500000; j += i){
      mylove[j] += i;
    }
  }
  scanf("%d", &T);
  while(T--){
    int n;
    scanf("%d", &n);

        printf("%I64d\n", mylove[n]);
      }

}
