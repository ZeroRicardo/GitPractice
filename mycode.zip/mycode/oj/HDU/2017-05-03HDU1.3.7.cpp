#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

struct no{
  int l, w;
}st1[5010], st2[5010], ft;
int flag[5010];
bool cmp1(struct no a, struct no b)
{
    return a.l == b.l ? a.w < b.w : a.l < b.l;
}
bool cmp2(struct no a, struct no b)
{
    return a.w == b.w ? a.l < b.l : a.w < b.w;
}
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int n, ans;
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
    {
        scanf("%d%d", &st1[i].l, &st1[i].w);
        flag[i] = 0;
    }
    sort(st1, st1 + n, cmp1);
    int cnt = n, ans1 = 0, i = 0, j = 0, w;
    for(i = 0; i < n; i++)
    {
      if(flag[i] == 0)
      {
        flag[i] = 1;
        w = st1[i].w;
        ans1++;
      }
      for(j = i + 1; j < n; j++)
      {
        if(flag[j] == 0)
        {
          if(st1[j].w >= w)
          {
            flag[j] = 1;
            w = st1[j].w;
          }
        }
      }
    }

    printf("%d\n",ans1);
  }
}
