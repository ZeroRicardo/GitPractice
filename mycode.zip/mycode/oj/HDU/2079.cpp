#include <bits/stdc++.h>
using namespace std;
int dp[100][50];
int a[50], b[50];
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    int n, k;
    cin >> n >> k;
    for(int i = 1; i <= k; i++)
      cin >> a[i] >> b[i];
    memset(dp, 0, sizeof dp);
    dp[0][0] = 1;
    for(int i = 1; i <= k; i++)
    {
      for(int m = 0; m <= b[i]; m++)
        for(int j = n; j >= m * a[i]; j--)
        {
          dp[i][j] += dp[i - 1][j - m * a[i]];
        //  cout << j << " " << dp[i][j] << endl;
        }
    }
    cout << dp[k][n] << endl;
  }
}
