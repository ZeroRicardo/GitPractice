#include <bits/stdc++.h>
using namespace std;
int dp[100010];
int main()
{
  int num[5];
  int a[5] = {0, 1, 2, 5};
  while(1)
  {
    int sum = 0;
    for(int i = 1; i <= 3; i++)
    {
      cin >> num[i];
      sum += num[i];
    }
    if(sum == 0)  break;
    memset(dp, 0, sizeof dp);
    dp[0] = 1;
    for(int i = 1; i <= 3; i++)
      for(int j = 1; j <= num[i]; j++)
        for(int k = 10000; k >= a[i]; k--)
        dp[k] += dp[k -  a[i]];
    int ans = 0;
    for(int i = 1; i <= 10000; i++)
      if(!dp[i])
      {
        ans = i;
        break;
      }
    cout << ans << endl;
  }
}
