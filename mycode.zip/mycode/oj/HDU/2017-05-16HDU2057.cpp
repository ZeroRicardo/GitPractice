#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 100000
using namespace std;

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  long long a, b, fa, fb, ans;
  char A[16], B[16], Ans[16];
  while(scanf("%s%s", A, B) != EOF)
  {
    int i = 0;
    fa = 1;
    if(A[0] == '-')
    {
      fa = -1;
      i++;
    }
    else if(A[0] == '+')
    {
      i++;
    }
    a = 0;
    for(; A[i];i++){
      a *= 16;
      if(A[i] >= 'A' && A[i] <= 'F')
        a += A[i] - 'A' + 10;
      else
        a += A[i] - '0';
    }
    a *= fa;
    i = 0;
    fb = 1;
    if(B[0] == '-')
    {
      fb = -1;
      i++;
    }
    else if(B[0] == '+')
    {
      i++;
    }
    b = 0;
    for(; B[i];i++){
      b *= 16;
      if(B[i] >= 'A' && B[i] <= 'F')
        b += B[i] - 'A' + 10;
      else
        b += B[i] - '0';
    }
    b *= fb;
    ans = a + b;
    int fans = 1;
    if(ans < 0)
    {
      fans = -1;
      ans = -ans;
    }
    i = 0;
    while(ans){
      int m = ans % 16;
      if(m >= 10 && m <= 15)
        Ans[i++] = m - 10 + 'A';
      else
        Ans[i++] = m  + '0';
      ans /= 16;
    }
    //printf("%lld %lld\n", a, b);
    if(fans < 0)
    printf("-");
    if(i == 0)
      printf("0");
    for(int j = i - 1; j >= 0; j--)
      printf("%c", Ans[j]);

    printf("\n");

  }
}
