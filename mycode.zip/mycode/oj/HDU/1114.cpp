#include <bits/stdc++.h>
using namespace std;
int P[520], W[520];
int f[10010];
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int E, F, V, n;
    scanf("%d%d", &E, &F);
    scanf("%d", &n);
    V = F - E;
    for(int i = 1; i <= n; i++)
      scanf("%d%d", &P[i], &W[i]);
    memset(f, 0x3f, sizeof f);
    f[0] = 0;
    for(int i = 1; i <= n; i++)
      for(int j = W[i]; j <= V; j++)
        f[j] = min(f[j], f[j - W[i]] + P[i]);
    if(f[V] != 0x3f3f3f3f)
      printf("The minimum amount of money in the piggy-bank is %d.\n", f[V]);
    else
      printf("This is impossible.\n");
  }
}
