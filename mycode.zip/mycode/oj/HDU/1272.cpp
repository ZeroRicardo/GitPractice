#include <bits/stdc++.h>
using namespace std;
const int maxn = 100000 + 10;
int par[maxn], ran[maxn], vis[maxn];
void init()
{
  for(int i = 1; i <= 100000; i++)
  {
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x)
{
  if(par[x] == x) return x;
  else  return par[x] = find(par[x]);
}
void unite(int x, int y)
{
  x = find(x), y = find(y);
  if(x == y) return;
  if(ran[x] < ran[y])
    par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
int main()
{
  int a, b;
  bool flag = 1;
  while(~scanf("%d%d", &a, &b))
  {
    if(a == -1 && b == -1)  break;
    init();
    memset(vis, 0, sizeof vis);
    flag = 1;
    vis[a] = vis[b] = 1;
    if(find(a) == find(b))
      flag = 0;
    unite(a, b);
    if(a == 0 && b == 0)  printf("Yes\n");
    else
    {
      while(~scanf("%d%d", &a, &b))
      {
        if(a == 0 && b == 0)  break;
        if(find(a) == find(b)) flag = 0;
        unite(a, b);
        vis[a] = vis[b] = 1;
      }
      int t = -1;
      if(flag)
      for(int i = 1; i <= 100000; i++)
        if(vis[i]){
          int t2 = find(i);
          if(t == -1) t = t2;
          if(t != t2) flag = 0;
        }
      if(flag)  printf("Yes\n");
      else  printf("No\n");
    }
  }
  return 0;
}
