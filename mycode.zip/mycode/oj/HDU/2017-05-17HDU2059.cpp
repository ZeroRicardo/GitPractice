#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;
double dp[110];
int p[110];
int l, n, c, vr, t, vt1, vt2;

double haha(int i, int j)
{
//  if(j == 0)

  return  p[i] - p[j] < c ? (double)(p[i] - p[j]) / vt1 : (double)(p[i] - p[j] - c) / vt2  + c * 1.0 / vt1;

//  return min((p[i] - p[j]) * 1.0 / vt2, p[i] - p[j] < c ? (p[i] - p[j]) * 1.0 / vt1 + t : (p[i] - p[j] - c) * 1.0 / vt2 + t + c * 1.0 / vt1);
}
double seat(int p,int v1,int v2,int s)
{
    if(p>s)
        return (p-s)/(double)v2+s/(double)v1;
    return p/(double)v1;
}
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);


  double t1, t2;
  while(~scanf("%d%d%d%d%d%d%d",&l,&n,&c,&t,&vr,&vt1,&vt2)){

    p[0] = 0;
    for(int i = 1; i <= n; i++)
      scanf("%d", &p[i]);
    p[n + 1] = l;

    t1 = (double)l / vr;

    dp[1] = haha(1, 0);
      for(int i = 2; i <= n + 1; i++)
      {
        double minn = haha(i, 0);
        for(int j = 1; j < i; j++)
        {
          minn = min (minn, haha(i, j)+t+dp[j]);
        }
        dp[i] = minn;
      }


  //  for(int i = 1; i <= n + 1; i++)
  //    printf("%.4f\n", dp[i]);
    if(t1 < dp[n + 1])
      printf("Good job,rabbit!\n");
    else
      printf("What a pity rabbit!\n");
  }
  return 0;

}
