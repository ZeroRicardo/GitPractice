#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int val[8] = {0, 1, 2, 3, 4, 5, 6};
int num[8];
int w[810], v[810];
int dp[100010];
void Print(int n)
{
  for(int i = 1; i <= n; i++)
    printf("%d ", w[i]);
  printf("\n");
  for(int i = 1; i <= n; i++)
    printf("%d ", v[i]);
  printf("\n");
}
int main()
{
  int cas = 1;
  while(1)
  {
    int sum = 0;
    bool flag;
    for(int i = 1; i <= 6; i++){
      scanf("%d", &num[i]);
      sum += num[i] * val[i];
    }
    if(sum == 0)  break;
    if(sum % 2) flag = 0;
    else
    {
      int V = sum / 2;
      int tot = 0;
      for(int i = 1; i <= 6; i++){
        int t = 1, x = num[i];
        while(x >= t)
        {
          w[++tot] = t;
          v[tot] = t * val[i];
          x -= t;
          t <<= 1;
        }
        if(x){
          w[++tot] = x;
          v[tot] = x * val[i];
        }
      }
    //  Print(tot);
      memset(dp, 0, sizeof dp);
      for(int i = 1; i <= tot; i++)
        for(int j = V; j >= v[i]; j--)
          dp[j] = max(dp[j], dp[j - v[i]] + v[i]);
      if(dp[V] == V)  flag = 1;
      else  flag = 0;
    }
    printf("Collection #%d:\n", cas++);
    if(!flag)  printf("Can't be divided.\n\n");
    else  printf("Can be divided.\n\n");
  }
}
