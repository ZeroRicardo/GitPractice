#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;
int mypow(int a, int b){
  if(a > 1000) a %= 1000;
  if(b == 1) return a;
  if(b % 2 == 0)
    return mypow(a, b / 2) * mypow(a, b / 2) % 1000;
  else
    return mypow(a, b / 2) * mypow(a, b / 2) * a % 1000;
  }

int main()
{
  int a, b;
  while(scanf("%d%d", &a, &b) != EOF){
    if(a == 0 && b == 0)
      break;
    printf("%d\n", mypow(a, b));
  }
  return 0;
}
