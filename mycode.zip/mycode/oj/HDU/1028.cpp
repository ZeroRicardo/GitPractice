#include <bits/stdc++.h>
using namespace std;
int main()
{
  int n;
  int dp[222];
  while(cin >> n)
  {
    memset(dp, 0, sizeof dp);
    dp[0] = 1;
    for(int i = 1; i <= n; i++)
      for(int j = i; j <= n; j++)
        dp[j] += dp[j - i];
    cout << dp[n] << endl;
  }
}
