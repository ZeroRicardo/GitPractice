#include <bits/stdc++.h>
using namespace std;
char maze[11][11];
int n, m;
int sx, sy, ex, ey;
int cnt = 0;
bool flag = 0;
int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
void debug()
{
  for(int i = 1; i <= n; i++)
  {
    for(int j = 1; j <= m; j++)
      printf("%c", maze[i][j]);
    printf("\n");
  }
}
void dfs(int x, int y, int t)
{
  //printf("%d %d %d\n", x, y, t);
  //debug();
  if(flag == 1) return;
  if(x == ex && y == ey && t == 0){
    flag = 1;
    return;
  }
  int dis = fabs(x - ex) + fabs(y - ey) - t;
  if(dis > 0 || dis & 1) return;
  maze[x][y] = 'X';
  for(int i = 0; i < 4; i++)
  {
    int mx = x + dx[i], my = y + dy[i];
    if(1 <= mx && mx <= n && 1 <= my && my <= m && maze[mx][my] != 'X')
      dfs(mx, my, t - 1);
  }
  maze[x][y] = '.';
}
int main()
{
  int d;
  while(~scanf("%d%d%d", &n, &m, &d))
  {
    if(n == 0 && m == 0 && d == 0)  break;
    cnt = 0;
    for(int i = 1; i <= n; i++)
    {
      for(int j = 1; j <= m; j++)
      {
        scanf(" %c", &maze[i][j]);
        if(maze[i][j] == 'S'){sx = i, sy = j;}
        else  if(maze[i][j] == 'D'){ex = i, ey = j;}
        else if (maze[i][j] == '.') cnt++;
      }
    }
    int dis = fabs(sx - ex) + fabs(sy - ey);
    if(cnt < d - 1 || dis % 2 != d % 2) printf("NO\n");
    else{
      flag = 0;
      dfs(sx, sy, d);
      if(flag)  printf("YES\n");
      else  printf("NO\n");
    }
  }
}
