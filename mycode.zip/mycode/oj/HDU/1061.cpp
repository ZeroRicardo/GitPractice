#include <bits/stdc++.h>
using namespace std;
#define ll long long
int mypow(int x, int n)
{
  int ret = 1;
  while(n)
  {
    if(n % 2) ret = (ret * x) % 10;
    x = (x * x) % 10;
    n >>= 1;
  }
  return ret;
}
int main()
{
  int T, n;
  scanf("%d", &T);
  while(T--)
  {
    scanf("%d", &n);
    printf("%d\n", mypow(n % 10, n));
  }
  return 0;
}
