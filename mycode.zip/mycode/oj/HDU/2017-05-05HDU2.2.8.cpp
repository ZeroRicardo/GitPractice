#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;
int fact[100000];

int main()
{
  int N;

  while(scanf("%d", &N) != EOF){
    if(N == 0)
      printf("0\n");
    else{
      memset(fact, 0, sizeof(fact));
      fact[0] = 1;
      int tmp = 1, re, high = 1;
      for(int i = 1; i<= N; i++)
      {
        num = i;
        re = 0;
        while(num != 0)
        {
          tmp = num % 10;
          num /= 10;
          fact[j++] *
         }
    }
  }
  return 0;
}
