#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define long long ll
#define maxn 1
using namespace std;
int list[32];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  list[0] = 3;
  for(int i = 1; i <= 30; i++)
  {
    list[i] = (list[i - 1] - 1) * 2;
  }
  int n;
  scanf("%d", &n);
  while(n--){
    int a;
    scanf("%d", &a);
    printf("%d\n", list[a]);
  }
  return 0;
}
