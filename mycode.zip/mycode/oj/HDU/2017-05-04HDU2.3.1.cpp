#include<stdio.h>
#include<string.h>

int main(){
    int t,i,j,A[1050],B[1050],C[1050];
    char a[1050],b[1050];

    while(scanf("%d",&t)!=EOF){

        for(i=1;i<=t;i++){
            scanf("%s%s",a,b);
            printf("Case %d:\n%s + %s = ",i,a,b);
            memset(A,0,sizeof(A));
            memset(B,0,sizeof(B));
            memset(C,0,sizeof(C));

            for(j=1,A[0]=strlen(a);j<=A[0];j++){
                A[j]=a[A[0]-j]-'0';
            }

            for(j=1,B[0]=strlen(b);j<=B[0];j++){
                B[j]=b[B[0]-j]-'0';
            }

            for(j=1,C[0]=A[0]>B[0]?A[0]:B[0];j<=C[0];j++){
                C[j]+=A[j]+B[j];
                C[j+1]+=C[j]/10;
                C[j]%=10;

                if(C[C[0]+1]!=0){
                    C[0]++;
                }

            }

            for(j=C[0];j>=1;j--){
                printf("%d",C[j]);
            }

            printf("\n");

            if(i!=t){
                printf("\n");
            }

        }

    }

    return 0;
}
