#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define long long ll
#define maxn 1
using namespace std;
char password[52];
char sc[] = "~!@#$%^";
bool spe(char c){
  for(int i = 0; sc[i]; i++){
    if(c == sc[i])
      return 1;
  }
  return 0;
}
bool judge(){
  int len = strlen(password);
  if(len < 8 || len > 16)
    return 0;
  int flag[4], cnt = 0;
  memset(flag, 0, sizeof(flag));
  for(int i = 0; i < len; i++){
    if(password[i] >= 'a' && password[i] <= 'z')
      {
        if(flag[0] == 0)
        {
          cnt++;
          flag[0] = 1;
        }
      }
    else if(password[i] >= 'A' && password[i] <= 'Z')
      {
        if(flag[1] == 0)
        cnt++;
        flag[1] = 1;

      }
    else if(password[i] >= '0' && password[i] <= '9')
      {
        if(flag[2] == 0)
        cnt++;
        flag[2] = 1;

      }
    else if(spe(password[i]))
    {
      if(flag[3] == 0)
      cnt++;
      flag[3] = 1;

    }
    if(cnt >= 3)
      return 1;

  }
  return 0;
}
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int M;
  scanf("%d", &M);
  while(M--){
    scanf("%s", password);
    if(judge()) printf("YES\n");
    else printf("NO\n");
  }
  return 0;

}
