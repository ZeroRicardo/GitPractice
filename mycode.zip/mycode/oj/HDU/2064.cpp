#include <bits/stdc++.h>
using namespace std;
long long dp[36];
int main()
{
  dp[0] = 0;
  for(int i = 1; i <= 35; i++)
  {
    dp[i] = 3 * dp[i - 1] + 2;
//    cout << dp[i] << endl;

  }
  int n;
  while(cin >> n)
  {
    cout << dp[n] << endl;
  }
  return 0;
}
