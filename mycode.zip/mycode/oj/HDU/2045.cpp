#include <bits/stdc++.h>
using namespace std;
int main()
{
  long long dp[52];
  dp[0] = 0, dp[1] = 3, dp[2] = 6, dp[3] = 6;
  for(int i = 4; i <= 50; i++)
    dp[i] = 2 * dp[i - 2] + dp[i - 1];
  int n;
  while(~scanf("%d", &n))
    printf("%lld\n", dp[n]);
  return 0;
}
