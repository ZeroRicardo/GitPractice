#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;
int a[110], b[110];
void swap(int *a, int *b){
  int t = *a;
  *a = *b;
  *b = t;
}
int main()
{
  int n, m, num;
  while(scanf("%d%d", &n, &m) != EOF){
    if(n == 0 && m == 0)
      break;
    num = n;
    for(int i = 0; i < n; i++)
      scanf("%d", &a[i]);
    for(int i = 0; i < m; i++)
      scanf("%d", &b[i]);
    for(int i = 0; i < m; i++)
      for(int j = 0; j < num; j++)
      {
        if(b[i] == a[j])
          {
            swap(&a[j], &a[num - 1]);
            num--;
          }

      }
    if(num == 0)
      printf("NULL\n");
    else
    {
      sort(a, a + num);

      for(int i = 0; i < num ; i++){
        //if(i == 0)  printf("%d", a[i]);
        //else
        printf("%d ", a[i]);
      }printf("\n");
    }
  }
  return 0;
}
