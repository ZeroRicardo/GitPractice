#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
using namespace std;
int a[100010];
int main()
{
  int T, n;
  scanf("%d", &T);

    int ct;
    for(ct = 1; ct <= T; ct++)
    {
      scanf("%d", &n);
      int tmp = 0, ans = -99999, st = 1, ed = 1, stm = 1, edm = 1;
      for(int i = 0; i < n; i++)
      {
        scanf("%d", &a[i]);
      }
      for(int i = 0; i < n; i++)
      {
          if(tmp <= 0)
          {
            tmp = a[i];
            st = i + 1;
            ed = i + 1;
          }
          else
          {
            tmp += a[i];
            ed++;
          }
          if(ans < tmp)
          {
            ans = tmp;
            stm = st;
            edm = ed;
          }
      }
      printf("Case %d:\n", ct);
      printf("%d %d %d\n", ans, stm, edm);
      if(ct != T)
        printf("\n");
    }

}
