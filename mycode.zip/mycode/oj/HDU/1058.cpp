#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll dp[6000];
int main()
{
  dp[1] = 1;
  int i, j, k, l;
  i = j = k = l = 1;
  for(int cnt = 2; cnt <= 6000; cnt++)
  {
    dp[cnt] = min(dp[i] * 2, min(dp[j] * 3, min(dp[k] * 5, dp[l] * 7)));
    if(dp[cnt] == dp[i] * 2)
      i++;
    if(dp[cnt] == dp[j] * 3)
      j++;
    if(dp[cnt] == dp[k] * 5)
      k++;
    if(dp[cnt] == dp[l] * 7)
      l++;
  }
  int n;
  while(~scanf("%d", &n) && n)
  {
    if(n % 10 >= 1 && n % 10 <= 3 && !(n % 100 >= 11 && n % 100 <= 13))
    {
      printf("The %d", n);
      switch(n % 10)
      {
        case 1:printf("st"); break;
        case 2:printf("nd"); break;
        case 3:printf("rd"); break;
      }
      printf(" humble number is ");
    }
    else
      printf("The %dth humble number is ", n);
    printf("%lld.\n", dp[n]);
  }
}
