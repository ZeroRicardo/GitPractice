#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

int main()
{
  int n, ch[110], ja[110], score1, score2;
  while(scanf("%d", &n) != EOF)
  {
    if(n == 0)
      break;
    for(int i = 0; i < n; i++)
      scanf("%d", &ch[i]);
    for(int i = 0; i < n; i++)
      scanf("%d", &ja[i]);
    sort(ch, ch + n);
    sort(ja, ja + n);
    score1 = score2 = 0;
    for(int i = 0; i < n; i++)
    {
      if(ch[i] > ja[i])
        score1 += 2;
      else if(ch[i] < ja[i])
        score2 += 2;
      else
      {
        score1++, score2++;
      }
    }
    printf("%d vs %d\n", score1, score2);
  }
}
