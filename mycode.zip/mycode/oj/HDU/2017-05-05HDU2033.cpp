#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>

using namespace std;

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int ah, am, as, bh, bm, bs, ch, cm, cs;
    scanf("%d%d%d%d%d%d", &ah, &am, &as, &bh, &bm, &bs);
    cs = as + bs;
    cm = bm + am + cs / 60 ;
    ch = cm / 60 + ah + bh;
    cm %= 60;
    cs %= 60;
    printf("%d %d %d\n", ch, cm, cs);
  }
}
