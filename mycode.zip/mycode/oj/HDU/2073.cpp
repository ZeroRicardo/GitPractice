#include <bits/stdc++.h>
using namespace std;
double dp[510][510];
int main()
{
  dp[0][0] = 0;
  int x = 0, y = 0;
  int nx, ny;
  while(x <= 200 && y <= 200)
  {
  //  cout << x << " " << y << endl;
    if(y == 0)
    {
      ny = x + 1;
      nx = 0;
    }
    else
    {
      nx = x + 1;
      ny = y - 1;
    }
    dp[nx][ny] = dp[x][y] + sqrt((nx - x) * (nx - x) + (ny - y) * (ny - y));
    x = nx, y = ny;
  }
  int N;
  scanf("%d", &N);
  for(int i = 1; i <= N; i++)
  {
    int x1, x2, y1, y2;
    scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
    printf("%.3f\n", fabs(dp[x1][y1] - dp[x2][y2]));
  }
  return 0;
}
