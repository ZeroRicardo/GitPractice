#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
using namespace std;
#define maxn 32768
 // 欧拉函数
int eular(int n){
  int cnt = n;
    for(int i = 2;i <= n;i++)
      if(n % i == 0)
        {
          cnt -= cnt/i;
          while(n % i == 0)
            n /= i;
        }
  return cnt;
}

int main(){

  int T;
  scanf("%d", &T);
  while(T--){
    int n;
    scanf("%d", &n);
    printf("%d\n", eular(n));
  }
  return 0;
}
