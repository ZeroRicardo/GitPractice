//dp, O(n * V);
#include <bits/stdc++.h>
using namespace std;
int a[22];
int dp[310];
int main()
{
  for(int i = 1; i <= 17; i++)
    a[i] = i * i;
  int V;
  while(cin >> V)
  {
    if(V == 0) break;
    memset(dp, 0, sizeof dp);
    dp[0] = 1;
    for(int i = 1; i <= 17; i++)
      for(int j = a[i]; j <= V; j++)
        dp[j] += dp[j - a[i]];
    cout << dp[V] << endl;
  }
}
