#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define long long ll
#define maxn 1
using namespace std;

int dp[50];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int N;
  scanf("%d", &N);
  while(N--){
    int m;
    scanf("%d", &m);
    dp[1] = 1, dp[2] = 1;
    for(int i = 3; i <= m; i++)
      dp[i] = dp[i - 1] + dp[i - 2];
    if(m == 1)
      printf("0\n");
    else
      printf("%d\n", dp[m]);
  }
  return 0;

}
