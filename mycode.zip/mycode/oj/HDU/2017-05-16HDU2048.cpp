#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 1
using namespace std;

double dp[50];

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int T, n;
  dp[1] = 0;
  dp[2] = 0.5;
  for(int i = 3; i <= 20; i++)
  dp[i] = 1 - ((i - 1) * (1 - dp[i - 1]) + (1 - dp[i - 2])) / i;
  scanf("%d", &T);
  while(T--){
    scanf("%d", &n);

    printf("%.2f%%\n", dp[n] * 100);
  }
  return 0;
}
