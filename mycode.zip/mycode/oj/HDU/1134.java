public class HelloWorld{
  public static void main()
  {
    System.out.println("Hello Zero!");
  }
}
