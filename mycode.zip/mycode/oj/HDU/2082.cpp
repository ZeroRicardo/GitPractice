#include <bits/stdc++.h>
using namespace std;
int dp[100][100];
int a[28];
int main()
{
  ios::sync_with_stdio(false);
  int T;
  cin >> T;
  while(T--)
  {
    for(int i = 1; i <= 26; i++)
      cin >> a[i];
    memset(dp, 0, sizeof dp);
      dp[0][0] = 1;
    for(int i = 1; i <= 26; i++)
    {
      for(int k = 0; k <= a[i]; k++)
        for(int j = 50; j >= k * i; j--)
      {
          dp[i][j] += dp[i - 1][j - k * i];
      }
    }
    int ans = 0;
    for(int i = 1; i <= 50; i++)
      ans += dp[26][i];
    cout << ans << endl;
  }
  return 0;
}
