//unsolved;
#include <bits/stdc++.h>
using namespace std;
int getc(char c)
{
  if(c == 'x')  return 0;
  else  return c - '0';
}
set<int> vis;
char ans[370000];
int tot;
int mat[4][4];
int d[4] = {1, 3, -1, -3};
char op[6] = "rdlu";
int getmat()
{
  int ret = 1;
  for(int i = 1; i <= 3; i++)
    for(int j = 1; j <= 3; j++)
      ret = ret * 10 + mat[i][j];
  return ret;
}
bool flag = 0;
void dfs(int p, int dep)
while()  {
    printf("%d\n", getmat());
    if(!flag && getmat() == 123456780){
      tot = dep;
      flag = 1;
      return;
    }
    for(int i = 0; i < 4; i++)
    {
      if(p > 6 && d[i] == 3)  continue;
      if(p < 3 && d[i] == -3) continue;
      if(p % 3 == 1 && d[i] == -1)  continue;
      if(p % 3 == 0 && d[i] == 1) continue;
      int nep = p + d[i];
      swap(mat[(p - 1) / 3 + 1][(p - 1) % 3 + 1], mat[(nep - 1) / 3 + 1][(nep - 1) % 3 + 1]);
      int xxx = getmat();
      if(vis.find(xxx) == vis.end())
      {
        ans[dep] = op[i];
        vis.insert(xxx);
        dfs(nep, dep + 1);
        if(flag)  return;
      }
      swap(mat[(p - 1) / 3 + 1][(p - 1) % 3 + 1], mat[(nep - 1) / 3 + 1][(nep - 1) % 3 + 1]);
    }
  }
int main()
{
  char c;
  int x, pos;
  int num[10];
  while(~scanf(" %c", &c))
  {
    x = 0;
    if(c == 'x')  pos = 1;
    num[1] = getc(c);
    mat[1][1] = num[1];
    for(int i = 2; i <= 9; i++)
    {
      scanf(" %c", &c);
      if(c == 'x')  pos = i;
      num[i] = getc(c);
      mat[(i - 1) / 3 + 1][(i - 1) % 3 + 1] = num[i];
    }
    bool flag = 0;
    for(int i = 1; i <= 9; i++)
      for(int j = i + 1; j <= 9; j++)
        if(num[i] > num[j] && num[i] && num[j])
          flag = !flag;
    if(flag) printf("unsolvable\n");
    else{
      vis.clear();
      dfs(pos, 0);
      for(int i = 0; i < tot; i++)
        printf("%c", ans[i]);
      printf("\n");
    }
  }
}
