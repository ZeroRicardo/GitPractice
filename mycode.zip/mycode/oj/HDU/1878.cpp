#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 1010;
int deg[MAX_V];
int par[MAX_V], ran[MAX_V];
void init(int n)
{
  for(int i = 1; i <= n; i++)
  {
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x)
{
  if(x == par[x]) return x;
  else  return par[x] = find(par[x]);
}
void unite(int x, int y)
{
  x = find(x), y = find(y);
  if(x == y) return;
  if(ran[x] < ran[y])
    par[x] = y;
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
int main()
{
  int n, m;
  while(~scanf("%d", &n) && n)
  {
    scanf("%d", &m);
    memset(deg, 0, sizeof deg);
    init(n);
    for(int i = 1; i <= m; i++)
    {
      int u, v;
      scanf("%d%d", &u, &v);
      deg[v]++;
      deg[u]++;
      unite(v, u);
    }
    bool flag = 1;
    int root = find(1);
    for(int i = 1; i <= n; i++)
      if(deg[i] % 2 || find(i) != root)
        flag = 0;
    if(flag)  printf("1\n");
    else  printf("0\n");
  }
  return 0;
}
