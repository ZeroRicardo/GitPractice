#include <bits/stdc++.h>
using namespace std;
#define ll long long
set<ll> s;
set<ll>::iterator ite;
priority_queue<ll> q;
bool isprime(int x)
{
  if(x == 1 || x == 0)  return 0;
  for(int i = 2; i * i <= x; i++)
    if(x % i == 0)  return 0;
  return 1;
}
int main()
{
  ios::sync_with_stdio(false);
  ll p1, p2, p3, tp;
  int x;
  while(cin >> p1 >> p2 >> p3 >> x)
  {
    s.clear();
    while(!q.empty()) q.pop();
    s.insert(1);
    q.push(-1);
    ite = s.begin();
    int i = 1;
    while(1)
    {
      tp = q.top(); q.pop();
      if(i == x + 1)
        {
          cout << -tp << endl;
          break;
        }
      if(!s.count(-tp * p1))
      {
        s.insert(-tp * p1);
        q.push(tp * p1);
      }
      if(!s.count(-tp * p2))
      {
        s.insert(-tp * p2);
        q.push(tp * p2);
      }
      if(!s.count(-tp * p3))
      {
        s.insert(-tp * p3);
        q.push(tp * p3);
      }
      i++;
    }
  }
  return 0;
}
