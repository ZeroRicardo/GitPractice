#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 1
using namespace std;

int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  int m, n;
  while(scanf("%d%d", &m, &n) != EOF){
    for(int i = 1; i <= n + 2; i++)
    {
      if(i == 1 || i == n + 2)
      {
        printf("+");
        for(int j = 1; j <= m; j++)
          printf("-");
        printf("+");
        printf("\n");
      }
      else
      {
        printf("|");
        for(int j = 1; j <= m; j++)
          printf(" ");
        printf("|");
        printf("\n");
      }
    }
    printf("\n");
  }
  return 0;
}
