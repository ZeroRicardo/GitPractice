#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
int main(){
  int n;
  priority_queue<int> q;
  priority_queue<int, vector<int>, greater<int> > p;
  while(scanf("%d", &n) == 1)
  {
    int i, t;
    for(i = 0; i < n; i++)
    {
      scanf("%d", &t);
      p.push(t), q.push(t);
    }
    for(i = 0; i < n; i++)
    {
      if(i == 0)
      {
        printf("%d", q.top());
        q.pop();
      }
      else if(i % 2 == 0)
      {
        printf(" %d", q.top());
        q.pop();
      }
      else
      {
        printf(" %d", p.top());
        p.pop();
      }
    }
    printf("\n");
    while(p.size()) p.pop();
    while(q.size()) q.pop();
  }
  return 0;
}
