#include <bits/stdc++.h>
using namespace std;
int dp[110][10010];
int V;
int a[1010], ans[10010];
void Print(int i)
{
  cout << "dp[" << i << "]:" << endl;
    for(int j = 1; j <= V; j++)
      cout << dp[i][j] << " ";
    cout << endl;
}
int main()
{
  int n;
  while(cin >> n)
  {
    V = 0;
    for(int i = 1; i <= n; i++)
    {
      cin >> a[i];
      V += a[i];
    }

    memset(dp, 0, sizeof dp);
    dp[0][0] = 1;
    for(int i = 1; i <= n; i++)
    {
      for(int j = 0; j <= V; j++)
      {
      //  cout << i << " " << j << " " << j + a[i] << endl;
        dp[i][j + a[i]] = max(dp[i][j + a[i]], dp[i - 1][j]);
        dp[i][abs(j - a[i])] = max(dp[i][abs(j - a[i])], dp[i - 1][j]);
        dp[i][j] = max(dp[i][j], dp[i - 1][j]);
      }
    //  Print(i);
    }
    int tot = 0;
    for(int i = 1; i <= V; i++)
    {
      if(!dp[n][i])
        ans[tot++] = i;
    }
    cout << tot << endl;
    bool first = 1;
      for(int i = 0; i < tot; i++)
      {
        if(first) first = 0;
        else  cout << " ";
        cout << ans[i];
      }
    if(tot)
      cout << endl;
  }
}
