#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
  int t;
  cin >> t;
  while(t--){
    int res, ps, os;
    cin >> res >> ps >> os;
    if(res == 0);
    else if(res <= 6)
    {
      for(int m = 7, i = 1; i <= res; i++,m--)
        ps += m;
    }
    else if(res)
    {
        ps += (res - 6) * 8;
        ps += 7 + 6 + 5 + 4 + 3 + 2 ;
    }

    if(ps >= os)
      cout << "Yes" << endl;
    else
    cout << "No" << endl;
  }
}
