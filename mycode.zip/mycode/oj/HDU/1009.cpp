#include <bits/stdc++.h>
using namespace std;
struct node{
  double j, f;
  double val;
  node(){}
  node(double _j, double _f):j(_j), f(_f){val = j / f;}
  bool operator < (const node &y)const{
    return val > y.val;
  }
}x[1010];
int main()
{
  int m, n;
  while(~scanf("%d%d", &m, &n))
  {
    if(m == -1 && n == -1)  break;
    for(int i = 1; i <= n; i++)
    {
      double F, J;
      scanf("%lf%lf", &J, &F);
      x[i] = node(J, F);
    }
    sort(x + 1, x + 1 + n);
    double ans = 0;
    int pos = 1;
    while(m && pos <= n)
    {
      if(m > x[pos].f)
      {
        m -= x[pos].f;
        ans += x[pos].j;
      }
      else
      {
        ans += m * x[pos].val;
        m = 0;
      }
      pos++;
    }
    printf("%.3f\n", ans);
  }
}
