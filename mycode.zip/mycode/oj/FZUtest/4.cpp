  #include <stdio.h>
  #include <string.h>
  #include <vector>

  using namespace std;
  #define maxn 100000
  #define MOD 100000007
  char strA[maxn + 10], strB[maxn + 10], strC[maxn + 10];
  int lenA, lenB;
  unsigned long long hashA[maxn], hashB, hashC;
  void cal()
  {
    memset(hashA, 0, sizeof(hashA));
    hashB = hashC = 0;
    for(int i = 0; i < lenB; i++){
      hashB = hashB * MOD + strB[i];
      hashC = hashC * MOD + strC[i];
    }
    for(int i = 0; i <= lenA - lenB; i++)
    {
      for(int j = 0; j < lenB; j++)
        hashA[i] = hashA[i] * MOD + strA[i + j];
    }

  }
  bool find_substring(char *pattern, char *text){
    int n = lenA;
    vector<int> next(n + 1, 0);
    for(int i = 1; i < n; ++i){
      int j = i;
      while(j > 0){
        j = next[j];
        if(pattern[j] == pattern[i]){
          next[i + 1] = j + 1;
          break;
        }
      }
    }
    int m = lenB;
    for(int i = 0, j = 0; i < m; i++){
      if(j < n && text[i] == pattern[j]){
        j++;
    } else {
      while(j > 0){
        j = next[j];
        if(text[i] == pattern[j]){
          j++;
          break;
        }
      }
    }
    if(j == n){
      return 1;
      }
    }
    return 0;
  }
  int main()
  {
    int T;
    scanf("%d", &T);
    while(T--){
      scanf(" %s %s", strA, strB);
      lenB = strlen(strB), lenA = strlen(strA);
      for(int i = 0, j = lenB - 1; j >= 0; i++, j--)
      {
        strC[i] = strB[j];
      }
      strC[lenB] = 0;
      bool flag = 0;
      if(lenA >= lenB){

        if(lenB != 1)
        {
          if(find_substring(strA, strB) || find_substring(strA, strC))
          {
            flag = 1;
          }
        }
        else
        {
          if(strB[0] == '0'){
            flag = 1;
          }
          else
          for(int i = 0; i < lenA; i++)
          {
            if(strA[i] == strB[0])
            {
              flag = 1;
              break;
            }
          }
        }
      }
        if(flag)  printf("Alice\n");
        else printf("Bob\n");
      }
    return 0;
  }
