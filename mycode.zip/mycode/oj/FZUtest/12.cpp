#include <stdio.h>
#include <vector>

using namespace std;
char mat[5][5], em[5][5];
vector<pair<int, int> > v;
char kim;
bool check(){
  int kim_cnt = 0, dot_cnt = 0, cnt2 = 0;
  for(int i = 0; i < 3; i++){
    kim_cnt = dot_cnt = 0;
    for(int j = 0; j < 3; j++)
    {
      if(mat[i][j] == kim)
        kim_cnt++;
      if(mat[i][j] == '.')
        dot_cnt++;
    }
    if(kim_cnt == 3)  return 1;
    else  if(kim_cnt == 2 && dot_cnt == 1)
      cnt2++;
  }

  for(int i = 0; i < 3; i++){
    kim_cnt = dot_cnt = 0;
    for(int j = 0; j < 3; j++)
    {
      if(mat[j][i] == kim)
        kim_cnt++;
      if(mat[i][j] == '.')
        dot_cnt++;
    }
    if(kim_cnt == 3)  return 1;
    else  if(kim_cnt == 2 && dot_cnt == 1)
      cnt2++;
  }

  kim_cnt = dot_cnt = 0;
  for(int i = 0; i < 3; i++){
    if(mat[i][i] == kim)
      kim_cnt++;
    if(mat[i][i] == '.')
      dot_cnt++;
  }
  if(kim_cnt == 3)  return 1;
  else  if(kim_cnt == 2 && dot_cnt == 1)
    cnt2++;
    kim_cnt = dot_cnt = 0;
    for(int i = 0; i < 3; i++){
      if(mat[i][2 - i] == kim)
        kim_cnt++;
      if(mat[i][2 - i] == '.')
        dot_cnt++;
    }
    if(kim_cnt == 3)  return 1;
    else  if(kim_cnt == 2 && dot_cnt == 1)
      cnt2++;

    if(cnt2 >= 2) return 1;
    else  return 0;
}
bool solve(){
  v.clear();
  for(int i = 0; i < 3; i++)
    for(int j = 0; j < 3; j++)
      if(mat[i][j] == '.')  v.push_back(make_pair(i, j));
  mat[v[0].first][v[0].second] = kim;
  /*for(int i = 0; i < 3; i++){
    for(int j = 0; j < 3; j++)
      printf("%c", mat[i][j]);
    printf("\n");
  }*/
  if(check()) return 1;
  else{
    for(int i = 1; i < v.size(); i++)
    {
      mat[v[i - 1].first][v[i - 1].second] = '.';
      mat[v[i].first][v[i].second] = kim;
    /*for(int i = 0; i < 3; i++){
         for(int j = 0; j < 3; j++)
           printf("%c", mat[i][j]);
         printf("\n");
       }*/
      if(check()) return 1;
    }
  }
  return 0;

}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    for(int i = 0; i < 3; i++)
      for(int j = 0; j < 3; j++)
        scanf(" %c", &mat[i][j]);

        /*for(int i = 0; i < 3; i++){
           for(int j = 0; j < 3; j++)
             printf("%c", mat[i][j]);
           printf("\n");
         }*/
    scanf(" %c", &kim);
    if(solve()) printf("Kim win!\n");
    else  printf("Cannot win!\n");
  }
}
