#include <stdio.h>

using namespace std;

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int n, m, x, y;
    scanf("%d%d", &n, &m);
    x = (m - 2 * n) / 2, y = (4 * n - m) / 2;
    printf("%d %d\n", x, y);
  }
  return 0;
}
