#include <stdio.h>
#include <string.h>

using namespace std;
#define maxn 10000
#define maxk 100
#define MOD 1000000007
long long F[maxn + 10][maxk + 10];
long long CC(int n,int k)
{
	double ans=1;
	for(int i=1;i<=k;i++)
	{
		ans*=(double)(n--)/i;
	}
	for(int i=1;n>0;i++)
	{
		ans*=(double)(n--)/i;
	}
	return (long long)(ans+0.5);
}
long long A(int n){
  long long ret = 1;
  for(int i = 1; i < n; i++)
    ret  = (ret * i) % MOD;
}
int main()
{
  memset(F, 0, sizeof(F));
  for(int i = 1; i <= maxn; i++)
  {
    F[i][0] = 1;
    for(int j = 1; j <= i && j <= maxk; j++)
    {
      F[i][j] = ((CC(i, j) % MOD) * ((A(j)  + MOD - 1))) % MOD;
    }
//    for(int j = 1; j <= i && j <= maxk; j++)
    {
    //  F[i][j] = (F[i][j] + F[i][j - 1]) % MOD;
    //  printf("%lld ", F[i][j]);
    }
  //  printf("\n");
  }
  int T, n, k;
  scanf("%d", &T);
  while(T--){
    scanf("%d%d", &n, &k);
    printf("%lld\n", F[n][k]);
  }
}
