#include <stdio.h>

using namespace std;

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int x1, x2, x3, x4, x5, x6, y1, y2, y3, y4, y5, y6;
    scanf("%d%d%d%d%d%d", &x1, &y1, &x2, &y2, &x3, &y3, &x4, &y4, &x5, &y5, &x6, &y6);
    if()

  }
}
