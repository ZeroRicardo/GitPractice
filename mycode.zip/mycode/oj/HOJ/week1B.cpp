#include <bits/stdc++.h>

using namespace std;
#define maxn 100000

int main()
{
  int a[maxn + 10], b[maxn + 10];
  int n, m, t, sum = 0;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
  {
    scanf("%d", &t);
    sum += t;
    a[i] = sum;
  }
  scanf("%d", &m);
  for(int i = 0; i < m; i++)
  {
    scanf("%d", &b[i]);
  }
  for(int i = 0; i < m; i++)
  {
    printf("%d\n", lower_bound(a, a + n, b[i]) - a + 1);
  }
  return 0;
}
