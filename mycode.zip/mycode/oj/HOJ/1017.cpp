#include <bits/stdc++.h>

using namespace std;
const int V=1001;
struct Edge
{
    int next,to;
} edge[V*V];
int cnt,idx;
int cut[V],N,head[V];
int low[V],dfn[V];
void init()
{
    cnt=0;
    idx=0;
    for(int i=1; i<=V; i++)
    {
        head[i]=-1;
        low[i]=0;
        dfn[i]=0;
        cut[i]=0;
    }
}
void addedge(int u,int v)
{
    edge[cnt].to=v;
    edge[cnt].next=head[u];
    head[u]=cnt++;
}
void tarjan(int u,int fa)
{
    low[u]=dfn[u]=(++idx);
    for(int k=head[u]; k!=-1; k=edge[k].next)
    {
        int v=edge[k].to;
        if(v==fa)  continue;
        if(dfn[v]!=0)
        {
            low[u]=min(dfn[v],low[u]);
            continue;
        }
        tarjan(v,u);
        low[u]=min(low[u],low[v]);
        if(low[v]>=dfn[u])  cut[u]++;//访问不到比U小的节点
    }
    if(fa!=0) cut[u]++;
}
int main()
{
  //freopen("1.txt", "r", stdin);
//  freopen("2.txt", "w", stdout);
  int u, v, cas = 1;
  while(1){
    N = 0;
    init();
    scanf("%d", &u);
    if(u == 0)  break;
    scanf("%d", &v);
    addedge(u, v);
    addedge(v, u);
    N = max(N, u);
    N = max(N, v);
    while(1)
    {
      scanf("%d", &u);
      if(u == 0)  break;
      scanf("%d", &v);
      addedge(u, v);
      addedge(v, u);
      N = max(v, N);
      N = max(u, N);
    }
    if(cas > 1)
      printf("\n");
    printf("Network #%d\n", cas);
    tarjan(1, 0);
    bool flag = 0;
    for(int i = 1; i <= N; i++)
      if(cut[i] > 1)
      {
        printf("  SPF node %d leaves %d subnets\n", i, cut[i]);
        flag = 1;
      }
    if(!flag)
      printf("  No SPF nodes\n");
    cas++;
  }
}
