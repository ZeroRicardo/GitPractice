#include <stdio.h>
#include <queue>
#include <algorithm>
#include <iostream>
#include <vector>
#include <string.h>
#include <math.h>
#include <set>
#include <stdlib.h>
#define maxn 100000000
using namespace std;
//int f[maxn + 10];
int main()
{
  //freopen("C:\\Users\\Master\\Desktop\\1\\test.txt", "r", stdin);
  long long a, b, c;
  scanf("%I64d", &a);
  if(a == 1 || a == 2)
    printf("-1\n");
  else{
    if(a & 1){
      b = (a * a - 1) / 2, c = (a * a + 1) / 2;
    }
    else{
      b = a * a / 4  - 1, c = a * a / 4 + 1;
    }
  printf("%I64d %I64d\n", b, c);
  }
}
