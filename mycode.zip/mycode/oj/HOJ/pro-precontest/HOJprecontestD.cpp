#include <stdio.h>
#include <iostream>

using namespace std;
#define maxn 3402
#define maxw 12880

int dp[maxw + 1];
int n, W;
int w[maxn], v[maxn];
void solve(){
  for(int i = 0; i < n; i++){
    for(int j = W; j >= w[i]; j--){
      dp[j] = max(dp[j], dp[j - w[i]] + v[i]);
    }
  }
  printf("%d\n", dp[W]);
}
int main()
{
  scanf("%d%d", &n, &W);
  for(int i = 0; i < n; i++)
    scanf("%d%d", &w[i], &v[i]);
  solve();
}
