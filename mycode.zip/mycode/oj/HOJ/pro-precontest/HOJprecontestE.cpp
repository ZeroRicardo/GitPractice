#include <bits/stdc++.h>

using namespace std;
bool mat[110][110];

int main()
{
  int n, m;

  while(1){
    scanf("%d%d", &n, &m);
    if(n == 0)
      break;
    memset(mat, 0, sizeof(mat));
    for(int i = 0; i < m; i++)
    {
      int x, y;
      scanf("%d%d", &x, &y);
      mat[x][y] = 1;
    }
    int flag = 1;
    for(int k = 0; k < n; k++)
      for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
          mat[i][j] = mat[i][j] || mat[i][k] && mat[k][j];
      for(int i = 0; i < n; i++)
        if(mat[i][i] == 1)
          {
            flag = 0;
            break;
          }
      if(flag)
        printf("YES\n");
      else
        printf("NO\n");
  }
}
