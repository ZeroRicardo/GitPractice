#include <bits/stdc++.h>

using namespace std;
#define maxn 10000
int res[maxn + 10];
int main()
{

  int m, n, j, flag;
  long long k;
  while(scanf("%d%d", &n, &m) != EOF)
  {
    memset(res, 0, sizeof(res));
    k = 0;
    j = 0;
    flag = 0;
    while(1)
    {
      k *= 10;
      k += n;
      j++;
      if(k % m == 0)
      {
          flag = 1;
          break;
      }
      else
      {
        res[k % m]++;
        if(res[k % m] > 1)
        {
          flag = 0;
          break;
        }
      }
    }
      if(flag)
        printf("%d\n", j);
      else
        printf("0\n");

  }

}
