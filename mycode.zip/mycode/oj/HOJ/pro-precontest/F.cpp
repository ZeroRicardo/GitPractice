#include <bits/stdc++.h>

using namespace std;
const int MOD = 1e9 + 7;
#define maxn 100000
int a[maxn + 10];
int l[maxn + 10], r[maxn + 10];
int vis[10000 + 10];
int pre[10000 + 10];
vector<int> head[10000 + 10];
int main()
{
  int n;
  long long ans = 0;
  for(int i = 1; i <= 10000; i++){
    head[i].clear();
    for(int j = 1; j * j <= i; j++){
      if(i % j == 0){
        head[i].push_back(j);
        head[i].push_back(i / j);
      }
    }
  }
  while(~scanf("%d", &n)){
    for(int i = 0; i < n; i++)
      scanf("%d", &a[i]);
    memset(pre, -1, sizeof(pre));
    for(int i = 0; i < n; i++){
      int num = a[i];
      int pos = -1;
      for(int j = 0; j < head[num].size(); j++)
        pos = max(pos, pre[head[num][j]]);
      l[i] = pos;
      pre[num] = i;
    }
    fill(pre, pre + n, n);
    for(int i = n - 1; i >= 0; i--){
      int num = a[i];
      int pos = n;
      for(int j = 0; j < head[num].size(); j++)
        pos = min(pos, pre[head[num][j]]);
      r[i] = pos;
      pre[num] = i;
    }

    ans = 0;
    for(int i = 0; i < n; i++){
    //  printf("%d %d\n", l[i], r[i]);
      ans += (i - l[i]) * (r[i] - i) %MOD;
    //  printf("%lld\n", ans);
    }
    printf("%lld\n", ans % MOD);
  }
  return 0;
}
