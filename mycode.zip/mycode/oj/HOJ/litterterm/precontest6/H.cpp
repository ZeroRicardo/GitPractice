#include <bits/stdc++.h>

using namespace std;
int ans = -1;
int main()
{
  int n, t;
  scanf("%d", &n);
  for(int i = 0; i < n; i++){
    scanf("%d", &t);
    ans =  max(ans, t);
  }
  ans++;
  bool flag = 1;
  while(ans > 2){
    if(ans % 2) flag = 0;
    ans = ans / 2;
  }
  if(flag)  printf("Mike\n");
  else  printf("Constantine\n");
}
