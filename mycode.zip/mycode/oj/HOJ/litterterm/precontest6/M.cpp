#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
int c[maxn + 10], dp[maxn + 10];
int pos[maxn + 10], cnt[maxn + 10];
int main()
{
  int n;
  scanf("%d", &n);
  memset(pos, -1, sizeof(pos));
  memset(cnt, -1, sizeof(cnt));
  for(int i = 1; i <= n; i++)
  {
    dp[i] = maxn * 10;
    scanf("%d", &c[i]);
    if(cnt[c[i]] != -1) pos[i] = cnt[c[i]];
    cnt[c[i]] = i;
  }
  dp[1] = 0;
  for(int i = 2; i <= n; i++)
  {
      if(pos[i] != -1)
      dp[i] = dp[pos[i]] + 1;
    dp[i] = min (dp[i], dp[i - 1] + 1);

  }
  printf("%d\n", dp[n]);
  return 0;
}
