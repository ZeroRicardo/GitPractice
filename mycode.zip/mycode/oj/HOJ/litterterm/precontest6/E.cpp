#include <bits/stdc++.h>

using namespace std;

int main()
{
  int p, q;
  double pro;
  scanf("%d%d", &p, &q);
  pro = (double)(p * p + q * q) / 100 / (p + q);
  printf("%f\n", pro);
  return 0;
}
