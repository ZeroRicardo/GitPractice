#include <bits/stdc++.h>

using namespace std;
#define maxn  1000000
int a[maxn + 10];
int main(){
  memset(a, 0, sizeof(a));
  a[1] = 1;
  for(int i = 1; i <= maxn; i++)
    for(int j = 2; i * j <= maxn; j++)
    {
      a[i * j] += a[i];
    }

  int k;
  scanf("%d", &k);
  printf("%d\n", a[k]);

  return 0;
}
