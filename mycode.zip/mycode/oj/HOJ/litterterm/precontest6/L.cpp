#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
long long a[maxn + 10];
long long s[maxn + 10];
int main()
{
  int n;
  scanf("%d", &n);
  scanf("%lld", &s[0]);
  a[0] = s[0];
  for(int i = 1; i < n; i++){
    scanf("%lld", &s[i]);
    a[i] = s[i] - s[i - 1];
  }
  for(int i = 0; i < n; i++)
    printf("%lld ", a[i]);
  printf("\n");
  return 0;
}
