#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
char str[maxn + 10];
int pos[28];
int main()
{
  scanf("%s", str);
  int len = strlen(str);
  if(len > 26)  printf("IMPOSSIBLE\n");
  else{
    memset(pos, -1, sizeof(pos));
    for(int i = 0; i < len; i++){
      if(pos[str[i] - 'a'] == -1)  pos[str[i] - 'a'] = i;
    }

    for(int i = 0; i < len; i++){
      if(pos[str[i] - 'a'] != -1 && pos[str[i] - 'a'] != i){
        for(int j = 0; j < 26; j++){
          if(pos[j] == -1){
            str[i] = 'a' + j;
            pos[j] = i;
            break;
          }
        }
      }
    }
    puts(str);
  }
}
