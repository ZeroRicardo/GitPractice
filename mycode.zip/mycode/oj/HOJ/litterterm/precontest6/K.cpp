#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
char str[maxn * 2 + 10];
int main()
{
  scanf(" %s", str);
  int cnt1, cnt2;
  int len = strlen(str);
  cnt1 = cnt2 = 0;
  bool flag = 1;
  for(int i = 0;i < len; i++){
    if(str[i] == '(') cnt1++;
    else  cnt2++;
    if(cnt2 > cnt1) flag = 0;
  }
  if(!flag) printf("IMPOSSIBLE\n");
  else{

    for(int i = 0; i < cnt1 - cnt2; i++)
      str[len + i] = ')';
    str[len + cnt1 - cnt2] = 0;
  puts(str);
  }
  return 0;
}
