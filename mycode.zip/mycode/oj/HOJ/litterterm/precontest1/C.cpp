#include <bits/stdc++.h>

using namespace std;
int n, m;
char mat[52][52];
char cmd[52];
int rx, ry, ex, ey;
struct cp{
  int x, y, time, cnt;
};
queue< cp> que;
int main()
{
  scanf("%d%d", &n, &m);
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= m; j++)
    {
      scanf(" %c", &mat[i][j]);
      if(mat[i][j] == 'R')
      {
        rx = i, ry = j;
      }
      if(mat[i][j] == 'E')
      {
        ex = i, ey = j;
      }
    }
  scanf(" %s", cmd);
  cp t0;
  t0.x = rx, t0.y = ry, t0.time = 0, t0.cnt = 0;
  que.push(t0);
  while(!que.empty())
  {
    cp t0, t1;
    t0 = que.front();
    t1 = t0;
    que.pop();
    char op;
    op = 'L', t1.x = t0.x - 1, t1.time++, t1.cnt += (op != cmd[t0.time]);
    if(t1.x < 1 || mat[t1.x][t1.y] == '#')
      t1.x = t0.x;

  }
}
