#include <stdio.h>
char mat[52][52];

int main()
{

  int m, n;
  scanf("%d%d", &m, &n);
  for(int i = 0; i < m; i++)
    scanf(" %s", mat[i]);

  for(int i = 0; i < n; i++)
    for(int j = m - 1; j >= 0; j--)
    {
      if(mat[j][i] == 'o')
      {
        int k;
        for(k = j + 1; k < m; k++)
          if(mat[k][i] != '.')
            break;
        mat[j][i] = '.';
        mat[k - 1][i] = 'o';
    //    printf("%d\n", k);
      }
    }


  for(int i = 0; i < m; i++)
  printf("%s\n", mat[i]);
}
