#include <stdio.h>
#include <algorithm>
#include <string.h>

using namespace std;

int main()
{
  char s[100];
  int dp[100];
  scanf("%s", s);
  int len = strlen(s);
  for(int i = 0;i < len; i++)
    dp[i] = 1;
  for(int i = 1; i < len; i++)
  {
    for(int j = i - 1; j >= 0; j--)
    {
      if(s[i] > s[j])
        dp[i] = max(dp[i], dp[j] + 1);
    }
  }
  int maxs = 0;
  for(int i = 0; i < len; i++)
    maxs = max(maxs, dp[i]);
  printf("%d\n", 26 - maxs);
  return 0;
}
