#include <stdio.h>

int main()
{
  int die1[6], die2[6];
  for(int i = 0; i < 6; i++)
    scanf("%d", &die1[i]);
  for(int i = 0; i < 6; i++)
    scanf("%d", &die2[i]);
  int win = 0, sum = 0;
  for(int i = 0; i < 6; i++)
    for(int j = 0; j < 6; j++)
    {
      if(die1[i] != die2[j])
      {
        sum++;
        if(die1[i] > die2[j])
        {
          win++;
        }
      }
    }
  printf("%.5f\n", (double)win / sum);
}
