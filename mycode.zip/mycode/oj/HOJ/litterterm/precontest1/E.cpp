#include <bits/stdc++.h>

using namespace std;

int main()
{
  int n, k;
  long long time[400];
  priority_queue <int, vector<int>, greater<int> > q;
  scanf("%d%d", &n, &k);
  int cnt = 0, j = 1;
  time[0] = 0;
  for(int i = 0; i < n; i++)
  {
    int t;
    scanf("%d", &t);
    q.push(t);
    cnt++;
    if(cnt == k)
    {
      time[j] =time[j - 1] + q.top();
      j++;
      q.pop();
      cnt--;
    }
  }
  while(!q.empty())
  {
    time[j] =time[j - 1] + q.top();
    j++;
    q.pop();
  }
  long long sum = 0;
  for(int i = 1; i <= n; i++)
    sum += time[i];
  printf("%I64d\n", sum);
  return 0;
}
