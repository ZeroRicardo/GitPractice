#include <stdio.h>
char map[52][52];
int dx[4] = {0, 1, 0, -1}, dy[4] = {1, 0, -1, 0};
int m, n;
void dfs(int i, int j)
{
  if(map[i][j] == 'W')
    return;
  else
    map[i][j] = 'W';
  for(int k = 0; k  < 4; k++)
  {
    int x = i + dx[k], y = j + dy[k];
    if(0 <= x && x < m && 0 <= y && y < n)
      dfs(x, y);
  }
}
int main()
{

  scanf("%d%d", &m, &n);
  for(int i = 0; i < m; i++)
    scanf("%s", map[i]);
  int cnt = 0;
  for(int i = 0; i < m; i++)
    for(int j = 0; j < n; j++)
    {
      if(map[i][j] == 'L')
      {
        cnt++;
        dfs(i, j);
      }
    }
  printf("%d\n", cnt);
}
