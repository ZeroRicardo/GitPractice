#include <bits/stdc++.h>

using namespace std;
#define maxn 100000
bool p[maxn + 10];
int main()
{
  int n, k, r;

  scanf("%d%d%d", &n, &k, &r);
  memset(p, 0, sizeof(p));
  for(int i = 0; i < k; i++)
  {
    int t;
    scanf("%d", &t);
    p[t] = 1;
  }
  int st, ed, ans = 0;
  for(st = 1; st + r - 1 <= n; st++)
  {
    ed = st + r - 1;
    int cnt = 0;
    for(int j = st; j <= ed; j++)
      cnt += p[j];
    if(cnt < 2)
    {
      for(int j = ed; j >= st; j--)
      {
        if(!p[j])
        {
          p[j] = 1;
          cnt++;
          ans++;
        }
        if(cnt == 2)
          break;
      }
    }
  }
  printf("%d\n", ans);
  return 0;
}
