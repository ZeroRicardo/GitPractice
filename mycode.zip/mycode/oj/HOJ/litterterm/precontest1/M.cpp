#include <bits/stdc++.h>

using namespace std;
int a[52], dp[2][52];
int main()
{
  int n;
  scanf("%d", &n);
  for(int i = 0;i < n; i++)
  {
    scanf("%d", &a[i]);
    dp[0][i] = dp[1][i] = 1;
  }

  for(int i = 1; i < n; i++)
  {
    for(int j = i - 1; j >= 0; j--)
    {
      if(a[i] > a[j])
        dp[0][i] = max(dp[0][i], dp[1][j] + 1);
      else if(a[i] < a[j])
        dp[1][i] = max(dp[1][i], dp[0][j] + 1);
    }
  }
  int maxt = max(dp[0][n - 1], dp[1][n - 1]);
  printf("%d\n", maxt);
  return 0;
}
