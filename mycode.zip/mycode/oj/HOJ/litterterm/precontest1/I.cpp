#include <bits/stdc++.h>

using namespace std;
int main()
{
  int n;
  long long sum = 0, sumt = 0;
  priority_queue<int> q;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
  {
    int t;
    scanf("%d", &t);
    q.push(t);
    sumt += t;
  }
  if(q.top() > sumt / 2)
  {
  while(q.size() >= 2)
  {
    int a = q.top();
    q.pop();
    int b = q.top();
    q.pop();
    sum += min(a, b);
    if(a - b != 0)
    q.push(a > b ? a - b : b - a);
  }
  }
  else
    sum = sumt / 2;
  printf("%lld\n", sum);
}
