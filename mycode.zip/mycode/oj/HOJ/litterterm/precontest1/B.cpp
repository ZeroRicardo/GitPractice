#include <bits/stdc++.h>

using namespace std;

int n, m;
long long b[15], p[15];
long long sum[1000], cnt = 0;
set<long long> s;
set<long long> ans;
vector<long long> mp;
void dfs(int i,long long sum1, long long sum2)
{
  if(i == m){
    if(sum1 == sum2){
      set<long long>::iterator ite;;
      ite = s.find(sum1);
      if(ite == s.end()) s.insert(sum1);
    }
    return;
  }
  dfs(i + 1, sum1, sum2);
  dfs(i + 1, sum1 + p[i], sum2);
  dfs(i + 1, sum1, sum2 + p[i]);
}
int main()
{
  scanf("%d%d", &n, &m);
  for(int i = 0; i < n; i++)
    scanf("%lld", &b[i]);
  for(int i = 0; i < m; i++)
    scanf("%lld", &p[i]);
  dfs(0, 0, 0);
  set<long long>::iterator ite;;
  for(int i = 0; i < n; i++){
    for(ite = s.begin(); ite != s.end(); ite++){
      ans.insert(b[i] + *ite * 2);
    }
  }
  for(ite = ans.begin(); ite != ans.end(); ++ite){
    printf("%lld\n", *ite);
  }
}
