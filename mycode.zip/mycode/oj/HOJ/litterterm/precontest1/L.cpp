#include <bits/stdc++.h>

using namespace std;
int tmp[400];
int main()
{
  int a[3][2], flag = 0;
  for(int i = 0; i < 3; i++)
    for(int j = 0; j < 2; j++)
      scanf("%d", &a[i][j]);
  int area = 0;
  memset(tmp, 0, sizeof(tmp));
  for(int i = 0; i < 3; i++)
    area += a[i][0] * a[i][1];
    for(int i = 0; i < 3; i++)
      for(int j = 0; j < 2; j++)
      {
        tmp[a[i][j]]++;
      }
    for(int i = 0; i < 3; i++)
      for(int j = 0; j < 3; j++)
        for(int k = 0; k < 2; k++)
          for(int l = 0; l < 2; l++)
      {
        if(i != j)
        {
          tmp[a[i][k] + a[j][l]]++;
        }
      }
      for(int i = 0; i < 2; i++)
        for(int j = 0; j < 2; j++)
          for(int k = 0; k < 2; k++)
          {
            tmp[a[0][i] + a[1][j] + a[2][k]]++;
          }
  int edge = sqrt(area);
  if(edge * edge == area && tmp[edge] >= 4)
  {
    flag = 1;
  }
  if(flag)
    printf("YES\n");
  else
    printf("NO\n");
}
