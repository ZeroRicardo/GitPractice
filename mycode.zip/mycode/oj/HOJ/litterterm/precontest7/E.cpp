#include <bits/stdc++.h>

using namespace std;
int main()
{
  int T, n;
  int a[110];
  scanf("%d", &T);
  while(T--){
    scanf("%d", &n);
    int maxa = 0;
    for(int i = 0; i < n; i++){
      scanf("%d", &a[i]);
      maxa = max(maxa, a[i]);
    }
    int ans = 0;
    for(int i = 0; i < n; i++)
    {
      a[i] += 100 - maxa;
      if(a[i] >= 50)
        ans++;
    }
    printf("%d\n", ans);

  }
  return 0;
}
