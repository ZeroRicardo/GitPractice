#include <bits/stdc++.h>

using namespace std;

int main()
{
  int T, n;
  char str[1010];
  
  scanf("%d", &T);
  while(T--){
    scanf("%d", &n);
    scanf(" %s", str + 1);
    int l, r;
    int ans = 0;
    for(l = 1; l <= n + 1; l++){
      for(r = l; r <= n + 1; r++){
        int win = 0;
        for(int i = 1; i < l; i++)
        {
          if(str[i] == 'S')
            win++;
          else if(str[i] == 'P')
            win--;
        }
        for(int i = l; i < r; i++)
        {
          if(str[i] == 'R')
            win++;
          else if(str[i] == 'S')
            win--;
        }
        for(int i = r; i <= n; i++)
        {
          if(str[i] == 'P')
            win++;
          else if(str[i] == 'R')
            win--;
        }
        if(win > 0){
          ans++;
        }
      }
    }
    printf("%d\n", ans);
  }
}
