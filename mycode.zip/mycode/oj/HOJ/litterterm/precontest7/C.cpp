#include <bits/stdc++.h>

using namespace std;

int main()
{
    int T, n;
    char str[110];
    scanf("%d", &T);
    while(T--){
      scanf("%d", &n);
      scanf(" %s", str);
      int ans = 0;
    /*  for(int i = 0; i < n - 2; i++)
      {
        if(str[i] == '.' && str[i + 1] == '.')
        {
          str[i + 1] = '*';
          ans++;
        }
        if(str[i] == '*'){
          while(str[i] == '*' && i < n - 2) i++;
        //  i++;
        }
      }
      if(str[n - 2] == '.' && str[n - 1] == '.') ans++;*/
      for(int i = 0; i < n; i++){
        if(str[i] == '*'){
          if(i > 1) str[i - 1] = '*';
          if(i < n - 1 && str[i + 1] == '.'){
            str[i + 1] = '*';
            i++;
        }
      }
    }
      int cnt = 0;
      for(int i = 0; i < n; i++)
      {
        if(str[i] == '.') cnt++;
        else{
      //    printf("%d %d", i, cnt);
          ans += (cnt + 2) / 3;
          cnt = 0;
        }
      }
      ans += (cnt + 2) / 3;
      printf("%d\n", ans);
  //    printf("%s\n", str);
    }
    return 0;
}
