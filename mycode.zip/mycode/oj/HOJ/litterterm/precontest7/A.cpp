#include <bits/stdc++.h>

using namespace std;
struct Team{
  char name[30];
  int s, p;
}team[110];
bool cmp(struct Team a, struct Team b){
  return a.s == b.s ? a.p < b.p : a.s > b.s;
}
int main(){
  int T, n;
  scanf("%d", &T);
  while(T--){
    scanf("%d", &n);
    for(int i = 0;i < n; i++){
      scanf(" %s %d %d", team[i].name, &team[i].s, &team[i].p);
    }
    sort(team, team + n, cmp);
    printf("%s\n", team[0].name);
  }
  return 0;
}
