#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
struct sith{
  int a, b, c, d;
}num[maxn + 10];
bool win(struct sith x,struct sith y)
{
  return ((x.a > y.a) && (x.b > y.b)) || ((x.a > y.a) && (x.c > y.c)) || ((x.b > y.b) && (x.c > y.c));
}
int main()
{
  int n;
  scanf("%d", &n);
  int min1 = 0, min2 = 0, min3 = 0;
  for(int i = 0; i < n; i++)
  {
    scanf("%d%d%d", &num[i].a, &num[i].b, &num[i].c);
    num[i].d = i + 1;
    if(num[i].a < num[min1].a)  min1 = i;
    if(num[i].b < num[min2].b)  min2 = i;
    if(num[i].c < num[min3].c)  min3 = i;
  }
  sort(num, num + n, win);
  int flag = 1;
  for(int i = 0; i < n; i++)
  {
    if(win(num[n - 1], num[i]))
    {
      flag = 0;
      break;
    }
  }
  if(flag)
    printf("1\n%d\n", num[n - 1].d);
  else
    printf("0\n");

}
