#include <bits/stdc++.h>

using namespace std;
#define p 0.916297857297023
int main()
{
  int x1, x2, y1, y2;
  double dis;
  scanf("%d%d", &x1, &y1);
  scanf("%d%d", &x2, &y2);
  dis = sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
  printf("%f\n", dis * dis * p);
  return 0;
}
