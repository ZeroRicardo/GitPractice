#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
struct team{
  int l, r;
}am[maxn + 10];
bool cmp(struct team a, struct team b)
{
  return a.l > b.l;
}
int main()
{
  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
  {
    scanf("%d%d", &am[i].l, &am[i].r);
  }
  sort(am, am + n, cmp);
  int ans = 0;
  for(int i = 0; i < n; i++)
  {
//    printf("%d %d\n", am[i].l, am[i].r);
    if(am[i].r >= am[0].l)
      ans++;
  }
  printf("%d\n", ans);
  return 0;
}
