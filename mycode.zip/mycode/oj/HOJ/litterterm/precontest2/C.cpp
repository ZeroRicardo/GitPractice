#include <bits/stdc++.h>

using namespace std;
#define maxn 2000000
int t[maxn + 10];
int main(){
  int n;
  scanf("%d", &n);
  memset(t, -1, sizeof(t));
  for(int i = 0; i < n; i++)
  {
    long long sq = (long long) i * i;
    if(sq < n)
    t[sq] = i;
    else
      t[(sq) % n] = i;
  }
  for(int i = 0; i < n; i++)
    printf("%d ", t[i]);
  return 0;
}
