#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
int a[maxn + 10];
int main()
{
  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
    scanf("%d", &a[i]);
  long long ans = 0, maxp = 0, minp;
  int i;
  for(i = 1; i < n; i++)
  {
    if(a[maxp] <= a[i])
    {
      maxp = i;
    }
    else
      break;
  }
  ans += a[maxp];
  while(i < n)
  {
    minp = i;
    maxp = i;
    for(; i < n; i++)
    {
      if(a[maxp] <= a[i])
      {
        maxp = i;
      }
      else
        break;
    }
    ans += a[maxp] - a[minp];
  }
  printf("%lld\n", ans);
  return 0;

}
