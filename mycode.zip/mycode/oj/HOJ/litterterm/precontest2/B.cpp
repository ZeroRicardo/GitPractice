#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
struct fuck{
  int a, b;
}hi[maxn + 10];
bool cmp(fuck x, fuck y)
{
  return x.a - x.b == y.a - y.b ?x.b > y.b :x.a - x.b > y.a - y.b;
}
int main()
{
  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
  {
    scanf("%d%d", &hi[i].a, &hi[i].b);
  }
  sort(hi, hi + n, cmp);
  long long ans = 0, res = 0;
  for(int i = 0; i < n; i++)
  {
    if(res < hi[i].a)
    {
      ans += hi[i].a - res;
      res += hi[i].a - res;
    }
    res -= hi[i].b;
  }
  printf("%lld\n", ans);
  return 0;
}
