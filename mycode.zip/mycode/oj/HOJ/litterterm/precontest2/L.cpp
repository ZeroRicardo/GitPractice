#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
struct zorcs{
  int a, b, i, fet;
}z[maxn + 10];
struct axe{
  int w, c, i;
}a[maxn + 10];
int ans[maxn + 10];
int main()
{
  int n, m;
  scanf("%d%d", &n, &m);
  for(int i = 1; i <= n; i++){
    scanf("%d%d", &z[i].a, &z[i].b);
    z[i].i = i;
  }
  for(int i = 1; i <= m; i++)
  {
    scanf("%d%d", &a[i].w, &a[i].c);
    a[i].i = i;
  }
  sort(z + 1, z + 1 + n, cmp1);
  sort(a + 1, a + 1 + m, cmp2);
}
