#include <stdio.h>
#include <string.h>
#include <math.h>
#define maxn 500000 + 10
char str[maxn];
int main()
{
  scanf("%s", str);
  int len = strlen(str);
  int flag = 0;
  int cnt1 = 0, cnt2 = 0, cnt3 = 0;
  for(int i = 0;i < len; i++)
  {
    if(str[i] == '(')
      cnt1++;
    else if(str[i] == '?')
      cnt2++;
    else
      cnt3++;
  }
  if(cnt2 < fabs(cnt1 - cnt3) || len % 2)
    {
    //  printf("*");
      flag = 0;
    }
  else{
    for(int i = 0; i < len; i++)
    {
      if(str[i] == '?')
      {
        if(cnt1 < len / 2)
        {
          str[i] = '(';
          cnt1++;
        }
        else{
          str[i] =')';
          cnt3++;
        }
      }
    }
    int tmp = 0;
    flag = 1;
    for(int i = 0; i < len; i++)
    {
      if(str[i] == '(')
        tmp++;
      else
        tmp--;
      if(tmp < 0)
      {
      //  printf("%");
        flag = 0;
        break;
      }
    }
  }
//  printf("%s\n", str);
  if(flag)
    printf("%s\n", str);
  else
    printf("Impossible\n");
}
