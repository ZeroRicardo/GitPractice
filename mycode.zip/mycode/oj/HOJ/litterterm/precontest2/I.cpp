#include <bits/stdc++.h>

using namespace std;
#define maxn 200000
struct node{
  int sum;
  vector<int> edge;
}G[maxn + 10];
bool flag[maxn + 10];
int main()
{
  int n, m;
  scanf("%d%d", &n, &m);
  for(int i = 1; i <= n; i++)
    G[i].sum = 0;
  for(int i = 0; i < m; i++)
  {
    int s, t;
    scanf("%d%d", &s, &t);
    G[s].sum++, G[t].sum++;
    G[s].edge.push_back(t), G[t].edge.push_back(s);
  }

  int mint = 1;
  for(int i = 1; i <= n; i++)
  {
    flag[i] = 1;
    if(G[mint].sum > G[i].sum)
      mint = i;
  }
  flag[mint] = 0;
  for(int i = 0; i < G[mint].sum; i++)
    flag[G[mint].edge[i]] = 0;
  for(int i = 1; i <= n; i++)
    printf("%d ", flag[i]);
  return 0;
}
