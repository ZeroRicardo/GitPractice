#include <bits/stdc++.h>

using namespace std;

int main()
{
  int n, t, maxt = 0;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
  {
    scanf("%d", &t);
    maxt = max(maxt, t);
  }
  printf("%d\n", maxt);
  return 0;
}
