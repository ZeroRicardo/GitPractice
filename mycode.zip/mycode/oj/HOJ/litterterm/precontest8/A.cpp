#include <bits/stdc++.h>

using namespace std;

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int x, y;
    char op[3];
    bool flag;
    scanf("%d %s %d", &x, op, &y);
    if(op[0] == '!')  flag = (x != y);
    else if(op[0] == '=') flag = (x == y);
    else if(op[0] == '>'){
      if(strlen(op) == 2) flag = (x >= y);
      else flag = (x > y);
    }
    else if(op[0] == '<'){
      if(strlen(op) == 2) flag = (x <= y);
      else flag = (x < y);
    }
    if(flag)
      printf("true\n");
    else
      printf("false\n");
  }
  return 0;
}
