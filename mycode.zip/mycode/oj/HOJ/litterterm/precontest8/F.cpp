#include <bits/stdc++.h>

using namespace std;
#define maxn 50000
int par[maxn + 10];
int ran[maxn + 10];
bool vis[maxn + 10];
char str[50010];
void init(int n){
  for(int i = 1; i <= n; i++)
  {
    par[i] = i;
    ran[i] = 0;
  }
}
int find(int x){
  if(par[x] == x)
    return x;
  else{
    par[x] = find(par[x]);
    str[x] = str[par[x]];
    return par[x];
  }
}
void unite(int x, int y){
  x = find(x);
  y = find(y);
  if(x == y)  return;
  if(ran[x] < ran[y]){
    par[x] = y;
  }
  else{
    par[y] = x;
    if(ran[x] == ran[y])  ran[x]++;
  }
}
bool same(int x, int y){
  return find(x) == find(y);
}

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int n, m;
    scanf("%d%d", &n, &m);
    bool flag = 1, flag2 = 0;
    long long ans = 0;

    scanf(" %s", str + 1);

    init(n);

    for(int i = 1; i <= (n + 1)/ 2; i++)
    {
      if(str[i] == '?' || str[n + 1 - i] == '?')  flag2 = 1;
      if(str[i] == str[n + 1 - i])  unite(i, n + 1 - i);
      else  if(str[i] != '?' && str[n + 1 - i] != '?')  flag = 0;
      else if(str[i] == '?' || str[n + 1 - i] == '?'){
        if(str[i] == '?') str[i] = str[n + 1 - i];
        else if(str[n + 1 - i] == '?') str[n + 1 - i] = str[i];
        unite(i, n + 1 - i);
      }

    }
    for(int i = 0; i < m; i++)
    {
      int x, y;
      scanf("%d%d", &x, &y);
      if(str[x] == str[y])  unite(x, y);
      else{
        if(str[x] != '?' && str[y] != '?')  flag = 0;
        else if(str[x] == '?' || str[y] == '?'){
          if(str[x] == '?') str[x] = str[y];
          else if(str[y] == '?') str[y] = str[x];
          unite(x, y);
        }
      }

    }
    memset(vis, 0, sizeof(vis));
    int cnt = 0;
    for(int i = 1; i <= n; i++)
    {
      int x = find(i);
      if(vis[x] == 0 && str[x] == '?'){
        cnt++;
      //  printf("%d\n", i);
        vis[x] = 1;
      }
    }
    if(flag)
    {
      long long ans = 1;
      for(int i = 1; i <= cnt; i++)
        ans = (ans * 26) % 1000000007;
      if(flag2)
        printf("%lld\n", ans);
      else
        printf("0\n");
    }
    else
      printf("0\n");
  }
}
