#include <bits/stdc++.h>

using namespace std;

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int k, m, n;
    priority_queue<int> q;
    scanf("%d%d%d", &k, &m, &n);
    for(int i = 0; i < n; i++){
      int tmp;

      scanf("%d", &tmp);
      k -= tmp;
      q.push(tmp);
    //  printf("%d\n", k);
    }

    int ans = 0;
    for(int i = 0; i < n; i++){
      if(k >= m)  break;
    //  printf("%d\n", k);
      k += q.top();
      q.pop();
      ans++;
    }
    printf("%d\n", ans);
  }
}
