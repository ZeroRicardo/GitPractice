#include <bits/stdc++.h>

using namespace std;

int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int a1, a2, a3;
    scanf("%d%d%d", &a1, &a2, &a3);
    if(a1 + a2 + a3 == 180 && a1 > 0 && a2 > 0 && a3 > 0)
      printf("YES\n");
    else
      printf("NO\n");
  }
}
