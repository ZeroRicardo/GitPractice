#include <bits/stdc++.h>

using namespace std;
int cnt[10010];
int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int n;
    scanf("%d", &n);
    memset(cnt, 0, sizeof(cnt));
    for(int i = 0; i < n; i++){
      int tmp = 0;
      scanf("%d", &tmp);
      cnt[tmp]++;
    }
    long long ans = 0;
    for(int i = 1; i <= 10000; i++){
      if(cnt[i] > 1)  ans += cnt[i] * (cnt[i] - 1) / 2;
      for(int j = i + 1; j < i + 32 && j <= 10000; j++)
        ans += cnt[i] * cnt[j];
      }
    printf("%lld\n", ans);
  }
}
