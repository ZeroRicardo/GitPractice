#include <bits/stdc++.h>

using namespace std;
char su[10][10];
bool vis[10];
bool check()
{

  for(int i = 0; i < 9; i++)
  {
    memset(vis, 0, sizeof(vis));
    for(int j = 0; j < 9; j++){
      vis[su[i][j] - '0'] = 1;
    }
    for(int j = 1; j <= 9; j++)
      if(vis[j] != 1) return 0;
  }

  for(int i = 0; i < 9; i++)
  {
    memset(vis, 0, sizeof(vis));
    for(int j = 0; j < 9; j++){
      vis[su[j][i] - '0'] = 1;
    }
    for(int j = 1; j <= 9; j++)
      if(vis[j] != 1) return 0;
  }
  for(int m = 0; m < 9; m += 3)
    for(int n = 0; n < 9; n += 3)
    {
      memset(vis, 0, sizeof(vis));;
      for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
          vis[su[m + i][n + j] - '0'] = 1;
      for(int j = 1; j <= 9; j++)
            if(vis[j] != 1) return 0;
    }
    return 1;
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
     for(int i = 0; i < 9; i++)
      scanf(" %s", su[i]);
    if(check()) printf("Valid\n");
    else  printf("Invalid\n");
  }
}
/*
534678912
672195348
198342567
859761423
426853791
713924856
961537284
287419635
345286179
*/
