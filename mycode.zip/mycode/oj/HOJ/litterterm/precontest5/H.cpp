#include <bits/stdc++.h>

using namespace std;

int main()
{
  int n;
  long long F[260][260], dp[260];
  memset(F, 0, sizeof(F));
  memset(dp, 0, sizeof(dp));
  F[0][0] = 1;

  for(int i = 1; i <= 250; i++)
  {
    F[i][i] = 1;
    F[i][0] = 1;
    if(i % 2 == 0) F[i][i / 2] = 1;
    for(int j = i / 2; j >= 1; j--){
      for(int k = j; k <= i; k++)
      F[i][j] += F[i - 2 * j][k];
    }
    for(int j = 1; j <= i; j++)
    dp[i] += F[i][j];
  }

/*for(int i = 1; i <= 10; i++){
  for(int j = 1; j <= i; j++)
    printf("%lld ", F[i][j]);
  printf("\n");
}*/
  while(1){
    scanf("%d", &n);
    if(n == 0)  break;
    printf("%lld\n", dp[n]);
  }
  return 0;

}
