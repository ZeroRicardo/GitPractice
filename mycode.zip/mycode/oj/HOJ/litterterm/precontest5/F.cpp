#include <bits/stdc++.h>

using namespace std;
#define maxn 100
struct Node{
  int num;
  char name[30];
  int tot = 0;
  vector<int> next;
}G[maxn + 10];
void addedge(int u, int v){
  G[u].tot++; G[u].next.push_back(v);
  G[v].tot++; G[v].next.push_back(u);
}
int main()
{
  int T;
  scanf("%d", &T);
  while(T--){
    int n, V = 0;
    char teamt[3][30];
    map< char*, int> m;
    scanf("%d", &n);
    for(int i = 0; i < n; i++){
      scanf(" %s %s %s", teamt[1], teamt[2], teamt[3]);
      map<char*, int>::iterator ite;
      for(int j = 0; j < 3; j++){
        ite = m.find(teamt[j]);
        if(ite == m.end()){
          m.insert(make_pair(teamt[i], V));
          strcpy(G[V].name, teamt[i]);
          V++;
      }
    }

      int a, b, c;
      a = m.find(teamt[0])->second;
      b = m.find(teamt[1])->second;
      c = m.find(teamt[2])->second;
      addedge(a, b);
      addedge(b, c);
      addedge(a, c);
    }
    int st;
    for(int i = 0; i < V; i++){
      if(strcmp(G[V].name, "Ahmad") == 0){
        st = i;
        break;
      }
    }
    G[st].num = 0;


  }
}
