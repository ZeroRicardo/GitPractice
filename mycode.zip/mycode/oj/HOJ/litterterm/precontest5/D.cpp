#include <iostream>
#include <stdio.h>

using namespace std;
long long CC(int n,int k)
{
	double ans=1;
	for(int i=1;i<=k;i++)
	{
		ans*=(double)(n--)/i;
	}
	for(int i=1;n>0;i++)
	{
		ans*=(double)(n--)/i;
	}
	return (long long)(ans+0.5);
}
int main()
{
   // freopen("1.txt", "r", stdin);
    int T;
    scanf("%d", &T);
    while(T--){
        int n, m, k, d, ct = 0;
        scanf("%d%d%d%d", &n, &m, &k, &d);
        for(int i = 0; i < n; i++)
        {
            int tp;
            scanf("%d", &tp);
            if(tp >= d) ct++;
        }
       // cout <<ct <<endl;
        long long ans = 0;
        for(int i = k; i <= ct; i++){
            if(i >= m)  break;
            ans += CC(ct, i) * CC(n - ct, m - i) % 1000000007;
          }
        printf("%lld\n", ans);
    }
    return 0;
}
