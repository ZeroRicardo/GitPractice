#include <bits/stdc++.h>

using namespace std;
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    int ce = 0, cd = 0, cs = 0;
    char pas[110];
    scanf(" %s", pas);
    for(int i = 0; pas[i]; i++){
      if('a' <= pas[i] && pas[i] <= 'z' || 'A' <= pas[i] && pas[i] <= 'Z')
        ce++;
      else if('0' <= pas[i] && pas[i] <= '9')
        cd++;
      else if(pas[i] == '@' || pas[i] == '?' || pas[i] == '!')
        cs++;
    }
    if(ce < 4)
      printf("The last character must be a letter.\n");
    else if(cd < 4)
      printf("The last character must be a digit.\n");
    else if(cs < 2)
      printf("The last character must be a symbol.\n");
    else
      printf( "The last character can be any type.\n");
  }
  return 0;
}
