#include <bits/stdc++.h>

using namespace std;

int main()
{
  int n;
  int t[110][110];
  int a[110];
  scanf("%d", &n);
  for(int i = 0; i < n; i++){
    for(int j = 0; j < n; j++){
      scanf("%d", &t[i][j]);
    }
  }
  for(int i = 0; i < n; i++){
    a[i] = (int)sqrt(t[i][i]);
    printf("%d ", a[i]);
  }
  printf("\n");
}
