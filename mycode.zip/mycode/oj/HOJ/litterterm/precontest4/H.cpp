#include <bits/stdc++.h>

using namespace std;
#define maxn 100000
int a[maxn + 10];
set<int> cnt[52];
int main()
{
  int n;
  scanf("%d", &n);
  for(int i = 1; i <= n; i++){
    scanf("%d", &a[i]);
    cnt[a[i]].insert(i);
  }
  for(int i = 1; i <= n; i++){
    bool flag = 0, flag1;
    set<int>::iterator p;;
    int maxp = maxn;
    for(int j = a[i] + 1; j <= 50; j++){
      flag1 = 0;
      if(!cnt[j].size())  continue;
      p = cnt[j].upper_bound(i);
      if(p != cnt[j].end() && *p > i){
        flag = 1;
        flag1 = 1;
      }
      if(flag1)
        maxp = min(maxp, *p);
    }
    if(flag)
      printf("%d ", a[maxp]);
    else
      printf("-1 ");
  }

/*  for(int i = 1; i <= 50; i++){
    set<int>::iterator j;;
    for( j = cnt[i].begin(); j != cnt[i].end(); j++){
      printf("%d ", *j);
    }
    printf("\n");
  }*/
  return 0;
}
