#include <bits/stdc++.h>

using namespace std;
const int MOD = 1e9 + 7;
#define maxn 100000
int fact[maxn + 10];
void init(int p)
{
  fact[0] = 1;
  for(int i = 1; i <= maxn; i++)
    fact[i] = (fact[i - 1] * i) % p;
}
int gcd(int a, int b)
{
  return b == 0 ? a : gcd(b, a % b);
}
int extgcd(int a, int b, int &x, int &y){
  int d = a;
  if(b != 0){
    d = extgcd(b, a % b, y, x);
    y -= (a / b) * x;
  }
  else{
    x = 1;
    y = 0;
  }
  return d;
}
long long mod_fact(int n, int p, int &e){
  e = 0;
  if(n == 0)  return 1;
  long long res = mod_fact(n / p, p, e);
  e += n / p;
  if(n / p % 2 != 0)  return res * (p - fact[n % p]) % p;
  return res * fact[n % p] % p;
}
int mod_inverse(int a, int m)
{
  int x, y;
  extgcd(a, m, x, y);
  return (m + x % m) % m;
}
int mod_comb(int n, int k ,int p){
  if(n < 0 || k < 0 || n < k) return 0;
  int e1, e2, e3;
  long long a1 = mod_fact(n, p, e1), a2 = mod_fact(k, p, e2), a3 = mod_fact(n - k, p, e3);
  if(e1 > e2 + e3) return 0;
  else return a1 * mod_inverse(a2 * a3 % p, p) % p;
}
int main()
{
    init(MOD);
    int e;
    for(int i = 1; i <= 100; i++)
      printf("%d\n", mod_fact(i, MOD, e));
    int m, n, k, p, q, tmp;
    long long y, pn;
    double P;
    scanf("%d %d %d %lf", &m, &n, &k, &P);
    q = (int)(P * 1000);
    p = 1000;
    int gd = gcd(q, p);
    q = q / gd;
    p = p / gd;


    if(k > 1)
    {
      tmp = mod_comb(n - 1, k - 1, MOD);
      printf("%d\n", tmp);
      for(int i = 1; i <= n - k; i++)
      tmp = (tmp * (p - q)) % MOD;
      for(int i = 1; i <= k; i++)
        tmp = (tmp * q) % MOD;
      pn = p;
    for(int i = 1; i <= n - 1; i++)
      pn = (pn * p) % MOD;
    }
    else{
      tmp = q;
      pn = p;
    }
    for(int i = 0; ;i++){
      if(((long long)MOD * i + tmp) % pn == 0)
      {
        y = ((long long)MOD * i + tmp) / pn;
        break;
      }
    }

    printf("%d %lld %lld\n", tmp, pn, y);

}
