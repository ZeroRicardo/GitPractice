#include <bits/stdc++.h>

using namespace std;
char s[100000 + 10];
int cnt[26];
vector<int> ANS, mincost;
int main()
{
  scanf("%s", s);
  memset(cnt, 0, sizeof(cnt));
  for(int i = 0; s[i]; i++)
    cnt[s[i] - 'a']++;
  ANS.push_back(2);
  for(int i = 0; i < 26; i++)
    if(cnt[i] >= 2)
    ANS.push_back(cnt[i]);
  for(int i = 0; i < ANS.size(); i++)
  {
      int cost = 0;
      for(int j = 0; j < 26; j++)
        cost += cnt[j] * (cnt[j] % ANS[i]);
      mincost.push_back(cost);
//      printf("%d %d\n", ANS[i], cost);
  }
  int mint = 0x7fffffff, ans = 2;
  for(int i = 0; i < ANS.size(); i++)
  {
    if(mint > mincost[i])
    {
      mint = mincost[i];
      ans = ANS[i];
    }
  }
  printf("%d\n", ans);
  return 0;

}
