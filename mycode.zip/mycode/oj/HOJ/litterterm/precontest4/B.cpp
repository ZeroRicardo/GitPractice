#include <bits/stdc++.h>

using namespace std;
#define maxn 10000
char s[maxn + 10];
long long dp[maxn + 10];
const int MOD = 1e9 + 7;
int main()
{
  int n;
  scanf("%d", &n);
  scanf(" %s", s);
  memset(dp, 0, sizeof(dp));
  dp[0] = 1;
  int l = 0;
  for(int i = 1; i < n; i++){
    bool flag = 0;
    int j;
    for(j = i - 1; j >= l; j--)
      if(s[i] == s[j]){
        l = j;
        flag = 1;
        break;
      }
    if(flag)
      dp[i] = (dp[i - 1] * 2 - dp[j]) % MOD;
    else
      dp[i] = dp[i - 1] * 2 % MOD;
  }
//  for(int i = 0; i < n; i++)
//  printf("%lld\n", dp[i]);
  printf("%lld\n", dp[n - 1]);
}
