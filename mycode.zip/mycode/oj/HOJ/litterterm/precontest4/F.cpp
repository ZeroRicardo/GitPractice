#include <bits/stdc++.h>

using namespace std;
#define maxn 100000
int a[maxn + 10], x[maxn + 10];
int main()
{
  int n, m;
  scanf("%d", &n);
  for(int i = 0; i < n; i++)
    scanf("%d", &a[i]);
  sort(a, a + n);
  scanf("%d", &m);
  for(int i = 0; i < m; i++)
    scanf("%d", &x[i]);
  for(int i = 0; i < m; i++){
    int *p = lower_bound(a, a + n, x[i]);
    if(p > a + n - 1)
      printf("Dr. Samer cannot take any offer :(.\n");
    else
      printf("%d\n", *p);
  }
  return 0;
}
