//#define LOCAL
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <cstdlib>
#include <algorithm>

using namespace std;

#define LL long long
#define ll long long
#define INF 0x3f3f3f3f
#define maxn MAX_N
#define MOD mod
#define MMT(x,i) memset(x,i,sizeof(x))
#define REP(i, n) for(int i = 0; i < n; i++)
#define FOR(i, n) for(int i = 1; i <= n; i++)
#define pb push_back
#define mp make_pair
#define X first
#define Y second

const LL MOD = 1e9 + 7;
const double pi = acos(-1.0);
const double E = exp(1);
const double EPS = 1e-8;

const int MAX_N = 1000010;
map<string, int> lis;
map<string, int>::iterator ite;
int beat[1010];
int main()
{
  #ifdef LOCAL
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
  #endif
  int n;
  while(cin >> n){
    if(n == 0)  break;
    lis.clear();
    MMT(beat, 0);
    char sp1[110], sp2[110];
    string str1, str2;
    int tot = 0, a, b;
    REP(i, n)
    {
      cin >> sp1 >> sp2;
      str1.assign(sp1);
      str2.assign(sp2);
    //  cout << sp1 << " " << sp2 << endl;
      ite = lis.find(str1);
      if(ite == lis.end()){
    //    cout << sp1 << endl;
        a = tot++;
        lis[str1] = a;
      }
      else
        a = lis[str1];

      ite = lis.find(str2);
      if(ite == lis.end()){
    //    cout << sp2 << endl;
        b = tot++;
        lis[str2] = b;
      }
      else
        b = lis[str2];
      beat[b]++;
    }

    int cnt = 0;
    REP(i, tot)
    {
    //  cout << beat[i] << endl;
      if(!beat[i])
        cnt++;
    }
    if(cnt == 1)  cout << "Yes" << endl;
    else  cout << "No" << endl;
  }
  return 0;
}
