#include <bits/stdc++.h>
using namespace std;
int n, m, t, mx, my, prex, prey;
bool first = 1;
int flower[22][22];
int getmax(){
  prex = mx, prey = my;
  int ret = 0;
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= m; j++){
      if(flower[i][j] > ret){
        ret = flower[i][j];
        mx = i;
        my = j;
      }
    }
  flower[mx][my] = 0;
  return ret;
}
int caldis(){
  if(first){
    first = 0;
    return mx + 1;
  }
  else return abs(prex - mx) + abs(prey - my) + 1;
}
int main(){
  scanf("%d%d%d", &n, &m, &t);
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= m; j++)
      scanf("%d", &flower[i][j]);
  int ans = 0;
  while(t > 0){
    int now = getmax();

    int d = caldis();
    if(d + mx <= t){
      ans += now;
      t -= d;
    }
    else break;
    //printf("%d %d %d\n", now, ans, t);
  }
  printf("%d\n", ans);
}
