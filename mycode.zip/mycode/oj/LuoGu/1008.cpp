#include <bits/stdc++.h>
using namespace std;
int a[11];
int main()
{
  for(int i = 1; i <= 9; i++)
    a[i] = i;
  for(int cnt = 1; cnt <= 362880; cnt++)
  {
    next_permutation(a + 1, a + 9 + 1);
    int x = a[1] * 100 + a[2] * 10 + a[3];
    int y = a[4] * 100 + a[5] * 10 + a[6];
    int z = a[7] * 100 + a[8] * 10 + a[9];
    if(2 * x == y && 3 * x == z) cout << x << " " << y << " " << z << endl;
  }
}
