#include <bits/stdc++.h>
using namespace std;
const int maxn = 28;
int w[maxn], v[maxn];
int dp[30010];
int main() {
  int V, n;
  scanf("%d%d", &V, &n);
  for(int i = 1; i <= n; i++)
    scanf("%d%d", &v[i], &w[i]);
  for(int i = 1; i <= n; i++)
    for(int j = V; j >= v[i]; j--)
      dp[j] = max(dp[j], dp[j - v[i]] + w[i] * v[i]);
  printf("%d\n", dp[V]);
}
