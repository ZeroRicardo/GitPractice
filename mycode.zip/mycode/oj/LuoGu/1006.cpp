#include <bits/stdc++.h>
using namespace std;
const int maxn = 55;
int a[maxn][maxn];
int dp[maxn][maxn][2 * maxn];   //i, j, k (i, k - i), (j, k - j)
int m, n;
int main() {
  scanf("%d%d", &m, &n);
  for(int i = 1; i <= m; i++)
    for(int j = 1; j <= n; j++)
      scanf("%d", &a[i][j]);
  for(int k = 3; k <= m + n; k++)
    for(int i = max(1, k - n - 1); i <= min(k - 1, m); i++)
      for(int j = i + 1; j <= min(k - 1, m); j++)
        dp[i][j][k] = max(max(dp[i - 1][j][k - 1], dp[i][j - 1][k - 1]),
                          max(dp[i][j][k - 1], dp[i - 1][j - 1][k - 1])) + a[i][k - i] + a[j][k - j];
  printf("%d\n", dp[m - 1][m][m + n - 1]);
}
