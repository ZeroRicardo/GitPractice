#include <bits/stdc++.h>
using namespace std;
int p1, p2, p3;
char buf[1010], ans[100010];
int main(){
  while(~scanf("%d%d%d", &p1, &p2, &p3)){
    scanf(" %s", buf);
    int j = 0;
    int len = strlen(buf);
    for(int i = 0; i <= len; i++){
      if(buf[i] == '-' && 1 <= i && i <= len - 2 &&
      ( (isdigit(buf[i - 1]) && isdigit(buf[i + 1]) && buf[i + 1] > buf[i - 1]) ||
      (isalpha(buf[i - 1]) && isalpha(buf[i + 1]) && buf[i + 1] > buf[i - 1]) ) )
      {
        char st, ed;
        int d;
        if(p3 == 1) st = buf[i - 1] + 1, ed = buf[i + 1], d = 1;
        else  st = buf[i + 1] - 1, ed = buf[i - 1], d = -1;
        for(char k = st; k != ed; k += d){
          for(int cnt = 1; cnt <= p2; cnt++){
            char tmp = k;
            if(p1 == 2 && isalpha(tmp)) tmp = k - 'a' + 'A';
            else if(p1 == 3)  tmp = '*';
            ans[j++] = tmp;
          }
        }
      }
      else ans[j++] = buf[i];
    }
    printf("%s\n", ans);
  }
}
