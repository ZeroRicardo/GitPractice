#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int maxn = 1010;
struct node{
  ll a, b;
}hh[maxn];
void show(int *p);
bool cmp(const node x, const node y){
  return max(1.0 / x.b, x.a * 1.0 / y.b) < max(1.0 / y.b, y.a * 1.0 / x.b);
}
int ans[20010], tmp[20010], gg[20010];
void mlti(int *p, int x){
  int c = 0;
  for(int i = 1; i <= p[0]; i++){
    int t = p[i] * x + c;
    p[i] = t % 10;
    c = t / 10;
  }
  while(c){
    p[++p[0]] = c % 10;
    c /= 10;
  }
}
int *div(int x){
  memcpy(gg, tmp, sizeof tmp);
  //show(gg);
  int c = 0;
  bool first = 1;
  for(int i = gg[0]; i >= 1; i--){
    c *= 10;
    int t = gg[i] + c;
    gg[i] = t / x;
    c = t % x;
    if(first && gg[i]){
      first = 0;
      gg[0] = i;
    }
    //printf("%d %d\n", c, gg[i]);
  }
  return gg;
}
bool right(int *a, int *b){
  if(a[0] > b[0]) return 0;
  else if(a[0] < b[0])  return 1;
  else{
    for(int i = a[0]; i >= 1; i--)
      if(a[i] > b[i]) return 0;
      else if(a[i] < b[i])  return 1;
    return 0;
  }
}
void show(int *p){
  for(int i = p[0]; i >= 1; i--)
    printf("%d", p[i]);
  printf("\n");
}
int main(){
  int n;
  scanf("%d", &n);
  for(int i = 0; i <= n; i++)
    scanf("%lld%lld", &hh[i].a, &hh[i].b);
  sort(hh + 1, hh + n + 1, cmp);
  tmp[0] = 1, tmp[1] = 1, ans[0] = 1, ans[1] = 0;
  for(int i = 0; i <= n; i++){
    if(i && right(ans, div(hh[i].b))) memcpy(ans, gg, sizeof ans);
    mlti(tmp, hh[i].a);
  }
  //show(tmp);
  show(ans);
}
