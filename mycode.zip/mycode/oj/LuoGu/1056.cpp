#include <bits/stdc++.h>
using namespace std;
struct nod{
  int cnt, id;
  nod(){cnt = 0;}
  bool operator <(const nod &x)const{
    return cnt > x.cnt;
  }
}row[1010], col[1010];
bool cmp(nod a, nod b){
  return a.id < b.id;
}
int main()
{
  memset(row, 0, sizeof row);
  memset(col, 0, sizeof col);
  int m, n, k, l, d;
  cin >> m >> n >> k >> l >> d;
  for(int i = 1; i <= d; i++)
  {
    int x, y, p ,q;
    cin >> x >> y >> p >> q;
    if(x == p) col[min(y, q)].cnt++;
    else if(y == q) row[min(x, p)].cnt++;
  }
  for(int i = 1; i <= m; i++) row[i].id = i;
  for(int j = 1; j <= n; j++) col[j].id = j;
  sort(row + 1, row + m);
  sort(col + 1, col + n);
  sort(row + 1, row + k + 1, cmp);
  sort(col + 1, col + l + 1, cmp);
  for(int i = 1; i <= k; i++)
    cout << row[i].id << " ";
  cout << endl;
  for(int i = 1; i <= l; i++)
    cout << col[i].id << " ";
  cout << endl;
}
