#include <bits/stdc++.h>
using namespace std;
double s;
int k;
int main()
{
  cin >> k;
  s = 0;
  int ans = 1;
  do{
    s += 1.0 / ans;
    ans++;
  }while(s <= k);
  cout << ans - 1 << endl;
}
