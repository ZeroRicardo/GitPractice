#include <bits/stdc++.h>
using namespace std;
int dp[62][5][32010];
int num[62], v[62][5], w[62][5];
int pos[62];
int n, m, k;
void debug() {
  printf("GG:\n");
  for(int i = 1; i <= m; i++) {
    for(int j = 1; j <= num[i]; j++)
      printf("%d %d\n", v[i][j], w[i][j]);
  }
  printf("\n");
}
int main() {
  scanf("%d%d", &n, &m);
  int k = 0;
  for(int i = 1; i <= m; i++) {
    int x, p, q;
    scanf("%d%d%d", &x, &p, &q);
    if(q == 0) {
      pos[i] = ++k;
      num[pos[i]] = 1, v[pos[i]][1] = x, w[pos[i]][1] = x * p;
    }
    else {
      for(int j = 1; j <= num[pos[q]]; j++) {
        v[pos[q]][j + num[pos[q]]] = v[pos[q]][j] + x;
        w[pos[q]][j + num[pos[q]]] = w[pos[q]][j] + x * p;
      }
      num[pos[q]] *= 2;
    }
  }
  m = k;
  // debug();
  int ans = 0;
  for(int i = 1; i <= m; i++)
    for(int k = 0; k <= num[i]; k++)
      for(int j = n; j >= v[i][k]; j--)
        for(int l = 0; l <= num[i - 1]; l++){
          dp[i][k][j] = max(dp[i][k][j], dp[i - 1][l][j - v[i][k]] + w[i][k]);
          ans = max(ans, dp[i][k][j]);
        }
  printf("%d\n", ans);

}
