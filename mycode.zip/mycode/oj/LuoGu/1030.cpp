#include <bits/stdc++.h>
using namespace std;
const int maxn = 12;
char s1[maxn], s2[maxn];
int len;
int get(char c) {
  for(int i = 1; i <= len; i++)
    if(s1[i] == c)
      return i;
}
void dfs(int l, int r, int ll, int rr) {
//  printf("%d %d %d %d ", l, r, ll, rr);
  char c = s2[rr];
  printf("%c", c);
  int p = get(c) - l;
  if(p >= 1)  dfs(l, p + l - 1, ll , p + ll - 1);
  if(p <= r - l - 1) dfs(p + l + 1, r, p + ll, rr - 1);
}
int main() {
  scanf(" %s %s", s1 + 1, s2 + 1);
  len = strlen(s1 + 1);
  dfs(1, len, 1, len);
}
