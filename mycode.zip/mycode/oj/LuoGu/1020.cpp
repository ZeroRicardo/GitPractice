
#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int a[maxn];
int f[maxn], g[maxn], cnt[maxn];
int main() {
  int n = 0;
  while(~scanf("%d", &a[++n]));
  n--;
  int ans1 = 0;
  memset(g, 0x3f, sizeof g);
  for(int i = 1; i <= n; i++) {
    f[i] = lower_bound(g + 1, g + n + 1, a[i]) - g;
    g[f[i]] = a[i];
    ans1 = max(ans1, f[i]);
  }
  for(int i = 1, j = n; i < j; i++, j--)
    swap(a[i], a[j]);
  memset(g, 0x3f, sizeof g);
  int ans2 = 0;
  for(int i = 1; i <= n; i++) {
    f[i] = upper_bound(g + 1, g + n + 1, a[i]) - g;
    g[f[i]] = a[i];
    ans2 = max(ans2, f[i]);
//    printf("%d ", f[i]);
  }
//  printf("\n");
  printf("%d\n%d\n", ans2, ans1);
}
