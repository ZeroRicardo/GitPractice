#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
  cin >> n;
  for(int i = n; i >= 0; i--){
    int t;
    cin >> t;
    if(t == 0)  continue;
    if(i != n){
      if(t > 0) cout << "+";
    }
    if(t != 1 || i == 0){
      if(t == -1 && i != 0) cout << "-";
      else
        cout << t;
    }
    if(i != 0){
      cout << "x";
      if(i != 1)
      cout << "^" << i;
    }
  }
  cout << endl;
}
