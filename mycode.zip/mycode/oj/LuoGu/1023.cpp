/*
(x0 + ans) * y0
x0 * y0 + ans * y0 >= xi * yi + ans * yi
ans * (y0 - yi) >= xi * yi - x0 * y0
if(yi > y0) ans >=  (xi * yi - x0 * y0) / (y0 - yi)
else ans <= (xi * yi - x0 * y0) / (y0 - yi)
*/
#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int x[maxn], mx, k, n;
double y[maxn], my;
bool cmp(double a, double b){
  return a > b;
}
int main(){
  scanf("%d", &mx);
  int u, v;
  n = 0;
  while(~scanf("%d%d", &u, &v)){
    if(u == -1 && v == -1)  break;
    x[n] = u, y[n] = v;
    if(n)
    x[n] -= x[0];
    //printf("%d %f\n", x[n], y[n]);
    n++;
  }
  mx -= x[0];
  x[0] = 0;
  scanf("%d", &k);
  sort(x, x + n);
  sort(y, y + n, cmp);
  for(int i = 0; i < n; i++){
    if(x[i] >= mx){
      my = (y[i] - y[i - 1]) / (x[i] - x[i - 1]) * (mx - x[i - 1]) + y[i - 1];
      break;
    }
  }
  if(x[n - 1] < mx){
    my = -k * (mx - x[n - 1]) + y[n - 1];
  }
  //printf("%f\n", my);
  double mint = 1e10, maxt = -1e10;
  for(int i = 1; i < n; i++){
    for(int tx = x[i - 1]; tx <= x[i]; tx++){
      //if(tx == x[i - 1])  ty = y[i - 1];
      double ty = (y[i] - y[i - 1]) / (x[i] - x[i - 1]) * (tx - x[i - 1]) + y[i - 1];
      //printf("%d %.2f %.2f\n", tx, ty, (tx * ty - mx * my) / (my - ty));
      if(fabs(ty - my) < 1e-5)  continue;
      if(ty > my) mint = min(mint, -(tx * ty - mx * my) / (ty - my));
      else if(ty < my)  maxt = max(maxt, -(tx * ty - mx * my) / (ty - my));
    }
  }
  for(int tx = x[n - 1]; ; tx++){
    double ty = -k * (tx - x[n - 1]) + y[n - 1];
    if(ty <= 0)  break;
    //printf("%d %.2f %.2f\n", tx, ty, (tx * ty - mx * my) / (my - ty));
    if(fabs(ty - my) < 1e-5)  continue;
    if(ty > my) mint = min(mint, -(tx * ty - mx * my) / (ty - my));
    else if(ty < my)  maxt = max(maxt, -(tx * ty - mx * my) / (ty - my));
  }
//  printf("%f %f\n", maxt, mint);
  int down = (int)ceil(maxt);
  int up = (int)floor(mint);
  if(down > up) printf("NO SOLUTION\n");
  else{
    if(down * up <= 0)  printf("0\n");
    else  printf("%d\n", abs(down) > abs(up) ? up : down);
  }
}
