#include <bits/stdc++.h>
using namespace std;
int k;
char table[8][12] = {"- -- -----", //up
                     "|   ||| ||", //upleft
                     "|||||  |||", //upright
                     "  ----- --", //mid
                     "| |   | | ", //downleft
                     "|| |||||||", //downright
                     "- -- -- --"}; //down
char s[1000010];
int main(){
  scanf("%d %s", &k, s);
  for(int i = 0; i < s[i]; i++){
    printf(" ");
    for(int j = 1; j <= k; j++)
      printf("%c", table[0][s[i] - '0']);
    printf("  ");
  }
  printf("\n");
  for(int j = 1; j <= k; j++){
    for(int i = 0; i < s[i]; i++){
      printf("%c", table[1][s[i] - '0']);
    for(int l = 1; l <= k; l++)
      printf(" ");
    printf("%c ", table[2][s[i] - '0']);
    }
    printf("\n");
  }
  for(int i = 0; i < s[i]; i++){
    printf(" ");
    for(int j = 1; j <= k; j++)
      printf("%c", table[3][s[i] - '0']);
    printf("  ");
  }
  printf("\n");
  for(int j = 1; j <= k; j++){
    for(int i = 0; i < s[i]; i++){
      printf("%c", table[4][s[i] - '0']);
    for(int l = 1; l <= k; l++)
      printf(" ");
    printf("%c ", table[5][s[i] - '0']);
    }
    printf("\n");
  }
  for(int i = 0; i < s[i]; i++){
    printf(" ");
    for(int j = 1; j <= k; j++)
      printf("%c", table[6][s[i] - '0']);
    printf("  ");
  }
  printf("\n");
}
