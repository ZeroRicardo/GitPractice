#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int maxn = 1005;
ll m[maxn];
ll k, n;
ll M(int x) {
  if(m[x])  return m[x];
  else return M(x - 1) * k;
}
int main() {

  while(cin >> k >> n) {
    memset(m, 0, sizeof m);
    m[0] = 1;
    ll ans = 0;
    for(int i = 0; i < 30; i++) {
      if(n & (1 << i))  ans += M(i);
    }
    cout << ans << endl;
  }
}
