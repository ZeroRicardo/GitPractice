#include <bits/stdc++.h>
using namespace std;
int m, s, t, d, hehe;
int get(int x) {
  if(x >= 6)  return 1;
  else if(x >= 2)  return 2;
  else return 3;
}
int main() {
  while(cin >> m >> s >> t) {
    d = s, hehe = t;
    while(d > 0 && t > 0) {
      //cout << m << " " << s - d << " " << hehe - t << endl;
      if(m >= 10) {
        m -= 10;
        d -= 60;
        t--;
      }
      else if(d >= 240 && t >= 14) {
        t -= 14;
        d -= 240;
      }
      else {
        int res = get(m);
        if((res + 1) * 17 >= d || res + 1 >= t) {
          while(d > 0 && t > 0) {
            d -= 17;
            t--;
          }
        }
        else {
          t -= res + 1;
          d -= 60;
          m += 4 * res - 10;
        }
      }
    }
    if(d <= 0)  {
      cout << "Yes" << endl;
      cout << hehe - t << endl;
    }
    else {
      cout << "No" << endl;
      cout << s - d << endl;
    }
  }
}
