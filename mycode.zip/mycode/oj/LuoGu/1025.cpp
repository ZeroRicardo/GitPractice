#include <bits/stdc++.h>
using namespace std;
int dp[210][12];
int main() {
  for(int i = 1; i <= 6; i++)
    dp[0][i] = 1;
  for(int i = 1; i <= 200; i++){
    for(int j = 1; j <= 6; j++) {
      if(j == 1)  dp[i][j] = 1;
      else if(i < j)  dp[i][j] = dp[i][i];
      else {
        dp[i][j] = dp[i][j - 1] + dp[i - j][j];
      }
//      printf("%d %d %d\n", i, j, dp[i][j]);
    }
  }
  int n, k;
  scanf("%d%d", &n, &k);
  printf("%d\n", dp[n][k] - dp[n][k - 1]);
}
