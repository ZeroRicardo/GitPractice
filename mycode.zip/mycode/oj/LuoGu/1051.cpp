#include <bits/stdc++.h>
using namespace std;
const int maxn = 110;
struct stu{
  char name[25];
  int score;
  stu(){score = 0;}
  bool operator < (const stu & t)const{
    return score < t.score;
  }
};
int main(){
  int n;
  stu tmp, m;
  scanf("%d", &n);
  int sum = 0;
  for(int i = 1; i <= n; i++){
    char name[25];
    int ave, remark, paper;
    char super, west;
    scanf("%s %d%d %c %c %d", name, &ave, &remark, &super, &west, &paper);
    strcpy(tmp.name, name);
    tmp.score = 0;
    if(ave > 80 && paper >= 1)  tmp.score += 8000;
    if(ave > 85 && remark > 80) tmp.score += 4000;
    if(ave > 90)  tmp.score += 2000;
    if(ave > 85 && west == 'Y') tmp.score += 1000;
    if(remark > 80 && super == 'Y') tmp.score += 850;
    sum += tmp.score;
    m = max(m, tmp);
  }
  printf("%s\n%d\n%d\n", m.name, m.score, sum);
}
