#include <bits/stdc++.h>
using namespace std;
const int maxn = 110;
char st[maxn], ed[maxn], buf[maxn];
char coding[maxn], coded[maxn];
int main(){
  scanf(" %s %s %s", st, ed, buf);
  bool f = 1;
  memset(coding, 0, sizeof coding);
  memset(coded, 0, sizeof coded);
  for(int i = 0; st[i]; i++){
    if(coding[st[i] - 'A' + 1] && coding[st[i] - 'A' + 1] != ed[i]){
      f = 0;
      break;
    }
    else if(coded[ed[i] - 'A' + 1] && coded[ed[i] - 'A' + 1] != st[i]){
      f = 0;
      break;
    }
    else{
      coding[st[i] - 'A' + 1] = ed[i];
      coded[ed[i] - 'A' + 1] = st[i];
    }
  }
  for(int i = 1; i <= 26; i++)
    if(!coding[i])  f = 0;
  if(!f)  printf("Failed\n");
  else{
    for(int i = 0; buf[i]; i++)
      buf[i] = coding[buf[i] - 'A' + 1];
    printf("%s\n", buf);
  }
}
