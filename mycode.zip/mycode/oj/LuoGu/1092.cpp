#include <bits/stdc++.h>
using namespace std;
const int maxn = 302;
char eqt[3][maxn];
int ans[maxn];
bool vis[maxn];
int n;
bool flag = 0;
bool check(){
  int ct = 0;
  for(int i = n - 1; i >= 0; i--){
    int a = eqt[0][i] - 'A' + 1, b = eqt[1][i] - 'A' + 1, c = eqt[2][i] - 'A' + 1;
    if(((ans[a] + ans[b] + ct) % n) == ans[c]){
      ct = (ans[a] + ans[b] + ct) / n;
      continue;
    }
    else return 0;
  }
  return 1;
}
bool check1(){
  for(int i = n - 1; i >= 0; i--){
    int a = eqt[0][i] - 'A' + 1, b = eqt[1][i] - 'A' + 1, c = eqt[2][i] - 'A' + 1;
    if(ans[a] == -1 || ans[b] == -1 || ans[c] == -1) continue;
    else if((((ans[a] + ans[b] + 1) % n) == ans[c]) || (((ans[a] + ans[b]) % n) == ans[c])){
      continue;
    }
    else return 0;
  }
  return 1;
}
void dfs(int p, int lev, int ct) {
  //if(lev > 1)
  //printf("%d %d %d\n", p, lev, ans[eqt[lev][p] - 'A' + 1]);
  if(flag)  return;
  if(p < 0) {
    if(check()){
      flag = 1;
      for(int i = 1; i <= n; i++)
        printf("%d ", ans[i]);
      printf("\n");
    }
     return;
  }
  if(!check1()) return;
  if(lev < 2) {
    int u = eqt[lev][p] - 'A' + 1;
    if(ans[u] != -1) {
      //printf("hehe %d %d %d\n", p, lev, ans[u]);
      dfs(p , lev + 1, ct);
    }
    else
      for(int i = 0; i < n; i++)
        if(!vis[i]) {
          vis[i] = 1;
          ans[u] = i;
          //printf("%d %d %d\n", p, lev, ans[u]);
          //if(lev == 1)  printf("%d gg\n", vis[2]);
          dfs(p, lev + 1, ct);
          if(flag)  return;
          ans[u] = -1;
          vis[i] = 0;
        }
  }
  else {
     int u = eqt[0][p] - 'A' + 1, v = eqt[1][p] - 'A' + 1, w = eqt[2][p] - 'A' + 1;
     if(ans[w] != -1) {
       //printf("gg\n");
       if(ans[w] == (ans[u] + ans[v] + ct) % n){
         ct = (ans[u] + ans[v] + ct) / n;
         dfs(p - 1, 0, ct);
       }
     }
     else {
       int x = (ans[u] + ans[v] + ct) % n;
       ct = (ans[u] + ans[v] + ct) / n;
       if(!vis[x]) {
         ans[w] = x;
         vis[x] = 1;
         dfs(p - 1, 0, ct);
         vis[x] = 0;
         ans[w] = -1;
       }
     }
     if(flag) return;
   }
}
int main(){
  //clock_t start = clock();
  scanf("%d", &n);
  for(int i = 0; i < 3; i++)
    scanf(" %s", eqt[i]);
  memset(ans, -1, sizeof ans);
  //for(int i = 1; i <= n; i++)
  //  printf("%d ", ans[i]);
  //printf("\n");
  dfs(n - 1, 0, 0);
  //clock_t end = clock();
  //double TIME = (end - start) * 1.0 / CLOCKS_PER_SEC;
  //printf("%f seconds\n", TIME);
}
