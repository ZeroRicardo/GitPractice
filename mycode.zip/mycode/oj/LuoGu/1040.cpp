#include <bits/stdc++.h>
using namespace std;
const int maxn = 32;
int a[maxn], dp[maxn][maxn];
int root[maxn][maxn];
int n;
void dfs(int l, int r){
  //printf("%d %d ", l, r);
  if(!root[l][r]) return;
  printf("%d ", root[l][r]);
  dfs(l, root[l][r] - 1);
  dfs(root[l][r] + 1, r);
}
void debug(){
  //for(int i = 1; i <= n; i++)
  //  printf("%d : %d %d\n", i, lft[i], rht[i]);
  printf("\n");
}
int main(){
  scanf("%d", &n);
  for(int i = 1; i <= n; i++)
    scanf("%d", &a[i]);
  for(int i = 1; i <= n; i++){
    dp[i][i] = a[i];
    root[i][i] = i;
  }
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= n; j++)
      if(j < i) dp[i][j] = 1;
      else if(j - i == 1){
        dp[i][j] = a[i] + a[j];
        root[i][j] = i;
      }
  for(int len = 3; len <= n; len++)
    for(int l = 1; l + len - 1 <= n; l++){
      //debug();
      int r = l + len - 1;
      int tmp = -12032420, pos = l;
      for(int k = l; k <= r; k++){
        if(tmp < dp[l][k - 1] * dp[k + 1][r] + a[k]){
          tmp = dp[l][k - 1] * dp[k + 1][r] + a[k];
          pos = k;
        }
      }
      int k = pos;
      dp[l][r] = dp[l][k - 1] * dp[k + 1][r] + a[k];
      //lft[k] = root[l][k - 1], rht[k] = root[k + 1][r];
      root[l][r] = k;
      //printf("%d %d %d\n\n", l, r, dp[l][r]);
    }
  printf("%d\n", dp[1][n]);
  dfs(1, n);
  printf("\n");
}
