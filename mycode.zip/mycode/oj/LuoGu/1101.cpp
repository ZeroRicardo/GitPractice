#include <bits/stdc++.h>
using namespace std;
const int maxn = 110;
char mtx[maxn][maxn];
bool mrk[maxn][maxn];
char word[] = "yizhong";
int n;
int dx[] = {-1, -1, -1, 0, 0, 1, 1, 1}, dy[] = {-1, 0, 1, -1, 1, -1, 0, 1};
void check(int x, int y, int k){
  for(int i = 0; i <= 6; i++)
    if(mtx[x + i * dx[k]][y + i * dy[k]] != word[i])  return;
  for(int i = 0; i <= 6; i++)
    mrk[x + i * dx[k]][y + i * dy[k]] = 1;
  return;
}
int main(){
  scanf("%d", &n);
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= n; j++)
      scanf(" %c", &mtx[i][j]);
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= n; j++)
      if(mtx[i][j] == 'y'){
        for(int k = 0; k < 8; k++){
          int mx = i + 6 * dx[k], my = j + 6 * dy[k];
          if(1 <= mx && mx <= n && 1 <= my && my <= n)
            check(i, j, k);
        }
      }
  for(int i = 1; i <= n; i++)
    for(int j = 1; j <= n; j++)
      if(!mrk[i][j])  mtx[i][j] = '*';
  for(int i = 1; i <= n; i++){
    for(int j = 1; j <= n; j++)
      printf("%c", mtx[i][j]);
    printf("\n");
  }
}
