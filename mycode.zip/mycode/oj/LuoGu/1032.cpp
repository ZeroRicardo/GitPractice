#include <bits/stdc++.h>
using namespace std;
const int maxn = 202;
struct node{
  char s[maxn];
  int stp;
};
map<string, bool> mmp;
char f[12][maxn], t[12][maxn];
bool check(char *st, int pos, char *ed){
  int len = strlen(f[pos]);

    for(int j = 0; f[pos][j]; j++)
      if(!st[j] || st[j] != f[pos][j]) {
        return 0;
      }
    {
      int k = 0;
      //printf("%s\n", ed);
      for(int j = 0; t[pos][j]; j++)
        ed[k++] = t[pos][j];
      //  printf("%s\n", ed);
      for(int j = len; st[j]; j++)
        ed[k++] = st[j];
      ed[k] = 0;
      //  printf("%s\n", ed);
      return 1;
    }
  return 0;
}
int main(){
  char st[maxn], ed[maxn];
  scanf(" %s %s", st, ed);
  int n;
  for(int i = 0; ; i++)
    if(scanf(" %s %s", f[i], t[i]) == -1){
      n = i;
      break;
    }
  node x;
  strcpy(x.s, st);
  x.stp = 0;
  queue<node> q;
  q.push(x);
  string buf;
  buf.assign(x.s);
  mmp[buf] = true;
  int ans = -1;
  while(!q.empty()){
    node y = q.front();
    q.pop();
    //printf("%s\n", y.s);
    if(y.stp > 10)  break;
    if(!strcmp(y.s, ed)){
      ans = y.stp;
      break;
    }
    node nxt;
    for(int j = 0; y.s[j]; j++){
      strcpy(nxt.s, y.s);
      for(int i = 0; i < n; i++){
        if(check(y.s + j, i,nxt.s + j)){
          buf.assign(nxt.s);
          if(!mmp[buf]){
            mmp[buf] = true;
            nxt.stp = y.stp + 1;
            q.push(nxt);
          }
        }
      }
    }
  }
  if(ans == -1) printf("NO ANSWER!\n");
  else
    printf("%d\n", ans);
}
