#include <bits/stdc++.h>
using namespace std;
const int maxn = 30010;
int p[maxn];
int cnt[210];
int n, m;
int main(){
  scanf("%d%d", &m, &n);
  for(int i = 1; i <= n; i++){
    scanf("%d", &p[i]);
    cnt[p[i]]++;
  }
  //sort(p + 1, p + n + 1);
  int ans = 0;
  for(int i = 1; i <= n; i++){
    if(cnt[p[i]]){
      cnt[p[i]]--;
      ans++;
      for(int j = m - p[i]; j >= 0; j--){
        if(cnt[j]){
          cnt[j]--;
          break;
        }
      }
    }
  }
  printf("%d\n", ans);
}
