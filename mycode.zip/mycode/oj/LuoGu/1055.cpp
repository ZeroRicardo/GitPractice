#include <bits/stdc++.h>
using namespace std;
char str[22];
int main()
{
  cin >> str;
  int len = strlen(str);
  int x = 1, sum = 0;
  for(int i = 0; i < len - 1; i++){
    if(str[i] != '-'){
      sum += x * (str[i] - '0');
      x++;
    }
  }
  sum %= 11;
  bool flag = 0;
  if(sum == 10 && str[len - 1] == 'X') flag = 1;
  else  if(str[len - 1] == sum + '0') flag = 1;
  if(flag)  cout << "Right" << endl;
  else{
    if(sum == 10) str[len - 1] = 'X';
    else  str[len - 1] = sum + '0';
    cout << str << endl;
  }
}
