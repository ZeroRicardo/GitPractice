#include <bits/stdc++.h>
using namespace std;
int dp[32][32];
int main() {
  int n, m;
  scanf("%d%d", &n, &m);
  dp[0][0] = 1;
  for(int i = 1; i <= m; i++)
    for(int j = 0; j < n; j++){
      dp[i][j] = dp[i - 1][(j + 1) % n] + dp[i - 1][(j + n - 1) % n];
      //printf("%d %d\n", dp[i][j]);
    }
  printf("%d\n", dp[m][0]);
}
