#include <bits/stdc++.h>
using namespace std;
const int maxn = 10010;
bool f[maxn];
int main(){
  int l, m;
  cin >> l >> m;
  for(int i = 0; i <= l; i++)
    f[i] = true;
  for(int i = 1; i <= m; i++){
    int l, r;
    cin >> l >> r;
    for(int i = l; i <= r; i++)
      f[i] = false;
  }
  int ans = 0;
  for(int i = 0; i <= l; i++)
    ans += f[i];
  cout << ans << endl;
}
