#include <bits/stdc++.h>
using namespace std;
struct STU{
  int id, a, b, c;
  bool operator < (const STU &t)  const{
    if(a + b + c == t.a + t.b + t.c){
      if(a == t.a)  return id < t.id;
      else  return a > t.a;
    }
    else  return a + b + c > t.a + t.b + t.c;
  }
}stu[310];
int n;
int main(){
  scanf("%d", &n);
  for(int i = 1; i <= n; i++){
    scanf("%d%d%d", &stu[i].a, &stu[i].b, &stu[i].c);
    stu[i].id = i;
  }
  sort(stu + 1, stu + n + 1);
  for(int i = 1; i <= 5; i++)
    printf("%d %d\n", stu[i].id, stu[i].a + stu[i].b + stu[i].c);
}
