#include <bits/stdc++.h>
using namespace std;
struct node{
  int id, sco;
  bool operator < (const node &t){
    return sco == t.sco ? id < t.id : sco > t.sco;
  }
}cad[5010];
int main(){
  int n, k;
  while(~scanf("%d%d", &n, &k)){
    for(int i = 1; i <= n; i++)
      scanf("%d%d", &cad[i].id, &cad[i].sco);
    sort(cad + 1, cad + n + 1);
    k = int(floor(k * 1.5));
    int ans = cad[k].sco, num = k;
    for(int i = k + 1; i <= n; i++)
      if(ans == cad[i].sco)
        num++;
    printf("%d %d\n", ans, num);
    for(int i = 1; i <= num; i++)
      printf("%d %d\n", cad[i].id, cad[i].sco);
  }
}
