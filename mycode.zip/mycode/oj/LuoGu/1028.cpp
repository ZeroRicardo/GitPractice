#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
int f[maxn];
int main()
{
  f[0] = 0;
  for(int i = 1; i <= 1000; i++){
    f[i] = 1;
    for(int k = 1; k <= i / 2; k++)
      f[i] += f[k];
  }
  int n;
  cin >> n;
  cout << f[n] << endl;
}
