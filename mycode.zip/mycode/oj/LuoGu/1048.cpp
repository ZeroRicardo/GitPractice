#include <bits/stdc++.h>
using namespace std;
const int maxn = 10010;
int w[maxn], v[maxn];
int dp[100010];
int main() {
  int V, n;
  scanf("%d%d", &V, &n);
  for(int i = 1; i <= n; i++)
    scanf("%d%d", &v[i], &w[i]);
  for(int i = 1; i <= n; i++)
    for(int j = v[i]; j <= V; j++)
      dp[j] = max(dp[j], dp[j - v[i]] + w[i]);
  printf("%d\n", dp[V]);
}
