#include <bits/stdc++.h>
using namespace std;
int dx[4] = {-1, 1}, dy[4] = {1, -1};    // x / y
int main()
{
  int n;
  while(~scanf("%d", &n))
  {
      int x = 1, y = 1;
      int mod;
      for(int i = 1; i < n; i++)
      {
        if(x & 1 && y == 1){
          x += 1;
          mod = 0;
          continue;
        }
        if(y % 2 == 0 && x == 1){
          y += 1;
          mod = 1;
          continue;
        }
        x += dx[mod], y += dy[mod];
      }
      printf("%d/%d\n", y, x);
  }
}
