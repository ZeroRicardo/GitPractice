#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int bit[35];
bool mtx[15][15];
int num[15];
int n, a, b;
const int maxn = 2010;
struct BigInteger {
  int b[maxn], n;
  BigInteger() {
    n = 1;
    memset(b, 0, sizeof b);
  }
  BigInteger(ll x) {
    *this = x;
  }
  BigInteger(string s) {
    *this = s;
  }
  BigInteger operator = (string s) {
    n = s.size();
    for(int i = n - 1, j = 0; i >= 0; i--, j++)
      b[j] = s[i] - '0';
    return *this;
  }
  BigInteger operator = (ll x) {
    if(x == 0)  n = 1;
    else {
      n = 0;
      while(x) {
        b[n++] = x % 10;
        x /= 10;
      }
    }
  }
  BigInteger operator + (const BigInteger &x) const{
    BigInteger ret;
    ret.n = max(n, x.n);
    int c = 0;
    for(int i = 0; i < ret.n; i++) {
      ret.b[i] = (b[i] + x.b[i] + c) % 10;
      c = (b[i] + x.b[i] + c) / 10;
    }
    if(c) ret.b[ret.n++] = c;
    return ret;
  }
  BigInteger operator - (const BigInteger &x) const {   //默认左边 >= 右边
    BigInteger res;
    int c = 0;
    for(int i = 0; i < n; i++) {
      res.b[i] = b[i] - x.b[i] - c;
      if(res.b[i] < 0) {
        res.b[i] += 10;
        c = 1;
      }
      else c = 0;
      if(res.b[i])  res.n = i + 1;
    }
    return res;
  }
  BigInteger operator * (const BigInteger &x) const {
    BigInteger res;
    for(int i = 0; i < n; i++) {
      for(int j = 0; j < x.n; j++) {
        res.b[i + j] += b[i] * x.b[j];
        res.b[i + j + 1] += res.b[i + j] / 10;
        res.b[i + j] %= 10;
      }
    }
    res.n = n + x.n;
    while(res.n > 1 && !res.b[res.n - 1]) res.n--;
    return res;
  }
  bool operator < (const BigInteger &t) const {
    if(n < t.n) return 1;
    else if(n > t.n)  return 0;
    else {
      for(int i = n - 1; i >= 0; i--)
        if(b[i] < t.b[i]) return 1;
        else if(b[i] > t.b[i])  return 0;
      return 0;
    }
  }
  bool operator > (const BigInteger &t) const {
    return t < *this;
  }
  bool operator >= (const BigInteger &t) const {
    return !(*this < t);
  }

};
ostream& operator << (ostream &out, const BigInteger t) {
  //out << t.n << endl;
  for(int i = t.n - 1; i >= 0; i--)
    out << t.b[i];
    return out;
}
istream& operator >> (istream &in, BigInteger &t) {
  string s;
  in >> s;
  t = s;
  return in;
}
int main() {
  string s;
  cin >> s >> n;
  int len = s.size();
  for(int i = 0; s[i]; i++)
    bit[i] = s[i] - '0';
  for(int i = 1; i <= n; i++) {
    cin >> a >> b;
    mtx[a][b] = 1;
  }
  for(int i = 0; i <= 9; i++)
    mtx[i][i] = 1;
  for(int k = 0; k <= 9; k++)
    for(int i = 0; i <= 9; i++)
      for(int j = 0; j <= 9; j++)
        mtx[i][j] = mtx[i][j] | mtx[i][k] & mtx[k][j];
  for(int i = 0; i <= 9; i++) {
    num[i] = 0;
    for(int j = 0; j <= 9; j++)
      if(mtx[i][j]) num[i]++;
  }
  BigInteger ans = 1;
  ll hehe = 1;
  for(int i = 0; i < len; i++) {
    BigInteger x = num[bit[i]];
    hehe *= num[bit[i]];
    ans = ans * x;
  }
  cout << ans << endl;
}
