#include <bits/stdc++.h>
using namespace std;
int main()
{
  //freopen("save.in", "r", stdin);
  //freopen("save.out", "w", stdout);
  int dpo = 0, res = 0, t, ans = 0;
  for(int i = 1; i <= 12; i++)
  {
    res += 300;
    cin >> t;
    res -= t;
    if(ans < 0) continue;
    else{
      if(res < 0) ans = -i;
      else{
        dpo += res / 100 * 100;
        res = res % 100;
      }
    }
  }
  if(ans < 0) cout << ans << endl;
  else{
    ans = dpo + dpo / 5 + res;
    cout << ans << endl;
  }
}
