#include <bits/stdc++.h>
using namespace std;
char s[205];
int p, k;
int n;
char dic[8][205];
int dp[205][45];
int cont(int l, int r) {
  int res = 0;
  for(int i = l; i <= r; i++) {
    for(int j = 1; j <= n; j++) {
      bool match = 1;
      for(int k = 0; dic[j][k]; k++) {
        if(i + k > r || s[i + k] != dic[j][k]) {
          match = 0;
          break;
        }
      }
      if(match) {
        res++;
        break;
      }
    }
  }
  return res;
}
int main() {
  scanf("%d%d", &p, &k);
  for(int i = 0; i < p; i++)
    scanf(" %s", s + 1 + i * 20);
  scanf("%d", &n);
  for(int i = 1; i <= n; i++)
    scanf(" %s", dic[i]);
  for(int i = 1; i <= p * 20; i++){
    for(int j = 1; j <= min(k, i); j++) {
      for(int l = j - 1; l < i; l++)
        dp[i][j] = max(dp[i][j], dp[l][j - 1] + cont(l + 1, i));
    //  printf("%d ", dp[i][j]);
    }
    //printf("\n");
  }
  printf("%d\n", dp[p * 20][k]);
}
