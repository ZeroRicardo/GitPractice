#include <bits/stdc++.h>
using namespace std;
const int maxn = 2 * 110;
int a[maxn];
int dp[maxn][maxn];
int main() {
  int n;
  cin >> n;
  for(int i = 1; i <= n; i++) {
    cin >> a[i];
    a[n + i] = a[i];
  }
//  for(int i = 1; i <= 2 * n; i++)
//    cout << a[i] << " ";
//  cout << endl;
  for(int len = 3; len <= n + 1; len ++)
    for(int l = 1; ; l++) {
      int r = l + len - 1;
      if(r > 2 * n) break;
      for(int k = l + 1; k <= r - 1; k++)
        dp[l][r] = max(dp[l][r], dp[l][k] + dp[k][r] + a[l] * a[k] * a[r]);
  //    printf("%d %d %d\n", l, r, dp[l][r]);
    }
  int ans = 0;
  for(int i = 1; i <= n; i++)
    ans = max(ans, dp[i][i + n]);
  cout << ans << endl;
}
