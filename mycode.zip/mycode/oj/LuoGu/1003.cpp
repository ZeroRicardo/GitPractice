#include <bits/stdc++.h>
using namespace std;
struct node{
  int x, y, a, b;
}gg[10010];
int main(){
  int n;
  cin >> n;
  for(int i = 1; i <= n; i++)
    cin >> gg[i].x >> gg[i].y >> gg[i].a >> gg[i].b;
  int u, v;
  cin >> u >> v;
  int ans = -1;
  for(int i = 1; i <= n; i++)
    if(gg[i].x <= u && u <= gg[i].x + gg[i].a && gg[i].y <= v && v <= gg[i].y + gg[i].b)  ans = i;
  cout << ans << endl;
}
