#include <bits/stdc++.h>
using namespace std;
const int maxn = 10010;
int ans[maxn];
int n, m;
int main() {
  scanf("%d%d", &n, &m);
  for(int i = 1; i <= n; i++)
    scanf("%d", ans + i);
  for(int i = 1; i <= m; i++)
    next_permutation(ans + 1, ans + n + 1);
  for(int i = 1; i <= n; i++)
    printf("%d ", ans[i]);
  printf("\n");
}
