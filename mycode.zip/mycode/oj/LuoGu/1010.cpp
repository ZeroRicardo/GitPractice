#include <bits/stdc++.h>
using namespace std;
void show(int x){
    if(x == 0 || x == 2){
        cout << x;
        return;
    }
    int bit[32];
    memset(bit, 0, sizeof bit);
    for(int i = 0; i < 32; i++){
        bit[i] = x & 1;
        x >>= 1;
    }
    bool first = 1;
    for(int i = 31; i >= 0; i--){
        if(bit[i]){
            if(first)	first = 0;
            else cout << '+';
            if(i != 1){
                cout<< "2(";
                show(i);
                cout << ")";
            }
            else cout << 2;
        }
    }
}
int main(){
    int n;
    while(cin >> n){
        show(n);
        cout << endl;
    }
}
