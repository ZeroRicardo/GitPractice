#include <bits/stdc++.h>
using namespace std;
const int maxn = 1 << 12 + 10;
char fbi[maxn];
char str[maxn];
int n, m;
char build(int p) {
  char s1, s2;
  if(p < m) {
    s1 = build(2 * p + 1);
    s2 = build(2 * p + 2);
    if(s1 == s2 && s1 != 'F') {
      printf("%c", s1);
      return s1;
    }
    else {
      printf("F");
      return 'F';
    }
  }
  if(p >= m) {
    //printf("%d", p - m);
    if(str[p - m] == '0') {

      printf("B");
      return 'B';
    }
    else {
      printf("I");
      return 'I';
    }
  }
}
int main(){
  scanf("%d", &n);
  m = (1 << n) - 1;
  n = (1 << n + 1) - 2;
  scanf("%s", str);
  build(0);
}
