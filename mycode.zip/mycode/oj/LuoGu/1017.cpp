#include <bits/stdc++.h>
using namespace std;
const int maxn = 110;
int ans[maxn], num;
int main() {
  int n, r;
  scanf("%d%d", &n, &r);
  int haha = n;
  //n = abs(n), r = abs(r);
  while(n) {
    ans[num] = n % r;
    if(ans[num] < 0)  ans[num] += abs(r);
    n -= (ans[num]);
    num++;
    n /= r;
  }
  printf("%d=", haha);
  for(int i = num - 1; i >= 0; i--) {
    if(ans[i] >= 10)  printf("%c", 'A' + ans[i] - 10);
    else printf("%d", ans[i]);
  }
  printf("(base%d)\n", r);
}
