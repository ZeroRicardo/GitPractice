#include <bits/stdc++.h>
using namespace std;
char str[1010];
int main()
{
  char x;
  int x1 = 0, x2 = 0, t = 0, f = 1, tf = 1;
  gets(str);
  int len = strlen(str);
  for(int i = 0; i <= len; i++)
  {
    if(i == len){
      x2 += f * tf * t;
      t = 0;
    }
    else if(str[i] == '='){
      x2 += f * tf * t;
      f = -1;
      tf = 1;
      t = 0;
    }
    else if(str[i] == '-'){
      x2 += f * tf * t;
      tf = -1;
      t = 0;
    }
    else if(str[i] == '+'){
      x2 += f * tf * t;
      tf = 1;
      t = 0;
    }
    else if(isalpha(str[i])){
      x = str[i];
  //    cout << i << endl;
      if(t == 0) t = 1;
      x1 += f * tf * t;
      tf = 1;
      t = 0;
    }
    else if(isdigit(str[i]))
      t = t * 10 + str[i] - '0';
    else{
      x2 += f * tf * t;
      t = 0;
    }
  }
  //cout << x1 << endl;
  cout << x << "=" << fixed << setprecision(3) << - double(x2) / x1 << endl;
}
