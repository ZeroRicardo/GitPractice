#include <bits/stdc++.h>
using namespace std;
int l, n;
int a[5005];
int main() {
  cin >> l >> n;
  int mx = 0, mn = 0;
  for(int i = 1; i <= n; i++) {
    cin >> a[i];
    mn = max(mn, min(a[i], l + 1 - a[i]));
    mx = max(mx, max(a[i], l + 1 - a[i]));
  }
  cout << mn << " " << mx << endl;
}
