#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int t, n, m;
int main(){
  scanf("%d%d", &n, &m);
  int ans = 1, now = 0;
  for(int i = 1; i <= n; i++){
    scanf("%d", &t);
    if(now + t <= m)  now += t;
    else{
      now = t;
      ans++;
    }
  }
  printf("%d\n", ans);
}
