#include <bits/stdc++.h>
using namespace std;
const int maxn = 22;
bool vis[maxn];
int x[maxn];
int n, k;
bool isprime(int k){
  int p = 1, y = 0;
  while(k){
    if(k % 2) y += x[p];
    k /= 2;
    p++;
  }
  //cout << y << endl;
  if(y <= 1)  return 0;
  for(int i = 2; i <= sqrt(y); i++)
    if(y % i == 0)
      return 0;
  return 1;
}
int count(int x){
  int ret = 0;
  while(x){
    ret += x % 2;
    x /= 2;
  }
  return ret;
}
int main(){
  cin >> n >> k;
  for(int i = 1; i <= n; i++)
    cin >> x[i];
  int ans = 0;
  for(int i = 0; i < (1 << n); i++)
  {
    if(count(i) == k){
  //    cout << i << " ";
      ans += isprime(i);
    }
  }
  cout << ans << endl;
}
