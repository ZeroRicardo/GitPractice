#include <bits/stdc++.h>
using namespace std;
const int scr[9][9] = { {6, 6, 6, 6, 6, 6, 6, 6, 6},
                        {6, 7, 7, 7, 7, 7, 7, 7, 6},
                        {6, 7, 8, 8, 8, 8, 8, 7, 6},
                        {6, 7, 8, 9, 9, 9, 8, 7, 6},
                        {6, 7, 8, 9, 10, 9, 8, 7, 6},
                        {6, 7, 8, 9, 9, 9, 8, 7, 6},
                        {6, 7, 8, 8, 8, 8, 8, 7, 6},
                        {6, 7, 7, 7, 7, 7, 7, 7, 6},
                        {6, 6, 6, 6, 6, 6, 6, 6, 6} };
//bool vis[12];
int sud[12][12];
int lala[12];
int ans = -1;
struct GG{
  bool vis[12];
}gg[9][9];
int getsco() {
  int res = 0;
  for(int i = 0; i < 9; i++)
    for(int j = 0; j < 9; j++)
      res += scr[i][j] * sud[i][j];
  return res;
}
bool check(int x, int y) {
  memset(gg[x][y].vis, 0, sizeof gg[x][y].vis);
  for(int i = 0; i < 9; i++) {
  //  if(sud[x][i] && vis[sud[x][i]]) return 0;
    //else
     gg[x][y].vis[sud[x][i]] = 1;
  }
//  memset(vis, 0, sizeof vis);
  for(int i = 0; i < 9; i++) {
    //if(sud[i][y] && vis[sud[i][y]]) return 0;
    //else
    gg[x][y].vis[sud[i][y]] = 1;
  }
  int sx = x / 3 * 3, sy = y / 3 * 3;
//  memset(vis, 0, sizeof vis);
  for(int i = sx; i <= sx + 2; i++)
    for(int j = sy; j <= sy + 2; j++)
    //  if(sud[i][j] && vis[sud[i][j]]) return 0;
    //  else
      gg[x][y].vis[sud[i][j]] = 1;
  return 1;
}
void debug() {
  for(int i = 0; i < 9; i++) {
    for(int j = 0; j < 9; j++)
      printf("%d ", sud[i][j]);
    printf("\n");
  }
  printf("\n");
}
void dfs(int x, int y) {
  //debug();
  //printf("%d %d\n", x, y);
  if(x > 8) {
    ans = max(ans, getsco());
    return ;
  }
  if(sud[x][y]) {
    if(y < 8) dfs(x, y + 1);
    else dfs(x + 1, 0);
  }
  else {
    //random_shuffle(lala + 1, lala + 1 + 9);
    check(x, y);
    for(int i = 1; i <= 9; i++) {
      if(!gg[x][y].vis[i]){
        //printf("%d %d %d\n", x, y, i);
        sud[x][y] = i;
        //if(check(x, y))
        {
          if(y < 8) dfs(x, y + 1);
          else dfs(x + 1, 0);
        }
      }
    }
    sud[x][y] = 0;
    return ;
  }
}
int main() {
  srand(time(NULL));
  for(int i = 0; i < 9; i++)
    for(int j = 0; j < 9; j++)
      scanf("%d", &sud[i][j]);
  //for(int i = 1; i <= 9; i++)
  //  lala[i] = i;
  if(rand() & 1)
  for(int k = 0; k < 9; k++)
    for(int i = 0, j = 8; i < j; i++, j--)
      swap(sud[k][i], sud[k][j]);
  //if(rand() & 1)
  for(int k = 0; k < 9; k++)
    for(int i = 0, j = 8; i < j; i++, j--)
      swap(sud[i][k], sud[j][k]);
  dfs(0, 0);
  printf("%d\n", ans);
}
