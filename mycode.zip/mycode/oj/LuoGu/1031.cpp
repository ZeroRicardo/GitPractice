#include <bits/stdc++.h>
using namespace std;
const int maxn = 110;
int a[maxn], n;
int main(){
  int sum = 0;
  scanf("%d", &n);
  for(int i = 1; i <= n; i++){
    scanf("%d", &a[i]);
    sum += a[i];
  }
  sum /= n;
  for(int i = 1; i <= n; i++)
    a[i] -= sum;
  int ans = 0;
  for(int i = 1; i <= n; i++){
    a[i] += a[i - 1];
    if(a[i])  ans++;
  }
  printf("%d\n", ans);
}
