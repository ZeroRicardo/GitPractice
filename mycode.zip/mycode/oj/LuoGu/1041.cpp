#include <bits/stdc++.h>
using namespace std;
const int maxn = 10010;
int a[maxn], b[maxn], c[maxn], d[maxn];
int main(){
  int n = 0, m = 0;
  char s;
  while(~scanf(" %c", &s)){
    if(s == 'E')  break;
    else if(s == 'W')  a[n]++, c[m]++;
    else if(s == 'L')  b[n]++, d[m]++;
    if((a[n] >= 11 || b[n] >= 11)  && abs(a[n] - b[n]) >= 2){
      n++;
    }
    if((c[m] >= 21 || d[m] >= 21) && abs(c[m] - d[m]) >= 2){
      m++;
    }
  }
  for(int i = 0; i < n; i++)
    printf("%d:%d\n", a[i], b[i]);
  if(a[n] || b[n] || n == 0){
    printf("%d:%d\n", a[n], b[n]);
    n++;
  }
  if((a[n - 1] >= 11 || b[n - 1] >= 11)  && abs(a[n - 1] - b[n - 1]) >= 2)  printf("0:0\n");
  printf("\n");
  for(int i = 0; i < m; i++)
    printf("%d:%d\n", c[i], d[i]);
  if(c[m] || d[m] || m == 0){
    printf("%d:%d\n", c[m], d[m]);
    m++;
  }
  if((c[m - 1] >= 21 || d[m - 1] >= 21) && abs(c[m - 1] - d[m - 1]) >= 2) printf("0:0\n");
}
