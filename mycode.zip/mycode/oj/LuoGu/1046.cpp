#include <bits/stdc++.h>
using namespace std;
int h[12];
int main(){
  int k, ans = 0;
  for(int i = 1; i <= 10; i++)
    cin >> h[i];
  cin >> k;
  for(int i = 1;i <= 10; i++)
    if(h[i] <= k + 30)
      ans++;
  cout << ans << endl;
}
