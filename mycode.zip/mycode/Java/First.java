package P1;

import java.io.*;
import java.net.InterfaceAddress;
import java.util.regex.Pattern;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.IconifyAction;

import org.omg.CORBA.StringHolder;

public class MagicSquare {

	public static boolean isLegalMagicSquare(String fileName) {
		int[][] magicSquare = null;
		int n = 0, row = 0;
		BufferedReader reader = null;
		Pattern pattern = Pattern.compile("[0-9]*");
		try {
			reader = new BufferedReader(new FileReader(fileName));
			String myLine = null;

			while ((myLine = reader.readLine()) != null) {

				// 检查分割字符是否为'\t', 非'\t'则return false;
				for (char c : myLine.toCharArray()) {
					if (Character.isSpace(c) && c != '\t') {
						System.out.println("Split character error!");
						reader.close();
						return false;
					}
				}

				// 初始化矩阵, 并判断每行元素个数是否相等, 若不相等, 则return false;
				String[] tempStrings = myLine.split('\t');
				if (n == 0) {
					n = tempStrings.length;
					magicSquare = new int[n][n];
				} else if (n != tempStrings.length) {
					System.out.println("Size error!");
					reader.close();
					return false;
				}

				// 将读取的数字存入矩阵中, 并判断是否为正整数, 若不为正整数, 则return false;
				for (int i = 0; i < n; i++) {
					if (pattern.matcher(tempStrings[i]).matches() == false) {
						System.out.println("Type Error!");
						reader.close();
						return false;
					}
					magicSquare[row][i] = Interger.valueOf(tempStrings[i]);
				}
				row++;
				reader.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
					return false;
				}
			}
		}

    // 求对角线之和, 并判断是否相等
  	int sum = 0, checkSum = 0;
  	for(int i = 0;i<n;i++) {
  		checkSum += magicSquare[i][i];
  		sum += magicSquare[i][n - i - 1];
  	}
  	if(sum!=checkSum) {
  		System.out.println("Sum is not the same constant.");
  		return false;
  	}
  	for(int i = 0;i<n;i++) {

  		// 检验行之和是否相等
  		sum = 0;
  		for (int j = 0; j < n; j++)
  			sum += magicSquare[i][j];
  		if (sum != checkSum) {
  			System.out.println("Sum is not the same constant.");
  			return false;
  		}

  		// 检验列和是否相等
  		sum = 0;
  		for (int j = 0; j < n; j++)
  			sum += magicSquare[j][i];
  		if (sum != checkSum) {
  			System.out.println("Sum is not the same constant.");
  			return false;
  		}
	}



	public static boolean generateMagicSquare(int n) {

		return false;
	}

	public static void main(String[] args) {

	}

}
