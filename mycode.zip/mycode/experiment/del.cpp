//如果a与b互质，c与b互质，则有a*c与b互质
#include <bits/stdc++.h>
using namespace std;
using ull = unsigned long long;
ull a[12];
bool vis[12];
int gcd(int x, int y){
	return y == 0 ? x : gcd(y, x % y);
}
int main(){
	int n;
	cin >> n;
	for(int i = 1;i <= n; i++)
		cin >> a[i];
	int ans = 0;
	for(int i = 1; i <= n; i++){
		if(!vis[i]){
			ull tmp = a[i];
			vis[i] = 1;
			ans++;
			for(int j = 1; j <= n; j++){
				if(!vis[j] && gcd(tmp, a[j]) == 1){
					vis[j] = 1;
					tmp *= a[j];
				}
			}
		}
	}
	cout << ans << endl;
}
