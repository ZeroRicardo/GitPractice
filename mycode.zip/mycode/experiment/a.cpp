#include <math.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <algorithm>

const int MAXN = 50010;

int n, q, a[MAXN][22], b[MAXN][22];//a维护最大值，b维护最小值，下面代码求的是最大值和最小值的差值
int query(int i, int j) {
int l, log2_l;
log2_l = (int)log2(j - i + 1);
l = 1 << log2_l;
return std::max(a[i][log2_l], a[j - l + 1][log2_l]) - std::min(b[i][log2_l], b[j - l + 1][log2_l]);
}
int main() {
static int i, j, l;

scanf("%d%d", &n, &q);
for (i = 1; i <= n; ++i) {
scanf("%d", &a[i][0]);
b[i][0] = a[i][0];
}
for (l = 1, j = 1; (l << 1) <= n; l <<= 1, ++j)
for (i = 1; i <= n - (l << 1) + 1; ++i) {
a[i][j] = std::max(a[i][j - 1], a[i + l][j - 1]);
b[i][j] = std::min(b[i][j - 1], b[i + l][j - 1]);
}
while (q--) {
scanf("%d %d", &i, &j);
printf("%d\n", query(i, j));
}
return 0;
}
