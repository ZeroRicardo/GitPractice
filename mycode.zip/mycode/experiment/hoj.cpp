#include <cstdio>
using namespace std;
int main()
{
  int T;
  scanf("%d", &T);
  while(T--)
  {
    long long n;
    scanf("%lld", &n);
    printf("%lld\n", n % 2 ? (
      n - 1) * (n - 1) / 4 : n * n / 4 - n / 2);
  }
}
