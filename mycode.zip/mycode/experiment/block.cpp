//分块求最值
#include <bits/stdc++.h>
using namespace std;
const int maxn = 200010;
int a[maxn], b[maxn], n, t;
void init_B()
{
  int maxa = -0x3f3f3f3f;
  t = 0;
  int blo = sqrt(n);
  for(int i = 1; i <= n; i++)
  {
    maxa = max(maxa, a[i]);
    if(i % blo == 0 || i == n){
  //    cout << "i" << i << endl;
      b[++t] = maxa;
      maxa = -1;
    }
  }
}
void Modify(int pos, int val)
{
  a[pos] = val;
  int blo = sqrt(n);
  int t = ceil(pos * 1.0 / blo);
  int maxa = -0x3f3f3f3f;
  for(int i = (t - 1) * blo + 1; i <= t * blo && i <= n; i++)
  {
  //  cout << "mi" << i << endl;
    maxa = max(maxa, a[i]);
  }
  b[t] = maxa;
}
int query(int l, int r)
{
  int maxt = -0x3f3f3f3f;
  int blo = sqrt(n);
  int x = ceil(l * 1.0 / blo), y = r / blo;
  if(x > y)
  {
    for(int i = l; i <= r; i++)
      maxt = max(maxt, a[i]);
  }
  else
  {
    for(int i = x + 1; i <= y; i++)
      maxt = max(maxt, b[i]);
    for(int i = l; i <= x * blo; i++)
      maxt = max(maxt, a[i]);
    for(int i = y * blo; i <= r; i++)
      maxt = max(maxt, a[i]);
  }
  return maxt;
}
void Print()
{
  for(int i = 1; i <= n; i++)
    cout << a[i] << " ";
  cout << endl;
  for(int i = 1; i <= t; i++)
    cout << b[i] << " ";
  cout << endl;
}
int main()
{
  ios::sync_with_stdio(false);
  int m, x, l, r;
  char op;
  while(cin >> n >> m)
  {
    for(int i = 1; i <= n; i++)
      cin >> a[i];
    //cout << (int)sqrt(n) << endl;
    init_B();
    //Print();
    for(int i = 1; i <= m; i++)
    {
      cin >> op;
      if(op == 'U')
      {
        cin >> x >> l;
        Modify(x, l);
        //Print();
      }
      else
      {
        cin >> l >> r;
        cout << query(l, r) << endl;
      }
    }
  }
}
/*
16
1 2 7495 6 5 3 743 98456 8657 8 09 0 89 8 6 5
*/
