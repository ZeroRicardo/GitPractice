
#include <bits/stdc++.h>
using namespace std;
int n, m;
int a[310];
int sum[310][310];      //sum[i][j] 表示 在第i个点到第j个点中建一个站的总最小距离
int dp[310][310];       //dp[i][j] 表示 前j个点建i个站的总最小距离
int main(){
  scanf("%d%d", &n, &m);
  a[0] = 0;
  for(int i = 1; i <= n; i++)
    scanf("%d", &a[i]);
  sort(a + 1, a + 1 + n);
  for(int i = 2; i <= n; i++)
    a[i] += a[i - 1];
  for(int i = 1; i <= n; i++)
    for(int j = i; j <= n; j++){
      sum[i][j] = a[j] - a[(i + j) / 2] - a[(i + j - 1) / 2] + a[i - 1];
    }
    memset(dp, 0x3f, sizeof dp);
    dp[0][0] = 0;
    for(int i = 1; i <= m; i++)
      for(int j = 1; j <= n; j++)
        for(int k = 0; k <= n; k++)
          dp[i][j] = min(dp[i][j], dp[i - 1][k] + sum[k + 1][j]);
    printf("%d\n", dp[m][n]);
}
