#include <stdio.h>
#include <string.h>
int n;
int t, cnt[2];
int main() {
	scanf("%d", &n);
	for(int i = 1; i <= n; i++) {
		scanf("%d", &t);
		cnt[t & 1]++;
	}
	if(cnt[0] > cnt[1])	printf("%d\n", cnt[1]);
	else printf("%d\n", cnt[0] + (cnt[1] - cnt[0]) / 3);
}
