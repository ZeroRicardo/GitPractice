#include <bits/stdc++.h>
using namespace std;
const int maxn = 1 << 19;
const int inf = 0x3f3f3f3f;
int dat[maxn], tot;
void init(int n)
{
  tot = 1;
  while(tot < n)  tot <<= 1;
  memset(dat, 0x3f, sizeof dat);
}
void update(int x, int val)
{
  x += tot - 1;
  dat[x] = val;
  while(x)
  {
    x = (x - 1) / 2;
    dat[x] = min(dat[x * 2 + 1], dat[x * 2 + 2]);
  }
}
int query(int a, int b, int k, int l, int r)
{
  if(a >= r || b <= l)  return inf;
  if(a <= l && b >= r)  return dat[k];
  int v1 = query(a, b, 2 * k + 1, l, (l + r) / 2);
  int v2 = query(a, b, 2 * k + 2, (l + r) / 2, r);
  return min(v1, v2);
}
int main()
{
  int n, m;
  while(~scanf("%d", &n))
  {
    int q, l, r, x;
    init(n);
    for(int i = 0; i < n; i++)
    {
      scanf("%d", &x);
      update(i, x);
    }
    scanf("%d", &q);
    for(int i = 1; i <= q; i++)
    {
      scanf("%d%d%d", &x, &l, &r);
      if(x == 1)  printf("%d\n", query(l, r + 1, 0, 0, tot));
      else  update(l, r);
    }
  }
}
