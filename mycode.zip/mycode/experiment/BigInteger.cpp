
//大数模板 未完成版
#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn = 100010;
struct BigInt{
  int s[maxn], num;
  bool flag;
  BigInt(){
    memset(s, 0, sizeof s);
    num = 0;
  }
  BigInt operator = (const ll x){
    ll t = x;
    num = 0;
    while(t){
      s[num++] = t % 10;
      t /= 10;
    }
    return *this;
  }
  BigInt operator + (const BigInt &x){
    BigInt ret;
    int c = 0;
    for(int i = 0; i < max(num, x.num); i++){
      ret.s[i] = (c + s[i] + x.s[i]) % 10;
      c = (c + s[i] + x.s[i]) / 10;
      ret.num++;
    }
    if(c) ret.s[ret.num++] = c;
    return ret;
  }
  BigInt operator * (BigInt &x){
    BigInt ret;
    for(int i = 0; i < x.num; i++){
      int t = x.s[i], c = 0;
      int j, k;
      for(j = 0, k = i; j < num; j++, k++){
        int tmp = ret.s[k] + t * s[j] + c;
        ret.s[k] = tmp % 10;
        c = tmp / 10;
      }
      while(c){
        int tmp = (ret.s[k] + c);
        ret.s[k] = tmp % 10;
        c = tmp / 10;
        k++;
      }
      ret.num = max(ret.num, k);
    }
    return ret;
  }
};
ostream& operator << (ostream &out, const BigInt &x){
  for(int i = x.num - 1; i >= 0; i--)
    out << x.s[i];
  return out;
}
