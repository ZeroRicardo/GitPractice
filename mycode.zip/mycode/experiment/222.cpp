#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mod = 1e9 + 7;
ll dp[110][110];
int main() {
  int n, k;
  while(cin >> k >> n) {
    for(int i = 1; i < k; i++)
      dp[1][i] = 1;
    for(int i = 2; i <= n; i++)
      for(int j = 0; j < k; j++) {
        for(int m = 0; m < k; m++)
          if(abs(j - m) != 1)
            dp[i][j] = (dp[i][j] + dp[i - 1][m]) % mod;
      }
    ll ans = 0;
    for(int i = 0; i < k; i++)
      ans = (ans + dp[n][i]) % mod;
    cout << ans << endl;
  }
}
