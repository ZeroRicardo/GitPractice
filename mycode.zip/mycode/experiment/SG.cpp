int f[N];
int sg[N];
int Hash[N];
void getSG(int n){
    memset(sg,0,sizeof(sg));
    for(int i = 1; i <= n; i++){
        memset(Hash,0,sizeof(Hash));
        for(int j = 1; f[j] <= i; j++)
            Hash[sg[i-f[j]]] = 1;
        for(int j = 0; j <= n; j++){
            if(Hash[j] == 0){
                sg[i] = j;
                break;
            }
        }
    }
}
