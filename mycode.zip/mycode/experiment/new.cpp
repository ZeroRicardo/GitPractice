#include <bits/stdc++.h>
using namespace std;
const double eps = 1e-8;
double f(double x){
  double ret = 1;
  for(int i = 1; i <= 13; i++)
    ret *= x;
  return ret * 3 - 7;
}
int main()
{
  double low = 1, high = 2, ans;
  while(low + eps < high)
  {
    double mid = (low + high) / 2;
    if(f(mid) <= 0)   ans = low = mid;
    else high = mid;
  }
  printf("%f\n", ans);
  printf("%f\n", pow(7.0 / 3, 1.0 / 13));
}
