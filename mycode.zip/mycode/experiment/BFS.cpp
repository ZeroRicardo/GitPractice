#include <bits/stdc++.h>
using namespace std;
const int inf = 0x3f3f3f3f;
struct node{
  int x, y;
  int key;
  int sm;
  node(){key = 0, sm = 0;}
  node(int a, int b, int c, int d){
    x = a, y = b, key = c, sm = d;
  }
};
int num;
int key;
char mat[105][105];
int n;
int dis[105][105][11][38];
int dx[4] = {1, 0, -1, 0}, dy[4] = {0, 1, 0, -1};
bool inrange(int x, int y){
  return 1 <= x && x <= n && 1 <= y && y <= n;
}
int &mmp(node t){
  return dis[t.x][t.y][t.key][t.sm];
}
void debug(node t){
  cout << t.x << " " << t.y << endl;
  cout << t.key << endl;
  cout << t.sm << endl;
  cout << mmp(t) << endl << endl;
}
int main(){
  while(cin >> n >> key){
    if(n == 0 && key == 0)  break;
    num = 0;
    node S;
    for(int i = 1; i <= n; i++)
      for(int j = 1; j <= n; j++){
        cin >> mat[i][j];
        if(mat[i][j] == 'K')  S.x = i, S.y = j;
        else if(mat[i][j] == 'S'){
          mat[i][j] = 'A' + num;
          num++;
        }
      }
    memset(dis, 0x3f, sizeof dis);
    queue<node> q;
    q.push(S);
    mmp(S) = 0;
    int ans = inf;
    while(!q.empty()){
      node u = q.front(); q.pop();
      //debug(u);
      int x = u.x, y = u.y, k = u.key, sm = u.sm;
      for(int i = 0; i < 4; i++){
        node v = u;
        int mx = x + dx[i], my = y + dy[i];
        v.x = mx, v.y = my;
        if(inrange(mx, my) && mat[mx][my] != '#'){
          //debug(v);
          if(isdigit(mat[mx][my])){
            int lock = mat[mx][my] - '0';
            if(lock == v.key + 1) v.key++;
            if(mmp(v) > mmp(u) + 1){
              mmp(v) = mmp(u) + 1;
              q.push(v);
            }
          }
          else if('A' <= mat[mx][my] && mat[mx][my] <= 'E'){
            int p = mat[mx][my] - 'A';
            if((sm >> p) & 1){
              if(mmp(v) > mmp(u) + 1){
                mmp(v) = mmp(u) + 1;
                q.push(v);
              }
            }
            else{
              v.sm += 1 << p;
              if(mmp(v) > mmp(u) + 2){
                mmp(v) = mmp(u) + 2;
                q.push(v);
              }
            }
          }
          else if(mat[mx][my] == 'T'){
            if(v.key >= key)  ans = min(ans, mmp(u) + 1);
          }
          else if(mmp(v) > mmp(u) + 1){
            mmp(v) = mmp(u) + 1;
            q.push(v);
          }
        }
      }
    }
    if(ans == inf)  cout << "impossible" << endl;
    else  cout << ans << endl;
  }
}
