#include <bits/stdc++.h>
using namespace std;
int main() {
  srand(time(NULL));
  int n, m;
  freopen("in.txt", "w", stdout);
  n = rand() % 6 + 1, m = rand() % 6 + 1;
  cout << n << " " << m << endl;
  int sx = rand() % n + 1, sy = rand() % m + 1;
  int ex, ey;
  do{
    ex = rand() % n + 1, ey = rand() % m + 1;
  }while(ex == sx && ey == sy);
  for(int i = 1; i <= n; i++) {
    for(int j = 1; j <= m; j++) {
      if(i == sx && j == sy) {
        cout << 'S';
        continue;
      }
      if(i == ex && j == ey) {
        cout << 'E';
        continue;
      }
      int x = rand() % 2;
      if(x) cout << 'W';
      else cout << '.';
    }
    cout << endl;
  }
}
