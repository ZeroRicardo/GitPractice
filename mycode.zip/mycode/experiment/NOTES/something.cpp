#define LOCAL
//宏定义LOCAL,本地用文件调试,提交时删去第一行
#ifdef LOCAL
  freopen("in.txt", "r", stdin);
  freopen("out.txt", "w", stdout);
#endif

//C++风格结构体定义,成员函数定义,运算符重载,输出流重载
template <typename T> //模板
struct point{
  T x, y;
  point(T x = 0, T y = 0):x(x), y(y) {}
};
template <typename T>
point<T> operator +(const point<T> &A, const point<T> &B){
  return point<T>(A.x + B.x, A.y + B.y);
}
template <typename T>
ostream& operator << (ostream &out, const point<T> &p){
  out << "(" << p.x << ", " << p.y << ")";
  return out;
}

//关闭同步,加速流输入输出
ios::sync_with_stdio(false);

int a[110], n = 100, x;
vector<int> G;      //G.size()返回数组大小, G.push_back(x)尾部添加元素x, G.pop_back()尾部删除元素, G.empty()判断G是否为空, G.clear()清空数组
sort(a, a + n); //数组sort排序
sort(G.begin(), G.end()); //vector sort排序
lower_bound(a, a + n, x);  //查找>=x的第一个位置,返回指针
lower_bound(G.begin(), G.end(), x); //vector查找
unique(a, a + n); //去重, 需先对数组进行排序, 返回尾指针

set<int> s;     //集合定义
set<int>::iterator ite; //集合迭代器定义,类似于指针
//set常用的操作有.size(), insert(x), .find(x), .begin(), .end(),
//自定义类的set,可以重载运算符<, 或自定义cmp函数 eg: set<MyStruct, cmp> s;
//set还支持集合的常用操作, 并集 set_union(), 交集 set_intersection(), 差集 set_difference, 对称差set_symmetric_difference
//上述操作示例 set_union(eg1.begin(),eg1.end(),eg2.begin(),eg2.end(),insert_iterator<set<int> >(eg3,eg3.begin()));

map<int, int> p;  //映射定义
map<int, int>::iterator mit;  //映射迭代器
//map为key-value容器,可以根据key值快速查找value(查找功能类似于字典).
//内部数据结构为平衡二叉树,map中的元素是自动按Key(自定义类重载运算符<即可)升序排序,数据可以看作有序.
//lower_bound(), upper_bound(), 比较key值.

next_permutation(a, a + n); //a数组的下一个字典序排列
pre_permutation(a, a + n);  //前一字典序排列

char c = cin.peek();  //读第一个字符,不取走
