//PAGE 223
//#define LOCAL
#include <bits/stdc++.h>
using namespace std;
int main()
{
  //宏定义LOCAL,本地用文件调试,提交时删去第一行
  #ifdef LOCAL
    freopen("in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
  #endif
  //关闭同步,加速流输入输出
  ios::sync_with_stdio(false);
}

int a, b, x;
x = (a + b) / 2; //向0取整
x = (a + b) >> 1; //向下取整
x = (a + b + 1) / 2; //向上取整
x = (a + b + 1) >> 1; // 向上取整
