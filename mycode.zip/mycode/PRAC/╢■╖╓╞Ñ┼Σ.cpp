#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 10010;
vector<int> G[MAX_V];
int match[MAX_V];
bool vis[MAX_V];
int V;
bool dfs(int u){
  for(int i = 0; i < G[u].size(); i++){
    int v = G[u][i];
    if(!vis[v]){
      vis[v] = 1;
      if(match[v] == -1 || dfs(v)){
        match[u] = v;
        match[v] = u;
        return 1;
      }
    }
  }
  return 0;
}
int hungarian(){
  int ans = 0;
  memset(match, -1, sizeof match);
  for(int u = 1; u <= V; u++){
    if(match[u] == -1){
      memset(vis, 0, sizeof vis);
      if(dfs(u))
        ans++;
    }
  }
  return ans;
}
