#include <bits/stdc++.h>
using namespace std;
const int inf = 0x3f3f3f3f
bool check(int x);
int BinarySearch(){
  //integer
  int low = 0, high = inf;

  // 寻找check(x) == 1 的最小x; check(high) = 1
  // xxxxx...√√√√
  while(low < high){
    int mid = (low + high) >> 1;
    if(check(mid)) high = mid;
    else low = mid + 1;
  }
  return high;

  //寻找check(x) == 1的最大x; check(low) = 1
  //√√√√√...xxxxx
  while(low < high){
    int mid = (low + high + 1) >> 1;
    if(check(mid))  low = mid;
    else high = mid - 1;
  }
  return low;

  //float
  double low = -inf, high = inf;
  for(int cnt = 1; cnt <= 100; cnt++){
    double mid = (low + high) / 2;
    if(check(mid))  low = mid;
    else high = mid;
  }
  return low;
}
int main(){
  printf("HELLO, WORLD\n");
}
