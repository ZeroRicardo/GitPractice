#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int a[maxn], f[maxn], g[maxn];
int n;
void LIS(){
  memset(g, 0x3f, sizeof g);
  g[0] = 0;
  for(int i = 1; i <= n; i++){
    f[i] = lower_bound(g, g + n, a[i]) - g;
    g[f[i]] = a[i];
  }
}
