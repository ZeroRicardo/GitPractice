void Read(int &x){
  char c;
  bool f = false;
  for(c = getchar(); c < '0' || c > '9'; c = getchar())
    f |= (c == '-');
  x = 0;
  for(; '0' <= c && c <= '9'; c = getchar())
    x = x * 10 + c - '0';
  if(f) x = -x;
}
