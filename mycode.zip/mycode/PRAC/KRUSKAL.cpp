#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
int par[MAX_V];
int rank[MAX_V];
void init(int n){
  for(int i = 1; i <= n; i++)
    par[i] = i;
  memset(rank, 0, sizeof rank);
}
int find(int x){
  return par[x] = (par[x] == x ? x : find(par[x]));
}
void unite(int x, int y){
  x = find(x), y = find(y);
  if(x == y)  return;
  if(rank[x] < rank[y]) par[x] = y;
  else{
    par[y] = x;
    if(rank[x] == rank[y])  rank[x]++;
  }
}
struct edge{
  int from, to, cost;
  edge(){}
  edge(int _from, int _to, int _cost):from(_from), to(_to), cost(_cost){}
  bool operator < (const edge &t)const{
    return cost < t.cost;
  }
}eg[MAX_E];
int V, E = 0;
void addedge(int u, int v, int w){
  eg[++E] = edge(u, v, w);
}
int kruskal(){
  sort(eg + 1, eg + E + 1);
  int ret = 0, cnt = V;
  for(int i = 1; i <= E; i++){
    int t1 = find(eg[i].from);
    int t2 = find(eg[i].to);
    if(t1 != t2){
      unite(t1, t2);
      ret += eg[i].cost;
      cnt--;
      if(cnt == 1)  break;
    }
  }
  return ret;
}
