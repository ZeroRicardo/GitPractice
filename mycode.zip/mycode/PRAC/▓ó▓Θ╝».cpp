#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
int par[maxn];
int rank[maxn];
void init(int n){
  for(int i = 1; i <= n; i++){
    par[i] = i;
    rank[i] = 0;
  }
}
int find(int x){
  return par[x] = (par[x] == x ? x : find(par[x]));
}
void unite(int x, int y){
  x = find(x), y = find(y);
  if(x == y)  return;
  if(rank[x] < rank[y]) par[x] = y;
  else{
    par[y] = x;
    if(rank[x] == rank[y])  rank[x]++;
  }
}
