#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn = 100010;
ll phi[maxn];
ll eulerPhi(ll n){
  ll res = n;
  for(ll i = 2; i * i <= n; i++)
    if(n % i == 0){
      res -= res / i;
      while(n % i == 0) n /= i;
    }
  if(n != 1)  res -= res / n;
  return res;
}
int main(){
  for(int i = 1; i <= 1000000; i++)
    cout << eulerPhi(i) << endl;
}
