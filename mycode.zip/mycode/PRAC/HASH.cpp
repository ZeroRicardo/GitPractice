//线性再探测法
const int mod = 1007;
int a[mod], lis[mod];
bool vis[mod];
int gethash(int x){
  int k = x % mod;
  if(k < 0) k += mod;
  while(vis[k] && lis[k] != x)  k++;
  vis[k] = 1, lis[k] = x;
  return k;
}
