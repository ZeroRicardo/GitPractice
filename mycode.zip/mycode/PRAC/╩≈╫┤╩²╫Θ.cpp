#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn = 10010;

//单点修改, 区间查询
int s[maxn], n;
int lowbit(int x){
  return x & -x;
}
void add(int x, int val){
  for(int i = x; i <= n; i += lowbit(i))
    s[i] += val;
}
int get(int x){
  int ret = 0;
  for(int i = x; i; i -= lowbit(i))
    ret += s[i];
  return ret;
}

//区间修改, 区间查询
int s1[maxn], s2[maxn], n;
int lowbit(int x){
  return x & -x;
}
void add(int x, int val){
  for(int i = x; i <= n; i += lowbit(i)){
    s1[i] += val;
    s2[i] += x * val;
  }
}
int get(int x){
  int ret = 0;
  for(int i = x; i; i -= lowbit(i))
    ret += (x + 1) * s1[i] - s2[i];
  return ret;
}
void update(int l, int r, int val){
  add(l, val);
  add(r + 1, -val);
}
int query(int l, int r){
  return get(r) - get(l - 1);
}
