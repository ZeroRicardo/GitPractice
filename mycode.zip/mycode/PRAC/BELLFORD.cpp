#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
struct edge{
  int from, to, value;
}eg[MAX_E];
int dis[MAX_V];
int V, E;
bool bellford(int s){
  memset(dis, 0x3f, sizeof dis);
  dis[s] = 0;
  for(int i = 1; i <= V; i++){
    bool update = 0;
    for(int j = 1; j <= E; j++)
    {
      int u = eg[j].from, v = eg[j].to, w = eg[j].value;
      if(dis[v] > dis[u] + w){
        dis[v] = dis[u] + w;
        update = 1;
        if(i == V) return true;
      }
    }
    if(!update) break;
  }
  return false; // No negative loops;
}
