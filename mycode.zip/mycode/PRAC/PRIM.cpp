#include <bits/stdc++.h>
using namespace std;
const int maxn = 1010;
int cost[maxn][maxn];
int mincost[maxn], pre[maxn];
bool used[maxn];
int n;
int prim(){
  memset(mincost, 0x3f, sizeof mincost);
  memset(used, 0, sizeof used);
  memset(pre, 0, sizeof pre);
  mincost[1] = 0;
  int ret = 0;
  while(1){
    int v = - 1;
    for(int i = 1; i <= n; i++)
      if(!used[i] && (v == -1 || mincost[v] > mincost[i])) v = i;
    if(v == -1) break;
    if(v != 1)
      cout << pre[v] << " " << v << endl;         //输出所选取的边
    ret += mincost[v];
    used[v] = 1;
    for(int i = 1; i <= n; i++)
      if(mincost[i] > cost[v][i]){
        mincost[i] = cost[v][i];
        pre[i] = v;
      }
  }
  return ret;   //返回边权和
}
