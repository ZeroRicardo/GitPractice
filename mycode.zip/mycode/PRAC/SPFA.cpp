#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 10010;
struct edge{
  int to, cost;
};
vector<edge> G[MAX_V];
bool vis[MAX_V];
int dis[MAX_V], cnt[MAX_V];
int V;
bool spfa(int s){
  memset(vis, 0, sizeof vis);
  memset(dis, 0x3f, sizeof dis);
  memset(cnt, 0, sizeof cnt);
  dis[s] = 0, vis[s] = 1, cnt[s] = 1;
  queue<int> q;
  q.push(s);
  while(!q.empty()){
    int u = q.front(); q.pop();
    vis[u] = 0;
    for(int i = 0; i < G[u].size(); i++){
      int v = G[u][i].to, w = G[u][i].cost;
      if(dis[v] > dis[u] + w){
        dis[v] = dis[u] + w;
        if(!vis[v]){
          vis[v] = 1;
          q.push(v);
          cnt[v]++;
          if(cnt[v] == V) return 0;   //存在负圈
        }
      }
    }
  }
  return 1;
}
