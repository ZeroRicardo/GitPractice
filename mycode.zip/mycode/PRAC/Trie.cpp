#include <bits/stdc++.h>
using namespace std;
const int maxn = 300010;
struct Trie{
  int Next[maxn][26], End[maxn];
  int root, L;
  inline int newnode(){
    for(int i = 0; i < 26; i++)
      Next[L][i] = -1;
    End[L++] = 0;
    return L - 1;
  }
  Trie(){
    L = 0;
    root = newnode();
  }
  void insert(string s){
    int len = s.length();
    int now = root;
    for(int i = 0; i < len; i++){
      int id = s[i] - 'a';
      if(Next[now][id] == -1)
        Next[now][id] = newnode();
      now = Next[now][id];
    }
    End[now] = 1;
  }
  bool query(string s){
    int len = s.length();
    int now = root;
    for(int i = 0; i < len; i++){
      int id = s[i] - 'a';
      now = Next[now][id];
    }
  }
};
Trie tree;

int main(){
  tree.insert("helloworld");
}
