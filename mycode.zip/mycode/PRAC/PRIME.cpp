#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
int prime[maxn];
bool judge(int x){
  if(x <= 1)  return 0;
  for(int i = 2; i <= sqrt(x); i++)
    if(x % i == 0)  return 0;
  return 1;
}
void get_prime(int n){
  memset(prime, 0, sizeof prime);
  for(int i = 2; i <= n; i++){
    if(!prime[i]) prime[++prime[0]] = i;
    for(int j = 1; j <= prime[0] && j <= n / i; j++){
      prime[prime[j] * i] = 1;
      if(i % prime[j] == 0) break;
    }
  }
}
int main(){
  get_prime(32767);
  cout << prime[0] << endl;
}
