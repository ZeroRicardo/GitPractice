#include <bits/stdc++.h>
using namespace std;
const int maxn = 1000010;
int f[maxn];
void pre(string &s){
  int i = 0, j = f[0] = -1, m = s.length();
  while(i < m){
    while(j != -1 && s[i] != s[j])  j = f[j];
    f[++i] = ++j;
  }
}
int kmp(string &s, string &t){
  int i = 0, j = 0, m = s.length(), n = t.length(), ans = 0;
  while(i < n){
    while(j != -1 && t[i] != s[j])  j = f[j];
    i++, j++;
    if(j >= m){
      ans++;
      j = f[j];
    }
  }
  return ans;
}
