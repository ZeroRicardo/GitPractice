#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;
const int inf = 0x3f3f3f3f;
int tot;
struct edge{
  int to, c, next;
  edge(){}
  edge(int _to, int _c, int _next):to(_to), c(_c), next(_next){}
}E[MAX_E];
int head[MAX_V], thead[MAX_V], level[MAX_V];
void addedge(int u, int v, int w){
  E[tot] = edge(v, w, head[u]);
  head[u] = tot++;
  E[tot] = edge(u, 0, head[v]);
  head[v] = tot++;
}
bool bfs(int s, int t){
  memset(level, 0, sizeof level);
  queue<int> q;
  q.push(s);
  level[s] = 1;
  while(!q.empty()){
    int u = q.front(); q.pop();
    for(int i = head[u]; i != -1; i = E[i].next){
      int v = E[i].to, w = E[i].c;
      if(w <= 0 || level[v])  continue;
      q.push(v);
      level[v] = level[u] + 1;
    }
  }
  return level[t];
}
int dfs(int u, int t, int f){
  if(u == t)  return f;
  for(int &i = thead[u]; i != -1; i = E[i].next){
    int v = E[i].to, w = E[i].c;
    if(E[i].c <= 0 || level[v] <= level[u]) continue;
    int d = dfs(v, t, min(f, w));
    if(d > 0){
      E[i].c -= d;
      E[i ^ 1].c += d;
      return d;
    }
  }
  return 0;
}
int max_flow(int s, int t){
  int ans = 0;
  while(bfs(s, t)){
    memcpy(thead, head, sizeof head);
    int f = dfs(s, t, inf);
    ans += f;
  }
  return ans;
}
void init(){
  tot = 0;
  memset(head, -1, sizeof head);
}
