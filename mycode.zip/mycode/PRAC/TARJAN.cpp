#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 1010;
vector<int> G[MAX_V];
int DFN[MAX_V], LOW[MAX_V];
int index;
bool vis[MAX_V];
stack<int> s;
void tarjan(int x){
  DFN[x] = LOW[x] = ++index;
  for(int i = 0; i < G[x].size(); i++){
    int v = G[x][i];
    if(!DFN[v]){
      tarjan(v);
      LOW[x] = min(LOW[x], LOW[v]);
    }
    else if(vis[v]){
      LOW[x] = min(LOW[x], DFN[v]);
    }
  }
  if(LOW[x] == DFN[x]){
    int tem;
    do{
      tem = s.top(); s.pop();
      vis[tem] = 0;
      cout << tem << endl;
    }while(tem != x);
  }
}
