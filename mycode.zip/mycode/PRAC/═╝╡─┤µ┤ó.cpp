#include <bits/stdc++.h>
using namespace std;
const int MAX_V = 1010;
const int MAX_E = 100010;

//存储结构定义
int mat[MAX_V][MAX_V];
//初始化
memset(mat, 0, sizeof mat);
//加边操作  addedge(u, v, w);
mat[u][v] = w;
//遍历顶点u的所有边
for(int i = 1; i <= V; i++)
  if(mat[u][v]){
    //...
  }


vector<int> G[MAX_V];
void init(int n){
  for(int i = 1; i <= n; i++)
    G[i].clear();
}
void addedge(int u, int v){
  G[u].push_back(v);
}

struct edge{
  int to, cost;
  edge(){}
  edge(int _to, int _cost):to(_to), cost(_cost){}
};
vector<edge> G[MAX_V];
void init(int n){
  for(int i = 1; i <= n; i++)
    G[i].clear();
}
void addedge(int u, int v, int w){
  G[u].push_back(edge(v, w));
}
//遍历顶点u的所有边
for(int i = 0; i < G[u].size(); i++){
  int v = G[u][i].to, w = G[u][i].cost;
  //...
}

struct edge{
  int to, cost, next;
  edge(){}
  edge(int _to, int _cost, int _next):to(_to), cost(_cost), next(_next){}
}eg[MAX_E];
int tot, head[MAX_V];
void init(){
  tot = 0;
  memset(head, -1, sizeof head);
}
void addedge(int u, int v, int w){
  eg[tot] = edge(v, w, head[u]);
  head[u] = tot++;
}
//遍历顶点u的所有边
for(int i = head[u]; i != -1; i = eg[i].next){
  int v = eg[i].to, w = eg[i].cost;
  //...
}
